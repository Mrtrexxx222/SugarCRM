<?php
$mod_strings['LBL_CCSYNC'] = 'Sync to Constant Contact';
$mod_strings['LBL_CCID'] = 'Constant Contact ID';
$mod_strings['LBL_CCLISTS'] = 'Constant Contact Lists';
?>
