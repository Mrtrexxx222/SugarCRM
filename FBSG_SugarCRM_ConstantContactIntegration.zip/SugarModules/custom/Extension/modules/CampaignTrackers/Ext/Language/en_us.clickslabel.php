<?php
$mod_strings['LBL_CLICKS'] = 'Clicks';