<?php
$dictionary['Campaign']['fields']['cc_id'] = array(
    'required' => false,
    'name' => 'cc_id',
    'vname' => 'LBL_CCID',
    'type' => 'varchar',
    'len' => 255,
);
$dictionary['Campaign']['fields']['clicks'] = array(
    'required' => false,
    'name' => 'clicks',
    'vname' => 'Clicks',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['opens'] = array(
    'required' => false,
    'name' => 'opens',
    'vname' => 'Opens',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['forwards'] = array(
    'required' => false,
    'name' => 'forwards',
    'vname' => 'Forwards',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['bounces'] = array(
    'required' => false,
    'name' => 'bounces',
    'vname' => 'Bounces',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['optouts'] = array(
    'required' => false,
    'name' => 'optouts',
    'vname' => 'Optouts',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['spamreports'] = array(
    'required' => false,
    'name' => 'spamreports',
    'vname' => 'Spam Reports',
    'type' => 'int',
    'len' => 11,
);
$dictionary['Campaign']['fields']['last_run_completed'] = array(
    'name' => 'last_run_completed',
    'type' => 'bool',
    'default' => 0,
);
