<?php
$cc_module = 'Lead';
include('custom/include/fbsg_cc_newvars.php');
