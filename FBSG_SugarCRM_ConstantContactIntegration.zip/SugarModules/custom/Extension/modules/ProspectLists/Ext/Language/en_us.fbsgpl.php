<?php
$mod_strings['LBL_CC_SYNC_BUTTON'] = 'Sync Contacts and Leads on this list to CC';
$mod_strings['LBL_SYNC_TO_CC'] = 'Sync List Details To CC';
$mod_strings['LBL_LAST_SUCCESSFUL_CC_UPDATE'] = 'Last Successful CC Update';