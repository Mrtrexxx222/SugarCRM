<?php
$mod_strings['LBL_EXPORT_STAGED_CC_CONTACTS'] = 'Handle Mass Export to CC';
$mod_strings['LBL_UPDATE_CC_CAMPAIGN_RESULTS'] = 'Update CC Campaign Results';
$mod_strings['LBL_SYNC_STAGED_LISTS'] = 'Sync Staged Lists';
$mod_strings['LBL_PROCESS_OPEN_ACTIVITIES'] = 'Process Open CC Activities';
$mod_strings['LBL_IMPORT_CONTACTS_FROM_CSYNC_TABLE'] = 'Import CC Contacts';
$mod_strings['LBL_AUTOMATIC_CONTACT_SYNC'] = 'Automatic Contact Sync';
$mod_strings['LBL_FULL_CONTACT_DOWNLOAD'] = 'Full Contact Download from CC';
$mod_strings['LBL_FULL_CONTACT_SYNC'] = 'Full Contact Sync from CC Temp Table';