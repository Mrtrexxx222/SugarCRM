<?php
$dictionary[$cc_module]['fields']['cc_sync'] = array(
    'required' => false,
    'name' => 'cc_sync',
    'vname' => 'LBL_CCSYNC',
    'type' => 'bool',
    'function' => array(
        'name' => 'displayCcSync',
        'returns' => 'html',
        'include' => 'modules/fbsg_ConstantContactIntegration/cc_list_view.php',
    ),
    'importable' => false,
    'reportable' => false,
    'duplicate_merge' => 'disabled',
);

$dictionary[$cc_module]['fields']['cc_id'] = array(
    'required' => false,
    'name' => 'cc_id',
    'vname' => 'LBL_CCID',
    'type' => 'varchar',
    'reportable' => true,
    'importable' => false,
    'len' => 255,
);

$dictionary[$cc_module]['fields']['cc_lists'] = array(
    'required' => false,
    'name' => 'cc_lists',
    'vname' => 'LBL_CCLISTS',
    'type' => 'multienum',
    'isMultiSelect' => 1,
    'options' => 'cc_list_dom',
    'reportable' => false,
    'importable' => false,
    'massupdate' => false,
    'studio' => false,
    'duplicate_merge' => 'disabled',
);

$dictionary[$cc_module]['fields']['cc_lists_view'] = array(
    'name' => 'cc_lists_view',
    'vname' => 'LBL_CCLISTS',
    'type' => 'varchar',
    'function' => array(
        'name' => 'displayLists',
        'returns' => 'html',
        'include' => 'modules/fbsg_ConstantContactIntegration/cc_list_view.php',
    ),
    'source' => 'non-db',
    'studio' => 'visible',
    'importable' => false,
    'reportable' => false,
    'duplicate_merge' => 'disabled',
);

$dictionary[$cc_module]['fields']['cc_optout'] = array(
	'required' => false,
	'name' => 'cc_optout',
	'vname' => 'Opted Out on Constant Contact',
	'type' => 'bool',
    'massupdate' => false,
	'default' => '0',
    'importable' => false,
    'reportable' => true,
    'duplicate_merge' => 'disabled',
);
