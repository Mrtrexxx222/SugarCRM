<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
require_once('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');
require_once('modules/fbsg_ConstantContactIntegration/fbsg_ConstantContactIntegration.php');
require_once('modules/ProspectLists/ProspectList.php');

class fbsg_cc_LeadLogic {
    function SyncToCC(&$bean, $event, $arguments) {
        global $db;
        $requestAction = '';
        $cc_Lists = '';

        if (isset($_REQUEST) && isset($_REQUEST['action'])) {
            $requestAction = $_REQUEST['action'];
        }
        $cc_acc = SugarCC::GetOnlyCC();
        if(!$cc_acc) return;
        if ($requestAction === 'Save' && !(isset($_REQUEST['fbsg_save']) && $_REQUEST['fbsg_save'] === false)) {
            if ($bean->cc_sync == false) {
                return;
            }
            $cc = new CCBasic($cc_acc->name, $cc_acc->password);
            $ccContact = new SugarCCPerson($cc);
            $ccContact->Sync($bean);
        } 
    }
}

?>
