<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');
require_once('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');
require_once('modules/fbsg_ConstantContactIntegration/fbsg_ConstantContactIntegration.php');
require_once('modules/ProspectLists/ProspectList.php');

class fbsg_cc_ProspectListsLogic {
    function SyncToCC(&$bean, $event, $arguments) {
        global $db;
        $requestAction = '';
        
        if (isset($_REQUEST) && isset($_REQUEST['action'])) {
            $requestAction = $_REQUEST['action'];
        }
        
        if ($requestAction === 'Save') {
            if ($bean->sync_to_cc == false || $bean->name === null || $bean->name == '') {
                return;
            }
            
            $cc_acc = SugarCC::GetOnlyCC();
            if(!$cc_acc) return;
            
            $cc = new CCBasic($cc_acc->name, $cc_acc->password);
            $ccList = new SugarCCList($cc);
            $ccList->Sync($bean);
        } 
    }
}

class fbsg_cc_ListLogic {
    function stage_associated_person(&$bean, $event, $arguments) {
    }
}