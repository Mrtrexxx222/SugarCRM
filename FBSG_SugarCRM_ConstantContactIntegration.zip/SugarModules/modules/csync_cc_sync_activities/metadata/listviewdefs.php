<?php
$module_name = 'csync_cc_sync_activities';
$listViewDefs [$module_name] = 
array (
  'ACTIVITY_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ACTIVITY_ID',
    'width' => '10%',
    'default' => true,
  ),
  'LIST_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LIST_ID',
    'width' => '10%',
    'default' => true,
  ),
  'PROCESSED' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_PROCESSED',
    'width' => '10%',
    'default' => true,
  ),
);
?>
