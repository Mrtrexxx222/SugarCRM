<?PHP

require_once ('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');
class csync_cc_sync_tableController extends SugarController {
	public function __construct() {
		parent::__construct();
	}
	public function action_index() {
		$this->view = 'panel';
	}
	public function action_panel() {
		$this->view = 'panel';
	}
	public function action_import() {
		$this->view = 'import';
	}
	public function action_start_cc_export() {
		$this->view = null;
		set_time_limit(300);
		$sCCActivity = new SugarCCActivity();
		$num_lists = $sCCActivity->exportAllContacts();
		if ($num_lists == - 1) {
			echo 'Error: Export Failed';
		} else if ($num_lists == 0) {
			echo 'Error: No lists to be exported';
		} else {
			echo 'Constant Contact export process initiated for ' . $num_lists . ' lists';
		}
	}
	public function action_update_activities_table() {
		global $db;
		$this->view = null;
		$lists = Array();
		$activities_table = Array();
		
		$proSeed = new ProspectList();
		$bean_list = $proSeed->get_full_list('', 'prospect_lists.cc_id is not null');
		
		foreach ($bean_list as $bean) {
			$lists[$bean->cc_id] = $bean->name;
		}
		
		$query = 'SELECT * FROM csync_cc_sync_activities';
		$results = $db->query($query);
		
		while ($row = $db->fetchByAssoc($results)) {
			$activities_table[] = Array(
					'name' => $lists[$row['list_id']],
					'status' => $row['processed'],
					'list_id' => $row['list_id']
			);
		}
		
		echo json_encode($activities_table);
	}
	public function action_sync_table_to_contacts_leads() {
		set_time_limit(600);
		$query_array = json_decode(html_entity_decode($_POST['query_array'], ENT_QUOTES));
		$this->view = null;
		
		$cc = SugarCC::GetOnlyCC();
		$ut = new CCBasic($cc->name, $cc->password);
		$SCCMass = new SugarCCMass($ut);
		if ($SCCMass->SyncImportTableToContacts($query_array)) {
			echo "Sync Complete";
		}
	}
	public function action_import_contacts_from_cc_to_sugar() {
		$this->view = 'import';
		self::mark_cc_contacts_for_import('Contacts');
	}
	public function action_import_leads_from_cc_to_sugar() {
		$this->view = 'import';
		self::mark_cc_contacts_for_import('Leads');
	}
	public function action_import_prospects_from_cc_to_sugar() {
		$this->view = 'import';
		self::mark_cc_contacts_for_import('Prospects');
	}
	public function action_import_accounts_from_cc_to_sugar() {
		$this->view = 'import';
		self::mark_cc_contacts_for_import('Accounts');
	}
	public function action_force_sched() {
		require_once ('custom/modules/Schedulers/Ext/ScheduledTasks/scheduledtasks.ext.php');
		$this->view = null;
		switch ($_REQUEST['job']) {
			case 'process_open_activities' :
				process_open_activities();
				break;
			case 'import_contacts_from_csync_table' :
				import_contacts_from_csync_table();
				break;
			case 'update_cc_campaign_results' :
				set_time_limit(600);
				update_cc_campaign_results();
				break;
		}
	}
	
	/**
	 * Marks downloaded CC contacts for import into a particular module
	 * specified with the string.
	 *
	 * @param string $bean_type        	
	 */
	public static function mark_cc_contacts_for_import($bean_type) {
		set_time_limit(600);
		if ($_REQUEST['select_entire_list']) {
			$uids = self::get_ids_from_query();
		} else if (! empty($_REQUEST['uid'])) {
			$uids = explode(',', $_REQUEST['uid']);
		}
		$cc = SugarCC::GetOnlyCC();
		$ut = new CCBasic($cc->name, $cc->password);
		$CCMass = new SugarCCMass($ut);
		$results = $CCMass->FlagCCTableForImport($uids, $bean_type);
		self::disp_import_results($results, $bean_type);
	}
	public static function get_ids_from_query() {
		global $db;
		$ret = Array();
		$query_search = '';
		$current_query_by_page = unserialize(base64_decode($_REQUEST['current_query_by_page']));
		if ((isset($current_query_by_page['searchFormTab'])) && (preg_match('/(.*)_search$/', $current_query_by_page['searchFormTab'], $match_res))) {
			$search_type = $match_res[1];
			foreach ($current_query_by_page as $search_key => $search_value) {
				if (preg_match('/(.*)_' . $search_type . '$/', $search_key, $field)) {
					if ($search_value) {
						$query_search .= $field[1] . ' LIKE "' . $search_value . '%" AND ';
					}
				}
			}
		}
		$query_search = substr($query_search, 0, - 5);
		$query = 'SELECT id FROM csync_cc_sync_table';
		if ($query_search) {
			$query .= ' WHERE ' . $query_search;
		}
		$res = $db->query($query);
		while ($row = $db->fetchByAssoc($res)) {
			$ret[] = $row['id'];
		}
		return $ret;
	}
	public static function disp_import_results($res, $bean_type) {
		$script = '<script type="text/javascript">' . 'var queued = ' . $res['queued'] . ';' . 'var skipped = ' . $res['skipped'] . ';' . 'var bean_type = "' . $bean_type . '";' . '</script>';
		echo $script;
	}
}
