if (queued) {
    var mess = queued + ' ' + bean_type + ' will be imported';
    if (skipped) {
        mess += '<br />Warning: The Last Name field is required in Sugar. ' + skipped + ' ' + bean_type + ' have no last name and will be skipped.';
    }
    YAHOO.SUGAR.MessageBox.show({
        type:"alert",
        title:"Import Started",
        msg: mess,
        fn:function(){window.location='index.php?module=csync_cc_sync_table&action=listview';},
    });
}