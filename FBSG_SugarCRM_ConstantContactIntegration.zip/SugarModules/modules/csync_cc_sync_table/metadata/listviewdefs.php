<?php
$module_name = 'csync_cc_sync_table';
$listViewDefs [$module_name] = 
array (
  'CC_EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'CC_FIRST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_FIRST_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'CC_LAST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_LAST_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'CC_WORK_PHONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_WORK_PHONE',
    'width' => '10%',
    'default' => true,
  ),
  'CC_HOME_PHONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_HOME_PHONE',
    'width' => '10%',
    'default' => true,
  ),
  'CC_ADDRESS_STREET' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_ADDRESS_STREET',
    'width' => '10%',
    'default' => true,
  ),
  'CC_ADDRESS_CITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_ADDRESS_CITY',
    'width' => '10%',
    'default' => true,
  ),
  'CC_ADDRESS_STATE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_ADDRESS_STATE',
    'width' => '10%',
    'default' => true,
  ),
  'CC_ADDRESS_COUNTRY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_ADDRESS_COUNTRY',
    'width' => '10%',
    'default' => true,
  ),
  'CC_ADDRESS_POSTALCODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CC_ADDRESS_POSTALCODE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
