<?php
$module_name = 'csync_cc_sync_table';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'cc_first_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_FIRST_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_first_name',
      ),
      'cc_last_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_LAST_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_last_name',
      ),
      'cc_email' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_EMAIL',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_email',
      ),
    ),
    'advanced_search' => 
    array (
      'cc_first_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_FIRST_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_first_name',
      ),
      'cc_last_name' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_LAST_NAME',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_last_name',
      ),
      'cc_email' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_EMAIL',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_email',
      ),
      'cc_work_phone' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_WORK_PHONE',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_work_phone',
      ),
      'cc_home_phone' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_HOME_PHONE',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_home_phone',
      ),
      'cc_address_street' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_ADDRESS_STREET',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_address_street',
      ),
      'cc_address_city' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_ADDRESS_CITY',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_address_city',
      ),
      'cc_address_state' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_ADDRESS_STATE',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_address_state',
      ),
      'cc_address_postalcode' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_ADDRESS_POSTALCODE',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_address_postalcode',
      ),
      'cc_address_country' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CC_ADDRESS_COUNTRY',
        'width' => '10%',
        'default' => true,
        'name' => 'cc_address_country',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
