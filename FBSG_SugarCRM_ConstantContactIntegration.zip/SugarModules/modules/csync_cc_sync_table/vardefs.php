<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/en/msa/master_subscription_agreement_11_April_2011.pdf
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2011 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

$dictionary['csync_cc_sync_table'] = array(
		'table' => 'csync_cc_sync_table',
		'audited' => false,
		'fields' => array(
				'cc_id' => array(
						'required' => false,
						'name' => 'cc_id',
						'vname' => 'LBL_CC_ID',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '100',
						'size' => '20'
				),
				'cc_email' => array(
						'required' => false,
						'name' => 'cc_email',
						'vname' => 'LBL_CC_EMAIL',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '255',
						'size' => '20'
				),
				'cc_first_name' => array(
						'required' => false,
						'name' => 'cc_first_name',
						'vname' => 'LBL_CC_FIRST_NAME',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '100',
						'size' => '20'
				),
				'cc_last_name' => array(
						'required' => false,
						'name' => 'cc_last_name',
						'vname' => 'LBL_CC_LAST_NAME',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '100',
						'size' => '20'
				),
				'cc_work_phone' => array(
						'required' => false,
						'name' => 'cc_work_phone',
						'vname' => 'LBL_CC_WORK_PHONE',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '20',
						'size' => '20'
				),
				'cc_home_phone' => array(
						'required' => false,
						'name' => 'cc_home_phone',
						'vname' => 'LBL_CC_HOME_PHONE',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '20',
						'size' => '20'
				),
				'cc_address_street' => array(
						'required' => false,
						'name' => 'cc_address_street',
						'vname' => 'LBL_CC_ADDRESS_STREET',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '255',
						'size' => '20'
				),
				'cc_address_city' => array(
						'required' => false,
						'name' => 'cc_address_city',
						'vname' => 'LBL_CC_ADDRESS_CITY',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '100',
						'size' => '20'
				),
				'cc_address_state' => array(
						'required' => false,
						'name' => 'cc_address_state',
						'vname' => 'LBL_CC_ADDRESS_STATE',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '50',
						'size' => '20'
				),
				'cc_address_country' => array(
						'required' => false,
						'name' => 'cc_address_country',
						'vname' => 'LBL_CC_ADDRESS_COUNTRY',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '100',
						'size' => '20'
				),
				'cc_address_postalcode' => array(
						'required' => false,
						'name' => 'cc_address_postalcode',
						'vname' => 'LBL_CC_ADDRESS_POSTALCODE',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '50',
						'size' => '20'
				),
				'cc_list_id' => array(
						'required' => false,
						'name' => 'cc_list_id',
						'vname' => 'LBL_CC_LIST_ID',
						'type' => 'varchar',
						'massupdate' => 0,
						'comments' => '',
						'help' => '',
						'importable' => 'true',
						'duplicate_merge' => 'disabled',
						'duplicate_merge_dom_value' => '0',
						'audited' => false,
						'reportable' => true,
						'calculated' => false,
						'len' => '255',
						'size' => '20'
				),
				'import_this' => array(
						'required' => false,
						'name' => 'import_this',
						'vname' => 'Import This',
						'type' => 'varchar',
						'massupdate' => 0,
						'duplicate_merge' => 'disabled',
						'calculated' => false,
						'len' => '20',
						'size' => '20'
				),
				'cc_opt_out' => array(
						'required' => false,
						'name' => 'cc_opt_out',
						'vname' => 'Opt-Out',
						'type' => 'int',
						'massupdate' => 0,
						'duplicate_merge' => 'disabled',
						'calculated' => false,
						'len' => '1',
						'size' => '1'
				)
		),
		'relationships' => array(),
		'optimistic_locking' => true,
		'unified_search' => true
);
if (! class_exists('VardefManager')) {
	require_once ('include/SugarObjects/VardefManager.php');
}
VardefManager::createVardef('csync_cc_sync_table', 'csync_cc_sync_table', array(
		'basic',
		'assignable'
));