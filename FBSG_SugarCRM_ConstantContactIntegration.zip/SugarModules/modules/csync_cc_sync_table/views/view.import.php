<?PHP
require_once('include/MVC/View/SugarView.php');

class ViewImport extends SugarView {
    
    public function preDisplay() {
        $this->dv->tpl = 'modules/csync_cc_sync_table/tpl/import.tpl';
    }
    
    public function display() {
        $smarty = new Sugar_Smarty();
        $smarty->assign('widget_script', $this->getJavascriptpath() . 'sugar_grp_yui_widgets.js');
        $smarty->display($this->dv->tpl);
    }

    public function getJavascriptPath() {
        if (preg_match('/^6\.[0-3]/', $GLOBALS['sugar_version'])) {
            return 'include/javascript/';
        } else {
            return 'cache/include/javascript/';
        }
    }
}
?>