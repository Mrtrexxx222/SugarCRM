<?php

require_once('include/MVC/View/views/view.list.php');

class csync_cc_sync_tableViewList extends ViewList {
    public function preDisplay() {
        parent::preDisplay();
        
        $this->lv->actionsMenuExtraItems[] = $this->syncContacts();
        $this->lv->actionsMenuExtraItems[] = $this->syncLeads();
        $this->lv->actionsMenuExtraItems[] = $this->syncProspects();
        $this->lv->actionsMenuExtraItems[] = $this->syncAccounts();
    }
    
    protected function syncContacts() {
        return 
<<<EOHTML
<a href='#' style='width:150px;' class='menuItem' onmouseover='hiliteItem(this, "yes");' onmouseout='unhiliteItem(this);' onclick='sugarListView.get_checks();if(sugarListView.get_checks_count() < 1) {alert("None Selected");return false;}var previous = document.MassUpdate.action.value;document.MassUpdate.action.value = "import_contacts_from_cc_to_sugar";document.MassUpdate.submit();document.MassUpdate.action.value = previous;'>Import Contacts</a>
EOHTML;
    }
    
    protected function syncLeads() {         
        return 
<<<EOHTML
<a href='#' style='width:150px;' class='menuItem' onmouseover='hiliteItem(this, "yes");' onmouseout='unhiliteItem(this);' onclick='sugarListView.get_checks();if(sugarListView.get_checks_count() < 1) {alert("None Selected");return false;}var previous = document.MassUpdate.action.value;document.MassUpdate.action.value = "import_leads_from_cc_to_sugar";document.MassUpdate.submit();document.MassUpdate.action.value = previous;'>Import Leads</a>
EOHTML;
    }

    protected function syncProspects() {         
        return 
<<<EOHTML
<a href='#' style='width:150px;' class='menuItem' onmouseover='hiliteItem(this, "yes");' onmouseout='unhiliteItem(this);' onclick='sugarListView.get_checks();if(sugarListView.get_checks_count() < 1) {alert("None Selected");return false;}var previous = document.MassUpdate.action.value;document.MassUpdate.action.value = "import_prospects_from_cc_to_sugar";document.MassUpdate.submit();document.MassUpdate.action.value = previous;'>Import Targets</a>
EOHTML;
    }

    protected function syncAccounts() {
        return 
<<<EOHTML
<a href='#' style='width:150px;' class='menuItem' onmouseover='hiliteItem(this, "yes");' onmouseout='unhiliteItem(this);' onclick='sugarListView.get_checks();if(sugarListView.get_checks_count() < 1) {alert("None Selected");return false;}var previous = document.MassUpdate.action.value;document.MassUpdate.action.value = "import_accounts_from_cc_to_sugar";document.MassUpdate.submit();document.MassUpdate.action.value = previous;'>Import Accounts</a>
EOHTML;
    }
}