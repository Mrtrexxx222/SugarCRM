<?php
class fbsg_CCIntegrationLog extends Basic {
	public $new_schema = true;
	public $module_dir = 'fbsg_CCIntegrationLog';
	public $object_name = 'fbsg_CCIntegrationLog';
	public $table_name = 'fbsg_ccintegrationlog';
	public $importable = false;
    public $id;
    public $name;
    public $date_entered;
    public $date_modified;
    public $modified_user_id;
    public $modified_by_name;
    public $created_by;
    public $created_by_name;
    public $description;
    public $deleted;
    public $created_by_link;
    public $modified_user_link;
    public $assigned_user_id;
    public $assigned_user_name;
    public $assigned_user_link;
    public $bean_id;
    public $bean_module;
    public $action;
    public $message;
    public $disable_row_level_security = true;

    public function __construct(){
        parent::__construct();
    }

    public function bean_implements($interface){
        switch($interface){
            case 'ACL': return true;
         }
        return false;
    }

    public static function LogBeanInteraction($bean, $action, $isError, $message = '') {
        self::LogInteraction($bean->id, $bean->module_dir, $action, $isError, $message);
    }

    public static function LogInteraction($bean_id, $bean_module, $action, $isError, $message = '') {
        $logEntry = new fbsg_CCIntegrationLog();
        $logEntry->bean_id = $bean_id;
        $logEntry->bean_module = $bean_module;
        $logEntry->action = $action;
        $logEntry->message = $message;
        $logEntry->is_error = $isError;
        $logEntry->save();
    }
}
