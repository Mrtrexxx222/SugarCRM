<?php
// created: 2012-12-03 14:22:51
$subpanel_layout['list_fields'] = array (
  'is_error' => 
  array (
    'type' => 'bool',
    'vname' => 'LBL_IS_ERROR',
    'width' => '10%',
    'default' => true,
  ),
  'action' => 
  array (
    'type' => 'varchar',
    'vname' => 'LBL_ACTION',
    'width' => '10%',
    'default' => true,
  ),
  'message' => 
  array (
    'type' => 'varchar',
    'vname' => 'LBL_MESSAGE',
    'width' => '10%',
    'default' => true,
  ),
  'date_entered' => 
  array (
    'type' => 'datetime',
    'vname' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
);