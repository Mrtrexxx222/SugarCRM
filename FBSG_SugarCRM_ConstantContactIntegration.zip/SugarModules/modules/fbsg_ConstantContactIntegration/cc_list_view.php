<?php
require_once('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');

class CCListsRender {
    public static function renderError() {
        return 'Constant Contact Integration has expired, or no Constant Contact'
             . ' account registered.';
    }

    public static function renderOptout() {
        return 'Opted Out';
    }

    public static function checkCcAndOptout($bean) {
        if(SugarCC::GetOnlyCC() == null) return self::renderError();
        if($bean->cc_optout) return CCListsRender::renderOptout();

        return false;
    }

    public static function renderSyncView($bean, $type = 'detail') {
        $errorCheck = self::checkCcAndOptout($bean);
        if($errorCheck) return $errorCheck;

        $checked = $bean->cc_sync ? 'checked ' : '';
        $disabled = ($type == 'detail' ? 'disabled ' : '');

        return '<input type="hidden" name="cc_sync" id="cc_sync" />'
            . '<input type="checkbox" class="checkbox" name="cc_sync" '
            . $checked . $disabled . ' />';
    }

    public static function renderDetailView($bean) {
        $errorCheck = self::checkCcAndOptout($bean);
        if($errorCheck) return $errorCheck;

        $ccPerson = new SugarCCPerson();

        $bean_lists = $ccPerson->getListNames($bean);

        $html = '';
        foreach($bean_lists as $list) {
            $html .= "<li style=\"margin-left:10px;\">$list</li>";
        }

        return $html; 
    }

    public static function renderEditView($bean) {
        $errorCheck = self::checkCcAndOptout($bean);
        if($errorCheck) return $errorCheck;

        $ccPerson = new SugarCCPerson();
        $html = 
        '<script type="text/javascript">
            var check_form_old = check_form;
            check_form = function(formname) {
                var oldAllow = check_form_old(formname);

                if(oldAllow === false) return false;

                var ccCheckbox = document.getElementById("cc_sync");
                var ccLists = document.getElementById("cc_lists");

                if(!ccCheckbox || !ccLists) return oldAllow;

                if(ccCheckbox.checked && !ccLists.value) return confirm("This contact is set to Constant Contact, but is not assigned to any lists. If you proceed, this contact will be removed from all lists in Constant Contact. Are you sure you want to do this?");
                return oldAllow;
            };
        </script>';
        $html .= '<input type="hidden" id="cc_lists_multiselect"'
            . ' name="cc_lists_multiselect" value="true">'
            . '<select id="cc_lists" name="cc_lists[]" multiple="true" size="6"'
            . ' style="width:150" title="">';
        
        $all_lists = SugarCCList::GetAllCCListNames();
        $bean_lists = $ccPerson->getListNames($bean);

        foreach($all_lists as $list) {
            $html .= "<option label=\"$list\" value=\"$list\"";
            if(in_array($list, $bean_lists)) {
                $html .= " selected";
            }
            $html .= ">$list</option>";
        }

        $html .= "</select>";
        return $html;
    }
}

function displayCcSync($focus, $field, $value, $view) {
    if($view == 'EditView') {
        return CCListsRender::renderSyncView($focus, 'edit');
    } else if($view == 'DetailView') {
        return CCListsRender::renderSyncView($focus, 'detail');
    } else return '';
}

function displayLists($focus, $field, $value, $view) {
    if($view == 'EditView') {
        return CCListsRender::renderEditView($focus);
    } else if($view == 'DetailView') {
        return CCListsRender::renderDetailView($focus);
    } else {
        return '';
    }
}


