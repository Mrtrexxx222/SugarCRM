<?php
require_once ('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');

class fbsg_ConstantContactIntegrationController extends SugarController {
	public function __construct() {
		parent::__construct();
		$this->action_remap = array(
				'index' => 'config',
				'ListView' => 'config',
				'DetailView' => 'config',
				'EditView' => 'config'
		);
	}
	public function action_config() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_config]");
		$this->view = 'config';
	}
	public function action_index() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_index]");
		$this->view = 'config';
	}
	public function GetFirst($query) {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][GetFirst]");
		global $db;
		$results = $db->query($query);
		if ($row = $db->fetchByAssoc($results)) {
			return $row;
		}
		return null;
	}

	private function constructCCID($nexturi, $base_url, $type) {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][constructCCID]");
		if (preg_match('/(\/ws\/customers\/.*\/' . $type . '\/[\d]+).*/', $nexturi, $matches)) {
			return $base_url . $matches[1];
		}
		return null;
	}
	public function action_addccaccount() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_addccaccount]");
		global $db, $timedate;
		$ccAccount = new fbsg_ConstantContactIntegration();
		$ccAccount->name = $db->quote($_POST['ccemail']);
		$ccAccount->password = $db->quote($_POST['ccpassword']);
		$ccAccount->pkey = $db->quote($_POST['cckey']);
		$ccAccount->last_auto_update = $timedate->now();
		$ccAccount->save();
		$utility = new CCBasic($ccAccount->name, $ccAccount->password);
		$ccLists = new SugarCCList($utility);
		$ccLists->CreateProspectLists();
		$this->view = 'config';
	}
	public function action_reverify() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_reverify]");
		global $db;
		if (isset($_POST['accountname']) && isset($_POST['cckey'])) {
			$aname = $_POST['accountname'];
			$pkey = $_POST['cckey'];
			$cc = SugarCC::GetSugarCCFromName($aname);
			$cc->pkey = $db->quote($pkey);
			$cc->save();
		}
		$this->view = 'config';
	}
	public function action_getlists() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getlists]");
		global $db;
		$this->view = null;
		echo '200';
		return;
		if (! isset($_REQUEST['accountname'])) {
			echo "Error: No account name.";
			return;
		}
		$accName = $db->quote($_REQUEST['accountname']);
		$cc = SugarCC::GetOnlyCCUtility();
		if ($cc) {
			$ccLists = new SugarCCList($cc);
			$response = $ccLists->CreateProspectLists();
			echo $response['status'];
		}
	}

	// AJAX controller action to get all campaigns
	public function action_getcampaigns() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaigns]");
		$this->view = null;
		if (! isset($_POST['accountname'])) {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaigns] No account name.");
			echo 'Error';
		} else {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaigns] Account name = {$_POST['accountname']}");
			$ccBasic = SugarCC::GetOnlyCCUtility();
			if ($ccBasic === null)
				return;
			$ccCamp = new SugarCCCampaign($ccBasic);
			$ccIDs = $ccCamp->GetCampaigns();
			$json = json_encode($ccIDs);
			echo $json;
		}
	}
	public function action_getcampaignevents() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents]");
		$this->view = null;
		$cc = SugarCC::GetOnlyCCUtility();
        $sugCC = SugarCC::GetOnlyCC();
		if (! $cc) {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] Couldn't find CC account.");
			echo json_encode(array(
					'error' => 'Couldn\'t find CC account.'
			));
		}
		if (! isset($_POST['accountname'])) {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] No account name.");
			echo json_encode(array(
					'error' => 'No account name passed.'
			));
		}

		if (isset($_POST['state'])) {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] State = {$_POST['state']}");
			$state = json_decode(html_entity_decode($_POST['state'], ENT_QUOTES));
			$camCCID = $state->ccid;
			$eventGetter = new CCCampaignEventCollection($cc, $camCCID, $sugCC->sync_sent_results, get_object_vars($state->nextUrls), get_object_vars($state->collections));
			$maxRounds = 2;
		} else if (! empty($_POST['ccid'])) {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] CCID = {$_POST['ccid']}");
			$camCCID = html_entity_decode($_POST['ccid'], ENT_QUOTES);
			$ccCamp = new SugarCCCampaign($cc);
			$updatedCampaign = $ccCamp->UpdateCampaign($camCCID);

			if ($updatedCampaign->status != 'Complete') {
			    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] Updated campaign is not complete.");
				echo json_encode(array(
						'status' => true
				));
				return;
			}

			$eventGetter = new CCCampaignEventCollection($cc, $camCCID, $sugCC->sync_sent_results);
			$eventGetter->GetCampaignCollections();
			$maxRounds = 1;
		} else {
		    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] No state or campaign ID passed in.");
			echo json_encode(array(
					'error' => 'No state or campaign ID passed in.'
			));
		}
		$GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] Starting get detailed results.");
		$eventStatus = SugarCCCampaign::GetDetailedResults($eventGetter, $maxRounds);
		$GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getcampaignevents] Done getting detailed results.");
		echo json_encode(array(
				'status' => $eventStatus ? true : false,
				'ccid' => $camCCID,
				'nextUrls' => $eventGetter->nextURLs,
				'collections' => $eventGetter->collections
		));
	}
	public function action_saveschedule() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_saveschedule]");
		$this->view = null;
		global $db;
		if (! isset($_REQUEST['accountname']) || ! isset($_REQUEST['sindex'])) {
			echo 'Error';
		} else {
			$name = urldecode($_REQUEST['accountname']);
			$cc = SugarCC::GetOnlyCC($name);
			if ($cc) {
				$cc->schedule_index = htmlspecialchars($db->quote($_REQUEST['sindex']));
				$cc->save();
			} else {
				echo "Nope.";
			}
		}
	}

	public function action_listactivities() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_listactivities]");
		$this->view = null;
		$cc = SugarCC::GetOnlyCCUtility();
		if (! $cc) {
			echo 'No CC account found.';
			return;
		}

		$activities = new CCActivityCollection($cc);
		$activities->GetData();

		echo '<pre>' . print_r($activities->Items, true) . '</pre>';
	}
	public function action_testwithcreds() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_testwithcreds]");
		$this->view = null;
		$success = false;
		if (isset($_POST['username']) && isset($_POST['pass']) && isset($_POST['pkey'])) {
			$cc = new CCBasic($_POST['username'], $_POST['pass'], true, false);
			$success = SugarCC::TestAccount($cc);
		}

		if ($success) {
			echo json_encode(array(
					'success' => true,
					'error' => null
			));
		} else {
			echo json_encode(array(
					'success' => false,
					'error' => null
			));
		}
	}
	public function action_removeaccount() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_removeaccount]");
		$this->view = null;
		if (isset($_POST['accountname'])) {
			$accName = $_POST['accountname'];
			$scc = SugarCC::GetSugarCCFromName($accName);
			if ($scc) {
				$scc->deleted = 1;
				$scc->save();
			}
		}
	}

	public function action_force_sched() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_force_sched]");
		require_once ('custom/modules/Schedulers/Ext/ScheduledTasks/scheduledtasks.ext.php');
		$this->view = null;
		set_time_limit(600);
		global $db;
		$db->setQueryLimit(50000);
		echo 'Trying to execute ' . $_REQUEST['job'];
		switch ($_REQUEST['job']) {
			case 'process_open_activities' :
				process_open_activities();
				break;
			case 'import_contacts_from_csync_table' :
				import_contacts_from_csync_table();
				break;
			case 'sync_staged_lists' :
				$sCC = SugarCC::GetOnlyCC();
				if (! $sCC) {
					echo 'Couldn\'t get the CC bean.';
					return false;
				}

				$ut = new CCBasic($sCC->name, $sCC->password);
				$ccMass = new SugarCCMass($ut);
				echo 'Okay, executing SyncStagedLists...';
				$ccMass->SyncStagedLists();
				break;
			case 'update_cc_campaign_results' :
				update_cc_campaign_results();
				break;
			case 'automatic_contact_sync' :
				automatic_contact_sync();
				break;
			case 'full_contact_sync':
				full_contact_sync();
				break;
			default :
				echo 'Unrecognized job.';
		}
	}
	public function action_sync_lists() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_sync_lists]");
		$this->view = null;
		$sugarCC = SugarCC::GetOnlyCC();
		$utility = new CCBasic($sugarCC->name, $sugarCC->password);
		$ccList = new SugarCCList($utility);
		$syncResult = $ccList->CreateProspectLists();

		if ($syncResult) {
			echo json_encode(array(
					'error' => null,
					'message' => 'Constant Contact lists synchronized with Sugar Prospect Lists.'
			));
		} else {
			echo json_encode(array(
					'error' => 'Could not communicate with CC',
					'message' => 'Could not communicate with CC'
			));
		}
	}

    public function action_sync_sent_results() {
        $syncSent = empty($_REQUEST['sync_sent']) ? 0 : 1;
        $cc = SugarCC::GetOnlyCC();
        $cc->sync_sent_results = $syncSent;
        $cc->save();
    }

	public function action_auto_import_settings() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_auto_import_settings]");
		set_time_limit(600);
		global $db, $timedate;
		$query_array = json_decode(html_entity_decode($_POST['query_array'], ENT_QUOTES));
		$this->view = null;

		$cc = SugarCC::GetOnlyCC();
		$cc->auto_import_module = $query_array[0];
		$cc->last_auto_update = $timedate->asDb($timedate->fromUser($query_array[1]));
		$cc->save();

		if (true) {
			echo "Automatic import settings have been updated.";
		}
	}
	public function action_sync_prospect_list() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_sync_prospect_list]");
		global $db;
		$this->view = null;
		if (empty($_POST['id'])) {
			echo json_encode(array(
					'error' => 'No list id passed.'
			));
			return;
		}
		$plID = $_POST['id'];
		$pl = new ProspectList();
		$pl->retrieve($plID);
		if (! $pl->id) {
			echo json_encode(array(
					'error' => 'Could not retrieve prospect list ' . $plID
			));
			return;
		}

		$cc = SugarCC::GetOnlyCC();

		if (! $cc) {
			echo json_encode(array(
					'error' => 'No active CC account found, or product key expired.'
			));
			return;
		}

		$countQuery = "select count(*) as num from prospect_lists_prospects where " . "prospect_list_id = '{$db->quote($pl->id)}' AND deleted = 0 " . "AND (related_type = 'Accounts' or related_type = 'Contacts' or related_type = 'Leads' or related_type = 'Prospects')";
		$count = $db->getOne($countQuery);
		if ($count > $cc->maxPLToSend) {
			$pl->sync_to_cc = true;
			$pl->save();
			echo json_encode(array(
					'error' => null,
                    'message' => 'Due to its size, this list will be synchronized in the background.',
                    'background' => true,
                    'count' => $count
			));
			return;
		} else {
			$ut = new CCBasic($cc->name, $cc->password);
			$ccMass = new SugarCCMass($ut);
            $response = $ccMass->SyncListToCC($pl);
			echo json_encode(array(
					'error' => null,
					'message' => 'CC List ' . $plID . ' synced to CC',
                    'count' => $count
			));
			return;
		}
	}
	public function action_getccitem() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_getccitem]");
		$this->view = null;
		$type = $_REQUEST['type'];
		$id = $_REQUEST['id'];

		$cc = SugarCC::GetOnlyCC();
		$ut = new CCBasic($cc->name, $cc->password);
		echo '<pre>' . htmlentities(print_r($ut->GetData($ut->GetEndpoint($type) . '/' . $id), true)) . '</pre>';
	}
	public function action_set_lead_source() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_set_lead_source]");
		global $db;
		$this->view = null;

		$cc_seed = new fbsg_ConstantContactIntegration();
		$bean = $cc_seed->get_full_list('', "fbsgcci.deleted='0'");
		if (count($bean)) {
			$bean = $bean[0];
			$bean->lead_source = $_REQUEST['lead_source'];
			$bean->save();
		}
	}
	public function action_update_contacts_sync_table() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_update_contacts_sync_table]");
		$this->view = null;
		$sugarCC = SugarCC::GetOnlyCC();
		$utility = new CCBasic($sugarCC->name, $sugarCC->password);
		SugarCCMass::update_contacts_sync_table(new DateTime(), $utility);
	}

	public function action_update_optouts() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_update_optouts]");
		$this->view = null;
		set_time_limit(600);
		$sugarCC = SugarCC::GetOnlyCC();
		$utility = new CCBasic($sugarCC->name, $sugarCC->password);
		$ccMass = new SugarCCMass($utility);

		$updateResult = $ccMass->UpdateOptouts();

		ob_clean();

		echo json_encode(array(
			'error' => false,
			'message' => 'Found ' . $updateResult['cc_optouts'] . ' opted out email addresses on CC. Updated '
				. $updateResult['sugar_optouts'] . ' records in Sugar.'));
	}

	public function action_membership_report() {
	    $GLOBALS['log']->info("[fbsg_cci][fbsg_ConstantContactIntegrationController][action_membership_report]");
		$this->view = null;
		ob_clean();
		SugarCCMass::ListMembershipReport('contacts');
	}

    public function action_update_sync_sent_results() {
        $syncSent = $_REQUEST['sync_sent'] === 'true' ? 1 : 0;
        $cc = SugarCC::GetOnlyCC();

        if($cc) {
            $cc->sync_sent_results = $syncSent;
            $cc->save();
        }
    }
}
