<?php
class CCActivity {
	var $Type;
	var $Status;
	var $FileName;
	var $utility;
	function __construct($u) {
		$this->utility = $u;
	}
	public function GetByCCID($ccid) {
		$response = $this->utility->GetData($ccid);
		if ($response['status'] < 400) {
			return $this->FromXML($response['data']);
		} else {
			return false;
		}
	}
	public function FromXML($xml) {
        $xml = CCXml::ParseXml($xml);
        if($xml == null) return null;

		$ret = new CCActivity($this->utility);
		$aroot = $xml->content->Activity;
		$ret->Type = (string) $aroot->Type;
		$ret->Status = (string) $aroot->Status;
		$ret->FileName = 'http://api.constantcontact.com' . urldecode((string) $aroot->FileName);
		return $ret;
	}
	public function GetFile() {
		if ($this->Status === 'COMPLETE' && $this->FileName) {
			$response = $this->utility->GetData($this->FileName);
			if ($response['status'] < 400) {
				return $response['data'];
			}
		}
		return false;
	}
	public function CreateAddContactActivity($activityText) {
		$url = $this->utility->web_service_base . 'customers/' . $this->utility->username . '/activities';
		$response = $this->utility->Post($url, $activityText, 'application/x-www-form-urlencoded');
		return $response;
	}
	/**
	 * Creates contact list export activities in ConstantContact.
	 *
	 * For each prospect list id passed to this method, a new contact export
	 * request is made to CC.
	 *
	 * @param array $listIDs        	
	 * @param array $columns        	
	 * @return multitype:unknown
	 */
	public function CreateExportJobs($listIDs, $columns = array('FIRST NAME', 'LAST NAME',
                                         'WORK PHONE', 'HOME PHONE', 'ADDRESS LINE 1',
                                         'CITY', 'STATE/PROVINCE (US/CANADA)', 'COUNTRY', 'POSTAL CODE')) {
		$url = $this->utility->web_service_base . 'customers/' . $this->utility->username . '/activities';
		$responses = array();
		$columnsEncoded = '';
		foreach ($columns as $column) {
			$columnsEncoded .= '&columns=' . urlencode($column);
		}
		foreach ($listIDs as $list) {
			$postdata = 'activityType=EXPORT_CONTACTS&fileType=CSV&exportOptDate=false' . '&exportOptSource=false&exportListName=false&sortBy=DATE_DESC' . $columnsEncoded . '&listId=' . urlencode($list);
			$response = $this->utility->Post($url, $postdata, 'application/x-www-form-urlencoded');
			$responses[] = $response;
		}
		return $responses;
	}
}
