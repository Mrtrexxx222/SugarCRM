<?php
class CCBasic implements CCConnector {

    var $username;
    var $consumer_key = '6aaeb9a5-8e0a-4b4f-8a67-58db1cf8cab7';
    var $cc_base_url = 'http://api.constantcontact.com';
    var $web_service_base = 'http://api.constantcontact.com/ws/';
    var $useSSL = true;
    private $password;

    function __construct($u, $p, $ssl = true, $enc = true) {
        $this->username = $u;
        $this->SetPassword($p, $enc);
        $this->useSSL = $ssl;
    }

    protected function GetPassword() {
        return $this->password;
    }

    protected function SetPassword($value, $enc = true) {
        $this->password = $enc
            ? blowfishDecode(blowfishGetKey('encrypt_field'), $value)
            : $value;
    }
    
    /**
     *
     * @param string $type Endpoint type; e.g. 'activities' or 'contacts'
     * @return type 
     */
    public function GetEndpoint($type, $id=null) {
        if ($id === null) {
            return $this->web_service_base . 'customers/'.$this->username.'/'.$type;
        } else {
            return $this->web_service_base . 'customers/'.$this->username.'/'.$type.'/'.$id;
        }
    }

    public function GetData($endpoint, $params = array()) {
        return $this->request($endpoint.'?'.http_build_query($params), 'GET');
    }

    public function Post($endpoint, $postData, $contentType = 'application/atom+xml;type=entry') {
        //$GLOBALS['log']->fatal("[Utility][Post] endpoint: {$endpoint} postData: {$postData}");
        return $this->request($endpoint, 'POST', $postData, $contentType);
    }

    public function Put($endpoint, $postData, $contentType = 'application/atom+xml;type=entry') {
        return $this->request($endpoint, 'PUT', $postData, $contentType);
    }

    private function GetRequestLogin() {
        return $this->consumer_key .
        "%" . $this->username .
        ":" . $this->GetPassword();
    }

    private function request($url, $type, $postdata = array(), $contentType = 'application/atom+xml;type=entry') {
        $login = $this->GetRequestLogin();
        if ($this->useSSL) {
            $url = str_replace('http:', 'https:', trim($url));
        }
        if(substr($url, strlen($url)-1, 1) == '?') {
            $url = substr($url, 0, strlen($url)-1);
        }
        $session = curl_init($url);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($session, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($session, CURLOPT_USERPWD, $login);
        if ($this->useSSL) {
            curl_setopt($session, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($session, CURLOPT_SSL_VERIFYHOST, 0);
        }

        if ($type === 'POST') {
            curl_setopt($session, CURLOPT_POST, 1);
            curl_setopt($session, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($session, CURLOPT_HTTPHEADER, array('Content-Type: ' . $contentType,
                'Content-Length: ' . strlen($postdata)));
        } else if ($type === 'PUT') {
            CCLog::Log('PUT data: ' . $postdata, 'debug');
            curl_setopt($session, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($session, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($session, CURLOPT_HTTPHEADER, array('Content-Type: ' . $contentType));
        } else if($type === 'GET') {
            
        }
        $response = curl_exec($session);
        $ret = '';
        if (!$response) {
            $ret = array('error' => curl_error($session),
                'status' => curl_getinfo($session, CURLINFO_HTTP_CODE),
                'data' => null);
            if($ret['status'] >= 400) {
                CCLog::Log('CCI Connection Error: ' . print_r($ret, true), 'fatal');
            }
        } else {
            $ret = array('error' => null,
                'status' => curl_getinfo($session, CURLINFO_HTTP_CODE),
                'data' => $response);
            if($ret['status'] >= 400) {
                CCLog::Log('CCI Error: ' . print_r($ret, true) . "'$url'", 'fatal');
                if($postdata) {
                    CCLog::Log('Attempted ' . $type . ': ' . $postdata, 'fatal');
                }
            }
        }
        curl_close($session);
        return $ret;
    }

}
?>
