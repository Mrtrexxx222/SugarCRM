<?php
class CCCampaign {
    var $Name;
    var $Status;
    var $SharePageURL;
    var $Sent;
    var $Opens;
    var $Clicks;
    var $Bounces;
    var $Forwards;
    var $OptOuts;
    var $SpamReports;
    var $ContactLists;
    var $Urls;
    var $cc_id;
    var $utility;
    public function __construct($ut = null) {
        $this->utility = $ut;
    }
    public function FromXML($xml) {
        if (is_string($xml)) {
            try {
                libxml_use_internal_errors(true);
                $dom = new DOMDocument("1.0", "UTF-8");
                $dom->strictErrorChecking = false;
                $dom->validateOnParse = false;
                $dom->recover = true;
                $dom->loadXML($xml);
                $xml = simplexml_import_dom($dom);
            } catch (Exception $e) {
                $encodedXml = base64_encode($xml);
                $GLOBALS['log']->info("[fbsg_cci][CCCampaign][FromXML] {$encodedXml}");
                $GLOBALS['log']->info("[fbsg_cci][CCCampaign][FromXML] XML Error: " . $e->getMessage());
            }
        }
        $cc = new CCCampaign($this->utility);
        $eRoot = $xml->content->Campaign;
        $this->Name = (string) $eRoot->Name;
        $this->Status = (string) $eRoot->Status;
        $this->SharePageURL = (string) $eRoot->SharePageURL;
        $this->Sent = (string) $eRoot->Sent;
        $this->Opens = (string) $eRoot->Opens;
        $this->Clicks = (string) $eRoot->Clicks;
        $this->Bounces = (string) $eRoot->Bounces;
        $this->Forwards = (string) $eRoot->Forwards;
        $this->OptOuts = (string) $eRoot->OptOuts;
        $this->SpamReports = (string) $eRoot->SpamReports;
        $this->Sent = (string) $eRoot->Sent;
        $this->Status = (string) $eRoot->Status;
        $this->cc_id = urldecode((string) $eRoot['id']);
        $this->ContactLists = array();
        $this->Urls = array();
        $CLKids = $eRoot->ContactLists ? $eRoot->ContactLists->children() : array();
        $URLKids = $eRoot->Urls ? $eRoot->Urls->children() : array();
        foreach ($CLKids as $cl) {
            $this->ContactLists[] = urldecode((string) $cl['id']);
        }
        foreach ($URLKids as $u) {
            $this->Urls[(string) $u->Value] = array(
                    'clicks' => (int) $u->Clicks,
                    'url_id' => (string) $u['id']
            );
        }
        return $this;
    }
    public function GetByCCID($ccid) {
        $response = $this->utility->GetData($ccid);
        if ($response['status'] < 400) {
            return $this->FromXML($response['data']);
        } else {
            return false;
        }
    }
    public function Send($method) {
        if ($methods === 'POST') {
            $url = $this->utility->web_service_base . 'customers/' . $this->utility->username . '/campaigns';
            return $this->utility->Post($url, $this->toXMLEntry());
        } else if ($method === 'PUT') {
            return $this->utility->Put($this->cc_id, $this->toXMLEntry());
        } else
            return false;
    }
}
?>