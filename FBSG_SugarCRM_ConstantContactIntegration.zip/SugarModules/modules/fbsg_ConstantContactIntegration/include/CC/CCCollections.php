<?php

/**
 * CCItemCollection
 *
 * Handles the traversal of paged atom collections. Each call to Get returns
 * the next page url, or null if done. The resulting items are stored in the
 * $Items member.
 *
 * The decoder is a class that will parse the 'entry' nodes. This could
 * almost certainly be handled in a generic way, but for now, I'm just writing
 * individual classes for it and injecting the decoder.
 *
 */
class CCItemCollection {
    var $decoder;
    var $utility;
    var $firstRun;
    var $firstURL;
    var $next;
    var $Items;

    public function __construct($u, $dec, $first) {
        $this->utility = $u;
        $this->decoder = $dec;
        $this->firstURL = $first;
        $this->firstRun = true;
        $this->next = null;
        $this->Items = array();
    }

    public function GetData($paged = false, $url = null) {
        if(!is_object($this->utility)) {
            CCLog::Log("No utility assigned in CCListCollection::Get", "debug");
            return null;
        }
        if ($url === null) {
            if (!$paged || $this->firstRun) {
                $url = $this->firstURL;
            } else if ($paged && $this->next) {
                $url = $this->utility->cc_base_url . $this->next;
            } else {
                return null;
            }
        }

        $this->firstRun = false;
        $response = $this->utility->GetData(trim(trim($url), '?'));
        $this->Items = array();
        if ($response['status'] < 400 && !$response['error']) {
            $parsedXML = CCXml::ParseXml($response['data']);
            if($parsedXML === null) return null;

            $links = CCXml::GetLinks($parsedXML);
            $this->next = isset($links['next']) ? $links['next'] : null;
            foreach ($parsedXML->entry as $entry) {
                $decoded = $this->decoder->FromXML($entry, true);

                if($decoded) {
                    $decoded->id = urldecode((string)$parsedXML->id);
                    $this->Items[] = $decoded;
                }
            }
        } else {
            return null;
        }

        return $this->next;
    }
}

/**
 * This guy's a little odd. Campaign events are retrieved as a set of collections.
 * So first thing we do, is retrieve these collections and store them. Then, we
 * keep a separate array to store the url we should request for the next set of
 * records. Once we get it, we store the next one for this collection in that array.
 *
 * Once the next is null, we presume that that collection is finished, and we can
 * move on to the next one. Implementation for this is left to the user of this
 * class (probably a mistake, look at SugarCCCampaign for how this is handled.)
 *
 * Point is, every time you do a Get, the next url is stored for you in the correct
 * part of the array (it is indexed by type, see the $types array)
 */

class CCCampaignEventCollection extends CCItemCollection {
    var $campaignID;
    var $clickURLs;
    var $collections;
    var $nextURLs;

    var $shouldSyncSends = false;

    public static $types = array('clicks', 'bounces', 'sends', 'optouts', 'forwards', 'opens');

    /**
     * The $urls and $cols parameters are present so we can keep track of state
     * across requests, if necessary.
     *
     * @param CCConnector $ut CC communicator
     * @param string $camID Campaign CC ID
     * @param array $urls Array of next urls
     * @param type $cols Array of collections
     */
    public function __construct($ut, $camID, $shouldSyncSends = false, $urls = null, $cols = null) {
        $d = new CCContactEvent('');
        $this->campaignID = $camID;
        if(!empty($urls) && !empty($cols)) {
            $this->nextURLs = $urls;
            $this->collections = $cols;
        }

        $this->shouldSyncSends = $shouldSyncSends;
        parent::__construct($ut, $d, null);
    }

    private function SetEventDetails($type) {
        switch($type) {
        case "clicks":
            $this->decoder->EventNode = "ClickEvent";
            $this->decoder->extraNodes = array();
            break;
        case "bounces":
            $this->decoder->EventNode = "BounceEvent";
            $this->decoder->extraNodes = array('Code', 'Description', 'BounceMessage');
            break;
        case "sends":
            $this->decoder->EventNode = "SentEvent";
            $this->decoder->extraNodes = array();
            break;
        case "optouts":
            $this->decoder->EventNode = "OptoutEvent";
            $this->decoder->extraNodes = array('OptOutSource', 'OptOutReason');
            break;
        case "forwards":
            $this->decoder->EventNode = "ForwardEvent";
            $this->decoder->extraNodes = array();
            break;
        case "opens":
            $this->decoder->EventNode = "OpenEvent";
            $this->decoder->extraNodes = array();
            break;
        }
    }

    /**
     * Gets the next page of the given collection type.
     *
     * Will also get the collections, if necessary.
     *
     * @param string $type Type of collection to pull down
     * @param timestamp $ts
     * @return bool true if more to grab in the given collection, false otherwise
     */
    public function GetData($type = 'clicks', $ts = null, $lastRunCompleted = false) {
        $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] Starting GetData for {$this->campaignID} and type {$type}");

        if(empty($this->nextURLs)) {
            $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] No next URL, so get campaign collection.");
            $this->GetCampaignCollections($this->campaignID);
        }
        $this->SetEventDetails($type);

        if(!empty($this->nextURLs[$type])) {
            $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] Found another URL for type {$type}");
            $baseUrl = $this->nextURLs[$type];
            if(!preg_match('/^https?.*/', $baseUrl)) {
                $url = $this->utility->cc_base_url . $baseUrl;
            } else {
                $url = $baseUrl;
            }
            $this->nextURLs[$type] = parent::GetData(false, $url);
            CCLog::Log("[Constant Contact Integration][CCCampaignEventCollection][Get] url: {$url}", 'debug');
            $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] URL = {$url}");


            if ($this->nextURLs[$type] && $ts && $lastRunCompleted) {
                $lastItem = end($this->Items);
                $itemTime = strtotime($lastItem->EventTime);
                if ($itemTime < $ts) {
                    $this->collections[$type] = null;
                    $this->nextURLs[$type] = null;
                    $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] {$itemTime} < {$ts}");
                    CCLog::Log("[Constant Contact Integration][CCCampaignEventCollection][Get] {$itemTime} < {$ts}", 'debug');
                    return false;
                }
            }

            if(!$this->nextURLs[$type]) {
                array_shift($this->collections[$type]);
                if(count($this->collections[$type]) > 0) {
                    $this->nextURLs[$type] = $this->collections[$type][0];
                }
            }
            $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] Complete.");
            return true;
        } else {
            $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetData] No more URLs for the current type.");
            return false;
        }
    }

    /**
     * Get the set of event collections for the given campaign from CC
     *
     * @param string $ccid Full ccid of a campaign
     * @return array Array of urls of the event collections of the given campaign,
     *               indexed by type.
     *               E.g., [['clicks' => ['/ws/customers/username/campaigns/2341243/events/urls/12352351234/clicks',
     *                                    '/ws/customers/username/campaigns/2341243/events/urls/15151151612/clicks'],
     *                       'bounces' => ['/ws/customers/username/campaigns/2341243/events/bounces'],
     *                       'sends' => ['/ws/customers/username/campaigns/2341243/events/sends'],
     *                       'forwards' => ['/ws/customers/username/campaigns/2341243/events/forwards']]
     *               Etc.
     */
    public function GetCampaignCollections($ccid = null) {
        $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetCampaignCollections] Starting GetCampaignCollections");
        if(!$ccid) {
            if(!$this->campaignID) return;
            $ccid = $this->campaignID;
        }

        $response = $this->utility->GetData($ccid . '/events/');
        $colLinks = array();
        $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetCampaignCollections] Response code: {$response['status']}");
        if($response['status'] < 400) {
            $colXML = CCXml::ParseXml($response['data']);
            if($colXML) {
                foreach($colXML->workspace->collection as $col) {
                    $link = $col['href'];
                    $groups = array();
                    if(preg_match('/^.*\/(\w+)$/', $link, $groups)) {
                        $type = $groups[1];
                        if($type == 'sends' && !$this->shouldSyncSends) continue;

                        $colLinks[$type][] = $this->utility->cc_base_url . (string)$col['href'];
                    }
                }
            }
        }
        $this->collections = $colLinks;
        $this->nextURLs = array();

        foreach($this->collections as $type=>$urls) {
            $this->nextURLs[$type] = count($urls) > 0 ? $urls[0] : '';
        }
        $GLOBALS['log']->info("[fbsg_cci][CCCampaignEventCollection][GetCampaignCollections] Complete");
    }
}

class CCContactEventCollection extends CCItemCollection {
    public function __construct($ut, $ccid, $eventNode, $eventURL,
                                $extraNodes = null) {
        $d = new CCContactEvent($eventNode, $extraNodes);
        $first = $ccid.'/events/'.$eventURL;
        parent::__construct($ut, $d, $first);
    }
}

class CCListMemberCollection extends CCItemCollection {
    var $listCCID;
    public function __construct($ut, $list_cc_id = null) {
        $d = new CCListMember();
        $first = $list_cc_id.'/members';
        $this->listCCID = $list_cc_id;
        parent::__construct($ut, $d, $first);
    }


    public function GetData($paged = false, $url = null) {
        return parent::GetData($paged, $url);
    }
}

class CCListCollection extends CCItemCollection {
    public function __construct($ut) {
        $d = new CCListSummary();
        $first = $ut->GetEndpoint('lists');
        parent::__construct($ut, $d, $first);
    }
}

class CCCampaignCollection extends CCItemCollection {
    public function __construct($ut) {
        $d = new CCCampaignSummary();
        $first = $ut->GetEndpoint('campaigns');
        parent::__construct($ut, $d, $first);
    }
}

class CCActivityCollection extends CCItemCollection {
    public function __construct($ut) {
        $d = new CCActivitySummary();
        $first = $ut->GetEndpoint('activities');
        parent::__construct($ut, $d, $first);
    }
}
?>
