<?php
class CCContact {

    var $Status;
    var $FirstName;
    var $MiddleName;
    var $LastName;
    var $JobTitle;
    var $CompanyName;
    var $EmailType;
    var $EmailAddress;
    var $HomePhone;
    var $WorkPhone;
    var $Addr1;
    var $Addr2;
    var $Addr3;
    var $City;
    var $StateCode;
    var $CountryCode;
    var $CountryName;
    var $PostalCode;
    var $SubPostalCode;
    var $Note;
    var $CustomFields;
    var $ContactLists;
    var $Confirmed;
    var $InsertTime;
    var $LastUpdateTime;
    var $cc_id;

    var $utility;
    var $fetchedXML;

    function __construct($u = null) {
        $this->utility = $u;
        $this->ContactLists = array();
        $this->CustomFields = array();
    }

    /**
     * Make a CCContact from the given XML
     * @param string $rawXML
     * @return CCContact
     */
    public function FromXML($xml) {
        $xml = CCXml::ParseXml($xml);
        if($xml === null) return null;

        $eRoot = $this->XMLContactRoot($xml);
        $cc = new CCContact($this->utility);
        $cc->cc_id = urldecode((string) $eRoot['id']);
        foreach ($eRoot->children() as $child) {
            $name = $child->GetName();
            $match = array();
            if ($name === 'ContactLists') {
                $cc->ContactLists = $this->GetListIDs($child);
            } else if (preg_match('/^CustomField(?P<digit>[\d]{1,2})$/', $name, $match)) {
                $cc->CustomFields[$match['digit']] = (string) $child;
            } else {
                $cc->$name = (string) $child;
            }
        }
        return $cc;
    }

    /**
     * Turn this contact into an atom entry in CC format
     * @return SimpleXMLElement
     */
    public function toXMLEntry() {
        $entry = CCAtom::GenerateAtom('Contact', $this->cc_id);         
        $objArray = (array) $this;
        $Contact = $entry->content->Contact;
        foreach ($objArray as $key => $value) {
            if ($key === 'CustomFields') {
                foreach ($this->CustomFields as $k => $v) {
                    $Contact->addChild('CustomField' . $k, $v);
                }
            } else if ($key === 'ContactLists') {
                $lists = $Contact->addChild('ContactLists');
                foreach ($value as $list) {
                    $listEntry = $lists->addChild('ContactList', '');
                    $listEntry->addAttribute('id', $list);
                }
            } else if ($key !== 'fetchedXML' && 
                       $key !== 'cc_id' && 
                       $key !== 'utility' && 
                       $value != null) {
                $Contact->addChild($key, $value);
            }
        }
        $Contact->addChild('OptInSource', 'ACTION_BY_CUSTOMER');
        return $entry->asXML();
    }

    /**
     * Get the contact with the given CCID from CC.
     * @param string $ccid
     * @return mixed A CCContact of the returned contact, false otherwise.
     */
    public function GetByCCID($ccid, $rawXML = false) {
        $response = $this->utility->GetData($ccid);
        if ($response['status'] < 400) {
            $xml = $response['data'];
            if($rawXML) {
                return $xml;
            } else {
                $con = $this->FromXML($response['data']);
                $con->fetchedXML = $xml;
                return $con;
            }
        } else {
            return false;
        }
    }

    /**
     * Search CC for a contact with the given email address, and fetch it.
     *
     * @param string $email
     * @return mixed The contact found by CC as a CCContact, false otherwise
     */
    public function GetByEmail($email, $rawXML = false) {
        $url = $this->utility->web_service_base . 'customers/' .
                $this->utility->username . '/contacts?email=' . $email;
        $response = $this->utility->GetData($url);
        if ($response['status'] >= 400) {
            return false;
        }
        $xml = CCXml::ParseXml($response['data']);
        
        if($xml === null) return false;
        else {
            $uri = $xml->entry->id;
            $uri = urldecode($uri);
            return $this->GetByCCID($uri, $rawXML);
        }
    }

    /**
     * Send this contact to CC
     * @param string $method POST or PUT
     * @return mixed Response from $utility's POST or PUT method, or false on error.
     */
    public function Send($method) {
        if ($method === 'POST') {
            $url = $this->utility->web_service_base . 'customers/' .
                    $this->utility->username . '/contacts';
            return $this->utility->Post($url, $this->toXMLEntry());
        } else if ($method === 'PUT') {
            return $this->utility->Put($this->cc_id, $this->toXMLEntry());
        }
        else
            return false;
    }

    private function XMLContactRoot($xmlElement) {
        if ($xmlElement->entry)
            return $xmlElement->entry->content->Contact;
        else
            return $xmlElement->content->Contact;
    }

    /**
     * Get an array of the list ids from the ContactLists xml root
     * @param $xml SimpleXMLElement of the ContactLists root
     * @return array URL decoded cc list ids
     */
    private function GetListIDs($xml) {
        $clists = array();
        foreach ($xml as $cl) {
            $clists[] = urldecode((string) $cl['id']);
        }
        return $clists;
    }
}
?>