<?php
class CCList {
    var $OptInDefault;
    var $Name;
    var $ShortName;
    var $SortOrder;
    var $ContactCount;

    var $utility;
    var $cc_id;

    var $fetchedXML;

    function __construct($u = null) {
        $this->utility = $u;
    }

    public function FromXML($xml, $generate = false) {
        $xml = CCXml::ParseXml($xml);
        if($xml === null) return null;

        $eRoot = $xml->content->ContactList;
        if($generate) {
            $cc = $this;
        } else {
            $cc = new CCList($this->utility);
            $this->cc_id = urldecode((string)$eRoot['id']);
        }
        $cc->cc_id = urldecode((string)$eRoot['id']);

        $this->OptInDefault = (string)$eRoot->OptInDefault;
        $this->Name = (string)$eRoot->Name;
        $this->ShortName = (string)$eRoot->ShortName;
        $this->SortOrder = (string)$eRoot->SortOrder;
        $this->ContactCount = (string)$eRoot->ContactCount;
        return $cc;
    }

    public function toXMLEntry() {
        $entry = CCAtom::GenerateAtom('ContactList', $this->cc_id);

        $list = $entry->content->ContactList;

        $list->addChild('OptInDefault', $this->OptInDefault);
        $list->addChild('Name', $this->Name);
        $list->addChild('ShortName', $this->ShortName);
        $list->addChild('SortOrder', $this->SortOrder);

        return $entry;
    }

    public function GetByCCID($ccid, $rawXML = false) {
        $response = $this->utility->GetData($ccid);
        if($response['status'] < 400) {
            $xml = $response['data'];
            if($rawXML) {
                return $xml;
            } else {
                $list = $this->FromXML($xml);
                $list->fetchedXML = $xml;
                return $list;
            }
        }
    }

    public function UpdateFetchedXML() {
        if(empty($this->fetchedXML)) {
            CCLog::Log('No xml fetched before attempting PUT for cc_id ' 
                     . $this->cc_id, "fatal");
            return null;
        } else {
            $fetched = CCXml::ParseXml($this->fetchedXML);
            if($fetched === null) return null;

            $fetched->content->ContactList->OptInDefault = array($this->OptInDefault);
            $fetched->content->ContactList->Name = array($this->Name);
            $fetched->content->ContactList->ShortName = array($this->ShortName);
            $fetched->content->ContactList->SortOrder = array($this->SortOrder);
            $fetched->content->ContactList->ContactCount = array($this->ContactCount);
            return $fetched->asXML();
        }
    }

    public function Send($method) {
        if($method === 'POST') {
            $url = $this->utility->web_service_base . 'customers/'
                . $this->utility->username . '/lists';
            $xml = $this->toXMLEntry();
            return $this->utility->Post($url, $xml->asXML());
        } else if($method === 'PUT') {
            $xml = $this->UpdateFetchedXML();
            
            return empty($xml) ? false 
                               : $this->utility->Put($this->cc_id, $xml);
        }
        else return false;
    }
}
?>