<?php
class CCListMember implements CCXmlParser {
    var $Email;
    var $Name;
    var $cc_id;
    
    public function __construct() {
        
    }
    
    public function FromXML($entry, $generate = false) {
        $entry = CCXml::ParseXml($entry);
        if($generate) {
            $item = new CCListMember();
        } else {
            $item = $this;
        }
        $member = $entry->content->ContactListMember;
        $item->Email = (string)$member->EmailAddress;
        $item->Name = (string)$member->Name;
        $item->cc_id = (string)$member['id'];
        return $item;
    }
}

class CCContactEvent implements CCXmlParser {
    var $campaignCCID;
    var $contactCCID;
    var $Email;
    var $EventNode;
    var $EventTime;
    var $extraNodes;
    var $id;
    
    /**
     *
     * @param string $en Name of the event node to grab (e.g., ClickEvent)
     * @param array $extraNodes Extra information to grab from the event
     *                          e.g., array('LinkUrl', 'EventTime')
     *                          Nodes relative to the $en
     */
    public function __construct($en, $extraNodes = null) {
        $this->EventNode = $en;
        $this->extraNodes = $extraNodes;
    }
    
    public function FromXML($entry, $generate = false) {
        $entry = CCXml::ParseXml($entry);
        if($generate) {
            $item = new CCContactEvent($this->EventNode, $this->extraNodes);
        } else {
            $item = $this;
        }
        $en = $this->EventNode;
        $member = $entry->content->$en;
        $contact = $member->Contact;
        $campaign = $member->Campaign;
        if(!$contact || !$campaign) {
            return null;
        }
        $item->campaignCCID = urldecode((string)$campaign['id']);
        $item->contactCCID = urldecode((string)$contact['id']);
        $item->Email = (string)$contact->EmailAddress;
        $item->EventTime = (string)$member->EventTime;
        if($this->extraNodes !== null) {
            foreach($this->extraNodes as $node) {
                $item->$node = (string)$member->$node;
            }
        }
        
        return $item;
    }
}

class CCListSummary implements CCXmlParser {
    var $Name;
    var $ShortName;
    var $SortOrder;
    var $OptInDefault;
    var $cc_id;
    
    public function __construct($t = null, $i = null) {
        $this->title = $t;
        $this->id = $i;
    }
    
    public function FromXML($entry, $generate = false) {
        $entry = CCXml::ParseXml($entry);
        if($generate) {
            $item = new CCListMember();
        } else {
            $item = $this;
        }
        $list = $entry->content->ContactList;
        $item->cc_id = (string)$list['id'];
        $item->Name = (string)$list->Name;
        $item->ShortName = (string)$list->ShortName;
        $item->SortOrder = (string)$list->SortOrder;
        $item->OptInDefault = (string)$list->OptInDefault;
        return $item;
    }
}

class CCCampaignSummary implements CCXmlParser {

    var $Name;
    var $Status;
    var $Date;
    var $cc_id;

    /**
     * Makes a CCCampaignSummary from the passed in XML.
     * @param SimpleXMLElement $xml The xml root of the entry element for the 
     *        campaign collection summary
     */
    public function FromXML($xml, $generate = false) {
        $xml = CCXml::ParseXml($xml);
        if($generate) {
            $cc = new CCCampaignSummary();
        } else {
            $cc = $this;
        }
        $root = $xml->content->Campaign;
        $cc->Name = (string) $root->Name;
        $cc->Status = (string) $root->Status;
        $cc->Date = (string) $root->Date;
        $cc->cc_id = urldecode((string) $root['id']);
        return $cc;
    }

}

class CCCampaignEvent implements CCXmlParser {
    var $contactID;
    var $campaignID;
    var $eventTime;
    var $type;
    
    public function FromXML($xml, $generate = false) {
        $xml = CCXml::ParseXml($xml);
        if($generate) {
            $cc = new CCCampaignEvent();
        } else {
            $cc = $this;
        }
        if(isset($xml->content->$type)) {
            $root = $xml->content->$type;
            $cc->contactID = urldecode((string)$root->Contact['id']);
            $cc->campaignID = urldecode((string)$root->Campaign['id']);
            $cc->eventTime = (string)$root->EventTime;
        }
        return $cc;
    }
}

class CCActivitySummary implements CCXmlParser {
    var $actID;
    var $Type;
    var $Status;
    var $TransactionCount;
    var $Errors;
    var $RunStartTime;
    var $RunFinishTime;
    var $InsertTime;
    
    public function FromXML($xml, $generate = false) {
        $xml = CCXml::ParseXml($xml);
        
        if($generate) {
            $cc = new CCActivitySummary();
        } else {
            $cc = $this;
        }
        
        if(isset($xml->content->Activity)) {
            $root = $xml->content->Activity;
            $cc->actID = (string)$root['id'];
            $cc->Type = (string)$root->Type;
            $cc->Status = (string)$root->Status;
            $cc->TransactionCount = (string)$root->TransactionCount;
            $cc->Errors = (string)$root->Errors;
            $cc->RunStartTime = (string)$root->RunStartTime;
            $cc->RunFinishTime = (string)$root->RunFinishTime;
            $cc->InsertTime = (string)$root->InsertTime;
        }
        return $cc;
    }
}
