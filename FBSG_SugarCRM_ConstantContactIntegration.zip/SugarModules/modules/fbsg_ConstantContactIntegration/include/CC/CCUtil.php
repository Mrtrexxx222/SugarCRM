<?php
class CCAtom {
    public static function GenerateAtom($entryType, $cc_id = '') {
        $entry = new SimpleXMLElement('<entry></entry>');
        $entry->addAttribute('xmlns', 'http://www.w3.org/2005/Atom');
        $id = $entry->addChild('id', $cc_id ? trim($cc_id) : 'data:,none');

        $title = $entry->addChild('title', '');
        $title->addAttribute('type', 'text');

        $entry->addChild('author', '');
        $updated = $entry->addChild('updated', '2011-02-05T14:21:06.407Z');
        $content = $entry->addChild('content');
        $content->addAttribute('type', 'application/vnd.ctct+xml');

        if(!empty($entryType)) {
            $item = $content->addChild($entryType);
            $item->addAttribute('xmlns', 'http://ws.constantcontact.com/ns/1.0/');

            if($cc_id) {
                $item->addAttribute('id', $cc_id);
            }
        }

        return $entry;
    }
}
        

class CCXml {
    public static function GetLinks($atom) {
        $atom = CCXml::ParseXml($atom);

        $links = array();
        if(!isset($atom->link)) return $links;

        foreach($atom->link as $link) {
            if($link['rel']) {
                $links[urldecode((string)$link['rel'])] = urldecode((string)$link['href']);
            }
        }
        return $links;
    }

    public static function ParseXml($xml) {
        if(empty($xml)) return null;
        if($xml instanceof SimpleXMLElement) return $xml;
        if(!is_string($xml)) {
            $GLOBALS['log']->fatal("Invalid type passed to CCXml::ParseXML: " . gettype($xml));
            try {
                throw new Exception();
            } catch(Exception $ex) {
                $GLOBALS['log']->fatal("Stack trace: " . $ex->getTraceAsString());
            }
            return null;
        }

        try {
            libxml_use_internal_errors(true);
            $dom = new DOMDocument("1.0", "UTF-8");
            $dom->strictErrorChecking = false;
            $dom->validateOnParse = false;
            $dom->recover = true;
            $dom->loadXML($xml);
            return simplexml_import_dom($dom);
        } catch(Exception $ex) {
            global $log;
            $encodedXml = base64_encode($xml);
            $log->info("[fbsg_cci][CCUtil][ParseXml] {$encodedXml}");
            $log->info("[fbsg_cci][CCUtil][ParseXml] XML Error: " . $e->getMessage());
            return null;
        }
    }
}

class CCLog {
    public static function Log($message, $level = 'debug') {
    	//log to the DB
    	$log = new fbsg_CCIErrors();
    	$log->name = substr($message, 0, 255);
        $log->message = htmlentities($message);
    	$log->log_level = $level;
    	$log->save();
    	 
    	//also log to the standard sugar log.
        switch($level) {
            case 'debug':
                $GLOBALS['log']->debug($message);
                break;
            case 'error':
                $GLOBALS['log']->error($message);
                break;
            case 'fatal':
                $GLOBALS['log']->fatal($message);
                break;
            case 'warn':
                $GLOBALS['log']->warn($message);
                break;
            case 'info':
                $GLOBALS['log']->info($message);
                break;
        }
    }
}
