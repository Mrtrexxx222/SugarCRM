<?php
interface CCConnector {

    function Post($endpoint, $postData, $contentType = 'application/atom+xml;type=entry');

    function Put($endpoint, $putData, $contentType = 'application/atom+xml;type=entry');

    function GetData($endpoint, $params = array());

    function GetEndpoint($type, $id = null);
}

interface CCXMLParser {
    public function FromXML($entry, $generate = false);
}
?>