<?php
global $beanFiles;
require_once($beanFiles['Contact']);
require_once($beanFiles['Lead']);
require_once($beanFiles['Campaign']);
require_once($beanFiles['fbsg_ConstantContactIntegration']);
require_once($beanFiles['fbsg_CCIntegrationLog']);

$cdir = 'modules/fbsg_ConstantContactIntegration/include';

require_once($cdir.'/CC/Interfaces.php');
require_once($cdir.'/CC/CCUtil.php');
require_once($cdir.'/CC/CCBasic.php');
require_once($cdir.'/CC/CCActivity.php');
require_once($cdir.'/CC/CCCampaign.php');
require_once($cdir.'/CC/CCCollections.php');
require_once($cdir.'/CC/CCContact.php');
require_once($cdir.'/CC/CCList.php');
require_once($cdir.'/CC/CCSummaries.php');

require_once($cdir.'/SugarCC/SugarCC.php');
require_once($cdir.'/SugarCC/SugarCCList.php');
require_once($cdir.'/SugarCC/SugarCCCampaign.php');
require_once($cdir.'/SugarCC/SugarCCPerson.php');
require_once($cdir.'/SugarCC/SugarCCActivity.php');
require_once($cdir.'/SugarCC/SugarCCMass.php');
require_once($cdir.'/SugarCC/SugarIncrementalSync.php');