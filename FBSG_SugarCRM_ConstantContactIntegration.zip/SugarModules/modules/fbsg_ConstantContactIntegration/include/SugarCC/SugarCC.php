<?php
class SugarCC {
	/**
	 * Transform the given date, in Y-m-d format, to db format.
	 */
	public static function GetSugarDate($date, $format = 'Y-m-d') {
		$dt = $GLOBALS['timedate'];
		$df = $GLOBALS['current_user']->getUserDateTimePreferences();
		$df = $df['date'];
		return $dt->swap_formats($date, $format, $df);
	}
	public static function GetOnlyCC() {
		$cc = new fbsg_ConstantContactIntegration();
		$list = $cc->get_full_list('');
		if (count($list) > 0) {
			$cc = $list[0];
			if(!$cc->last_auto_update) {
				$cc->last_auto_update = $GLOBALS['timedate']->now();
			}
			return $cc->t() ? $list[0] : null;
		} else {
			return null;
		}
	}
	public static function GetOnlyCCUtility() {
		$cc = SugarCC::GetOnlyCC();
		if (! $cc) {
			return null;
		} else {
			return new CCBasic($cc->name, $cc->password);
		}
	}
	
	/**
	 * Get the Sugar fbsg_ConstantContactIntegration instance with the given
	 * user name.
	 * NOTE: Does not check for the validity of the product key.
	 * 
	 * @global DBHelper $db
	 * @param string $name
	 *        	Constant Contact user name
	 * @return mixed fbsg_ConstantContactIntegration if successful, null
	 *         otherwise.
	 */
	public static function GetSugarCCFromName($name) {
		global $db;
		$cc = new fbsg_ConstantContactIntegration();
		$list = $cc->get_full_list('', "fbsgcci.name = '" . $db->quote(urldecode($name)) . "'");
		if (count($list) > 0) {
			return $cc->retrieve($list[0]->id);
		} else {
			return null;
		}
	}
	
	public static function ExplodeCaretDelimited($cds) {
		$items = explode('^,^', $cds);
		foreach ($items as $i => $item) {
			$items[$i] = trim($item, '^');
		}
		return $items;
	}
	
	/**
	 * Test the credentials associated with this account.
	 * 
	 * @return bool True if successful, false otherwise.
	 */
	public static function TestAccount($ut) {
		$url = $ut->web_service_base . 'customers/' . $ut->username . '/contacts';
		$response = $ut->GetData($url);
		
		if ($response['status'] < 400) {
			return true;
		}
		return false;
	}
}
?>