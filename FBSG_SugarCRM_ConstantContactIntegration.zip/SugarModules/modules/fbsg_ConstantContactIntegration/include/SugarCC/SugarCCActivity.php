<?php
class SugarCCActivity {
    /*
     * Create a url-encoded CSV row for the given person ID.
     * 
     * All fields from the given table, and the primary email address, available for the $columns array.
     * 
     * @param $sConId string ID of the Sugar person
     * @param $table string Database table the person lives in. This is not sanitized, so do not pass any
     *                      user-controlled data.
     * @param $columns Array Associative array. Key is the Sugar field name, value is the CC field name.
     * 
     * @return string url-encoded CSV row from the retrieved person record, null if nothing retrieved in the query.
     */
    private static function ContactToFormEncodedFromId($sConId, $table, $columns) {
        global $db;
        $sConId = $db->quote($sConId);
        $query = "select p.*, ea.email_address email1 from " . $table . " p inner join email_addr_bean_rel eabr on p.id = eabr.bean_id and eabr.bean_module = '".ucwords($table)."' and eabr.deleted = 0 inner join email_addresses ea on ea.id = eabr.email_address_id and eabr.primary_address = 1 and ea.deleted = 0 where p.id = '$sConId' and p.deleted = 0";
        $results = $db->query($query);

        if($sCon = $db->fetchByAssoc($results)) {
            return self::ActivityDataFromArray($sCon, $table, $columns);
        }
        return null;
    }

    private static function ActivityDataFromArray($sCon, $table, $columns) {
        $sugarKeys = array();
        if($table === 'accounts') {
            $email = 'email1';
            $zip = 'billing_address_postalcode';
            $street = 'billing_address_street';
            $state = 'billing_address_state';
            $colIndex = 'company';
        } else { //TODO: Make this not presume a person table
            $email = 'email1';
            $zip = 'primary_address_postalcode';
            $street = 'primary_address_street';
            $state = 'primary_address_state';
            $colIndex = 'person';
        }

        $primZip = explode('-', $sCon[$zip]);
        $primZip = $primZip[0];

        foreach($columns[$colIndex] as $k => $v) {
            $addedValue = '';
            if($k === $email) {
                $addedValue = $sCon[$email];
            } else if($k === $zip) {
                $addedValue = $primZip;
            } else if($k === $street) {
                $streetValue = preg_split('/[\n\r]+/', $sCon[$street]);
                $addedValue = $streetValue[0];
            } else if($k === $state) {
                $addedValue = (strlen($sCon[$k]) === 2 ? $sCon[$k] : '');
            } else if(!$v || !isset($sCon[$k])) {
                $addedValue = '';
            } else {
                $addedValue = $sCon[$k];
            }
            
            //Wrap in quotes, if necessary
            if(strpos($addedValue, ",")) {
                $addedValue = '"' . str_replace('"', '', $addedValue) . '"';
            }
            
            $sugarKeys[] = $addedValue;

        }
        return urlencode(implode(',', $sugarKeys));
    }

    private static function encodeColumns($columns) {
        $values = array();
        foreach ($columns as $k => $v) {
            $values[] = $v;
        }
        return urlencode(implode(',', $values));
    }
    
    public static function createAddContactsActivity($sIDs, $listCCID,
        $columns = array('company' => array('email1' => 'Email address'), 'person' => array('email1' => 'Email Address'))) {

        global $db;
        $postdata = 'activityType=ADD_CONTACTS&data=' . self::encodeColumns($columns['person']) . '%0A';
        $modified = false;
        
        foreach($sIDs as $sID) {
            if($sID['type'] === 'C') {
                $table = 'contacts';
            } else if($sID['type'] === 'L') {
                $table = 'leads';
            } else if($sID['type'] === 'P') {
                $table = 'prospects';
            } else if($sID['type'] === 'A') {
                $table = 'accounts';
            } else {
                CCLog::Log('CCI Error: createAddContactsActivity: incorrect type passed', 'fatal');
                return null;
            }
            $nextEncodedContact = self::ContactToFormEncodedFromId($sID['id'], $table, $columns);
            if($nextEncodedContact !== null) {
                $postdata .= $nextEncodedContact . '%0A';
                $modified = true;
            }
        }
        
        $postdata = substr($postdata, 0, strlen($postdata) - 3) . '&lists=' . urlencode($listCCID);
        return $modified ? $postdata : null;
    }

    public static function createRemoveContactsActivity($sIDs, $listCCID, 
        $columns = array('company' => array('email1' => 'Email address'), 'person' => array('email1' => 'Email Address'))) {
        global $db;
        $postdata = 'activityType=REMOVE_CONTACTS_FROM_LISTS&data=' . self::encodeColumns($columns['person']) . '%0A';
        $modified = false;

        foreach($sIDs as $sID) {
            if($sID['type'] === 'C') {
                $table = 'contacts';
            } else if($sID['type'] === 'L') {
                $table = 'leads';
            } else if($sID['type'] === 'P') {
                $table = 'prospects';
            } else if($sID['type'] === 'A') {
                $table = 'accounts';
            } else {
                CCLog::Log('CCI Error: createRemoveContactsActivity: incorrect type passed', 'fatal');
                return null;
            }

            $nextEncodedContact = self::ContactToFormEncodedFromId($sID['id'], $table, $columns);
            if($nextEncodedContact !== null) {
                $postdata .= $nextEncodedContact . '%0A';
                $modified = true;
            }
        }

        $postdata = substr($postdata, 0, strlen($postdata) - 3) . '&lists=' . urlencode($listCCID);
        return $modified ? $postdata : null;
    }

    public function checkActivityStatus() {
         global $db;
         $responses = Array();
         $completed_activities = Array();
         $sugarCC = SugarCC::GetOnlyCC();
         $utility = new CCBasic($sugarCC->name, $sugarCC->password);
         $query = 'SELECT * FROM csync_cc_sync_activities WHERE csync_cc_sync_activities.processed=0';
         $result = $db->query($query);
         while ($row = $db->fetchByAssoc($result)) {
             $responses[] = Array(
                 'get' => $utility->GetData($row['activity_id']),
                 'list_id' => $row['list_id'],
             );
         } 
         foreach ($responses as $response) {
             if ($response['get']['status'] >= 300) {
                 CCLog::Log('checkActivityStatus HTML Status: ' . $response['get']['status'], 'fatal');
             } else if ($response['get']['error']) {
                 CCLog::Log('checkActivityStatus CURL Error: ' . $response['get']['error'], 'fatal');
             } else {
                 $xml = new SimpleXMLElement($response['get']['data']);
                 if ($xml->content->Activity->Status == "COMPLETE") {
                     $query = 'UPDATE csync_cc_sync_activities SET csync_cc_sync_activities.processed=1 WHERE csync_cc_sync_activities.activity_id=\'' . $xml->id . '\'';
                     $db->query($query);
                     $completed_activities[] = Array(
                         'url' => $utility->cc_base_url . $xml->content->Activity->FileName,
                         'list_id' => $response['list_id'],
                     );
                 }
             }
         }
         
         return $completed_activities;
     }
     public function exportAllContacts() {
         global $db;
         $query = "TRUNCATE TABLE csync_cc_sync_table";
         $db->query($query);
         $query = "TRUNCATE TABLE csync_cc_sync_activities";
         $db->query($query);
         
         $sugarCC = SugarCC::GetOnlyCC();
         $utility = new CCBasic($sugarCC->name, $sugarCC->password);
         $export_activity = new CCActivity($utility);
         $ccLists = SugarCCList::GetAllCCLists();
         $responses = $export_activity->CreateExportJobs($ccLists);
         $count = 0;
         
         if (count($responses) != count($ccLists)) {
             CCLog::Log('CreateExportJobs Lists sync error', 'fatal');
             return (-1);
         }
         
         foreach ($responses as $response) {
             if ($response['error']) {
                 CCLog::Log('CreateExportJobs CURL Error: ' . $response['error'], 'fatal');
             } else if ($response['status'] != 201) {
                 CCLog::Log('CreateExportJobs Status Error: ' . $response['status'], 'fatal');
             } else {
                 $temp_xml_arr = new SimpleXMLElement($response['data']);
                 if ($temp_xml_arr->Errors) {
                     CCLog::Log('CreateExportJobs Errors: '. $temp_xml_arr->Errors, 'fatal');
                 } else {
                     $query = 'INSERT INTO csync_cc_sync_activities (id, activity_id, processed, list_id) VALUES (' . $db->quoted(create_guid()) . ',' . $db->quoted($temp_xml_arr->id) . ', \'0\',  '. $db->quoted($ccLists[$count]) . ')';
                     $db->query($query);
                 }                
             }
             $count++;
         }
         
         return ($count);
     }
}
