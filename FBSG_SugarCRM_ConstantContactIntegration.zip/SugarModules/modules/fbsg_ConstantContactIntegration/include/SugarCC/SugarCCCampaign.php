<?php
class SugarCCCampaign {
    var $utility;

    public function __construct($ut = null) {
        $this->utility = $ut;
    }

    public function UpdateCampaign($ccID) {
        require_once('modules/ProspectLists/ProspectList.php');
        global $db;
        $camSeed = new Campaign();
        $proSeed = new ProspectList();
        $cams = $camSeed->get_full_list('', 'campaigns.cc_id = \'' . $db->quote($ccID) . '\'');
        $cam = new Campaign();

        if(count($cams) > 0) {
            $cam = $cams[0];
        } else {
            return false;
        }

        $ccCampaign = new CCCampaign($this->utility);
        $ccCampaign->GetByCCID($ccID);
        if(!$ccCampaign) { return false; }

        $cam->content = "Constant Contact Campaign Status: " . $ccCampaign->Status;
        $cam->refer_url = $ccCampaign->SharePageURL;
        $cam->campaign_type = "Email";
        $cam->sent = $ccCampaign->Sent;
        $cam->opens = $ccCampaign->Opens;
        $cam->clicks = $ccCampaign->Clicks;
        $cam->bounces = $ccCampaign->Bounces;
        $cam->forwards = $ccCampaign->Forwards;
        $cam->optouts = $ccCampaign->OptOuts;
        $cam->spamreports = $ccCampaign->SpamReports;
        $cam->impressions = $ccCampaign->Sent;
        $cam->status = $ccCampaign->Status == 'Sent' ? 'Complete' : 'Planning';
        $cam->save();
        $this->AddCampaignTrackers($ccCampaign, $cam);
        foreach($ccCampaign->ContactLists as $ccList) {
            $plid = $this->GetPLIDByCCID($ccList);
            if($plid) {
                $cam->load_relationship('prospectlists');
                $cam->prospectlists->add($plid);
            }
        }
        return $cam;
    }

    public function GetCampaigns() {
        require_once('modules/Campaigns/Campaign.php');
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] . Starting GetCampaigns");
        $ccLists = new SugarCCList($this->utility);
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] . Starting to create prospect lists.");
        $ccLists->CreateProspectLists();
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] Finished creating prospect lists.");
        $CCCampaigns = new CCCampaignCollection($this->utility);
        $ccIDs = array();
        $success = false;
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] Creating campaign list object, and proceeding to get the campaign data from CC.");
        //do {
            $continue = $CCCampaigns->GetData(true);
            $success = true;
            foreach($CCCampaigns->Items as $campaign) {
                $ccIDs[] = $campaign->cc_id;
                $cam = new Campaign();
                $camList = $cam->get_list('', 'campaigns.cc_id = \'' . urldecode($campaign->cc_id) . '\'');

                if (count($camList['list']) > 0) {
                    $cam = $camList['list'][0];
                }
                $cam->name = $cam->name ? $cam->name : $campaign->Name;
                $cam->start_date = SugarCC::GetSugarDate(substr($campaign->Date, 0, strpos($campaign->Date, 'T')));
                $cam->end_date = $cam->start_date;
                $cam->cc_id = $campaign->cc_id;
                $cam->save();
                $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] Saved campaign {$cam->name}.");
            }
        //} while($continue);
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetCampaigns] Completed. " . print_r($ccIDs, true));
        return array('code' => $success ? 200 : 400, 'ids' => $ccIDs);
    }

    //Get the next $maxRounds of campaign results from CC.
    //Returns true when done, false when more to grab, null on error
    public static function GetDetailedResults(&$campEventCol, $maxRounds = 1, $ts = null, $lastRunCompleted = false) {
        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Starting");
        global $db, $current_user, $timedate;
        $types = CCCampaignEventCollection::$types;

        $rounds = 0;

        $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] MaxRounds = $maxRounds");

        // iterate through one event type per loop
        while ($rounds < $maxRounds) {
            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Starting round $rounds");
            $camID = self::GetCamIDFromCCID($campEventCol->campaignID);
            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Campaign ID = $camID");
            // Campaign doesn't exist in sugar
            if (!$camID) {
                $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Campaign ID is NULL");
                return null;
            }

            $nextType = self::GetNextEventType($types, $campEventCol);
            if(!$nextType) {
                $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] No more event types.  Complete.");
                return true;    // no more event types, done
            }

            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Next type: {$nextType}");
            CCLog::Log("[SugarCCCampaign][GetDetailedResults] next type: {$nextType}", 'debug');

            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Getting campaign data.");
            $campEventCol->GetData($nextType, $ts, $lastRunCompleted);
            // if no events of current type then continue to next type
            if(!(count($campEventCol->Items) > 0)) {
                $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] No more events of the current type.");
                $rounds -= 1;
                continue;
            }

            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Beginning loop through events.");
            foreach ($campEventCol->Items as $item) {
                $type = self::TranslateType($item);
                if (!$type) {
                    continue;
                }
                $person = SugarCCPerson::GetPersonByEmailAddress($item->Email);
                if (!$person) {
                    continue;
                }

                $td = new TimeDate();
                $d = new DateTime(date('Y-m-d H:i:s', strtotime($item->EventTime)));
                $date = $td->asUser($d, $current_user);
                self::AddCampaignLog($type, $camID, $person, $date, $item->id, $timedate->get_date_time_format());
            }
            $GLOBALS['log']->info("[fbsg_cci][SugarCCCampaign][GetDetailedResults] Completed loop through events.");
            $rounds++;
        }
        return false;
    }
    
    private function GetPLIDByCCID($ccid) {
        global $db;
        $query = "SELECT id FROM prospect_lists WHERE cc_id = '{$db->quote($ccid)}' AND deleted = 0";
        $results = $db->query($query);
        if($row = $db->fetchByAssoc($results)) {
            return $row['id'];
        }
        else return null;
    }

    private static function GetCamIDFromCCID($ccid) {
        global $db;
        $query = "select id from campaigns where cc_id = '{$db->quote($ccid)}' AND deleted = 0";
        return $db->getOne($query);
    }

    private function AddCampaignTrackers($ccCam, $sCam) {
        require_once('modules/CampaignTrackers/CampaignTracker.php');
        global $db;
        $trackSeed = new CampaignTracker();
        foreach($ccCam->Urls as $url=>$data) {
            $trackers = $trackSeed->get_full_list('', 'campaign_trkrs.campaign_id = \''.$db->quote($sCam->id).
                                                  '\' AND campaign_trkrs.tracker_url = \''.$db->quote($url).'\'');
            if(count($trackers) > 0) {
                $tracker = $trackers[0];
            } else {
                $tracker = new CampaignTracker();
            }
            $tracker->cc_url_id = urldecode($data['url_id']);
            $tracker->tracker_name = $url;
            $tracker->tracker_url = $url;
            $tracker->campaign_id = $sCam->id;
            $tracker->clicks = $data['clicks'];
            $tracker->save();
        }
    }

    private static function AddCampaignLog($type, $camID, $person, $date = null, $cc_url_id = null, $dateFormat = null) {
        require_once('modules/CampaignLog/CampaignLog.php');
        global $db;
        $cLog = new CampaignLog();
        $cList = $cLog->get_full_list('', "campaign_log.target_id = '{$db->quote($person->id)}' AND campaign_log.campaign_id = '{$db->quote($camID)}' AND campaign_log.activity_type = '{$db->quote($type)}'");
        if (count($cList) > 0)
            $cLog = $cList[0];
        $cLog->activity_type = $type;
        if (($type == 'link') && $cc_url_id) {
            $trackSeed = new CampaignTracker;
            $trackList = $trackSeed->get_full_list('',"cc_url_id='$cc_url_id'");
            if (count($trackList) > 0) {
                $tracker = $trackList[0];
                $cLog->related_id = $tracker->id;
                $cLog->related_type = 'CampaignTrackers';
            }
        }
        if($date) {
            $cLog->activity_date = SugarCC::GetSugarDate($date, $dateFormat);
        }
        $cLog->target_type = $person->module_dir;
        $cLog->target_id = $person->id;
        $cLog->campaign_id = $camID;
        $cLog->more_information = $person->email1;
        $cLog->save();
    }

    private static function GetNextEventType($types, $evCol) {
        $nextType = null;
        foreach ($types as $t) {
            if (isset($evCol->nextURLs[$t])) {
                if ($evCol->nextURLs[$t]) {
                    $nextType = $t;
                    break;
                }
            }
        }

        return $nextType;
    }



    private static function TranslateType($item) {
        switch($item->EventNode) {
            case 'ClickEvent':
                return 'link';
            case 'SentEvent':
                return 'targeted';
            case 'OptoutEvent':
                return 'removed';
            case 'ForwardEvent':
                return 'forwarded';
            case 'OpenEvent':
                return 'viewed';
            case 'BounceEvent':
                if($item->Code == 'B' || $item->Code == 'D') {
                    return 'invalid email';
                } else {
                    return 'send error';
                }
            default:
                return '';
        }
    }
}
