<?php
require_once('modules/ProspectLists/ProspectList.php');

class SugarCCList {
    var $utility;
    var $excludedLists = array('Active', 'Removed', 'Do Not Mail');

    public function __construct($ut = null, $ex = null) {
        $this->utility = $ut;
        if($ex !== null) {
            $this->excludedLists = $ex;
        }
    }

    public static function GetAllCCLists() {
        $pSeed = new ProspectList();
        $ctLists = $pSeed->get_full_list('', 'prospect_lists.cc_id IS NOT NULL and prospect_lists.deleted = 0');
        $ccids = array();
        foreach ($ctLists as $ctList) {
            $ccids[] = $ctList->cc_id;
        }
        return $ccids;
    }
    
    private static function GetSugarCCLists() {
        global $db;
        $query = "select id, cc_id from prospect_lists where cc_id is not null";
        $results = $db->query($query);

        $ccLists = array();
        while($row = $db->fetchByAssoc($results)) {
            $ccLists[$row['id']]['cc_id'] = $row['cc_id'];
        }

        return $ccLists;
    }

    public static function GetSugarListByCcId($ccId) {
        global $db;
        $bean = new ProspectList();
        $list = $bean->get_list('', "prospect_lists.cc_id = {$db->quoted($ccId)}");
        if(!empty($list['list'])) {
            return $list['list'][0];
        }
        return null;
    }


    public function CreateProspectLists() {
        $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateProspectLists] Starting CreateProspectLists");
        global $db;
        $CCLists = new CCListCollection($this->utility);
        $success = false;

        $currentLists = self::GetSugarCCLists();
        do {
            $continue = $CCLists->GetData(true);
            foreach ($CCLists->Items as $list) {
                $success = true;
                if (!in_array($list->Name, $this->excludedLists)) {
                    $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateProspectLists] Creating {$list->Name} prospect list.");
                    $moddedID = $this->CreateSugarProspectLists($list);
                    $currentLists[$moddedID]['modified'] = true;
                }
            }
        } while($continue);

        // If a list exists in Sugar, but was not touched when retrieving
        // lists from CC, then it must have been deleted; kill it on Sugar
        // as well.
        foreach($currentLists as $existingID => $data) {
            if(!isset($data['modified']) || $data['modified'] === false) {
                $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateProspectLists] List exists in SugarCRM, but was not retrieved from CC, so delete list {$existingID}.");
                $query = 'update prospect_lists set deleted = 1 where id = \'' . $existingID . '\'';
                $GLOBALS['log']->debug($existingID . ' not modified, deleting with query \'' . $query . '\'');
                $db->query($query);

                $query = 'update prospect_lists_prospects set deleted = 1 where prospect_list_id = \''.$existingID . '\'';
                $db->query($query);
            }
        }

        if($success) {
            $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateProspectLists] Completed successfully.");
            return true;
        } else {
            $GLOBALS['log']->fatal("[fbsg_cci][SugarCCList][CreateProspectLists] FAILED");
            CCLog::Log("Failure to create Sugar prospect lists.", "fatal");
            return false;
        }

    }

    public static function GetAllCCListNames() {
        global $db;
        $query = "select name from prospect_lists where cc_id is not null and deleted = 0 order by name asc";
        $result = $db->query($query);
        $ccnames = array();
        while($row = $db->fetchByAssoc($result)) {
            $ccnames[] = $row['name'];
        }

        return $ccnames;
    }

    private function CreateSugarProspectLists($list) {
        global $timedate;
        $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateSugarProspectLists] . Starting CreateSugarProspectLists.");
        $newPList = new ProspectList();
        $pLists = $newPList->get_list('', 'prospect_lists.cc_id = \'' . urldecode($list->cc_id) . '\'');
        if ($pLists['list']) {
            $currentList = $pLists['list'][0];
        } else {
            $currentList = $newPList;
        }
        $currentList->cc_id = urldecode($list->cc_id);
        $currentList->name = $list->Name;
        $currentList->list_type = 'Default';
        $currentList->description = "Constant Contact marketing list";
        $currentList->sync_to_cc = 1;
        $currentList->last_successful_cc_update = $timedate->now();
        $currentList->last_successful_cc_remove = $timedate->now();
        $currentList->save();
        $GLOBALS['log']->info("[fbsg_cci][SugarCCList][CreateSugarProspectLists] . Created Sugar {$currentList->name} prospect list with ID of {$currentList->id}.");
        return $currentList->id;
    }

    public function Sync($b = null) {
        if (!$b) {
            return false;
        } else if (is_array($b)) {
            $err = false;
            foreach ($b as $bean) {
                if(!$this->SendToCC($bean)) $err = true;
            }
            return !$err;
        } else {
            return $this->SendToCC($b);
        }
    }

    public function SendToCC($b = null) {
        if (!$b || !$b->name) {
            return false;
        }

        global $db;

        $ccList = new CCList($this->utility);

        // If we have a cc_id sugar side check if it exists CC side
        if ($b->cc_id) {
            $retrievedList = $ccList->GetByCCID($b->cc_id);
        }
        // If we have a cc_id from the CC side then update
        if ($retrievedList->cc_id) {
            $retrievedList->Name = $b->name;
            $retrievedList->Send('PUT');
        } else {    // else we create a new contact list in CC
            $ccList->Name = $b->name;
            $ccList->OptInDefault = 'false';
            $ccList->ShortName = $b->name;
            $ccList->SortOrder = '99';
            $response = $ccList->Send('POST');
            if ($response['status'] < 300) {
                $xmlResponse = CCXml::ParseXml($response['data']);

                $listAttributes = $xmlResponse->content->ContactList->attributes();
                $b->cc_id = urldecode((string)$listAttributes['id']);
                $query = "UPDATE prospect_lists SET cc_id = '{$db->quote($b->cc_id)}' WHERE id = '{$db->quote($b->id)}'";
                $db->query($query);
            } else if ($response['status'] == '409') {
                $query = "UPDATE prospect_lists SET sync_to_cc = 0 WHERE id = '{$db->quote($b->id)}'";
                $db->query($query);
                return false;
            }
        }

        return true;
    }
}
