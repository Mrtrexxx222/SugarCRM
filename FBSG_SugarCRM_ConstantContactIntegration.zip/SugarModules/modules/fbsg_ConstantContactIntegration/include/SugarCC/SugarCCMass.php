<?php
class SugarCCMass {
    var $utility;
    
    var $fbsg_columns = array(
        'person' => array(
            'email1' => 'Email address',
            'account_name' => 'Company Name',
            'first_name' => 'First name',
            'last_name' => 'Last name',
            'phone_home' => 'Home phone',
            'phone_work' => 'Work phone',
            'title' => 'Job Title',
            'primary_address_street' => 'Address line 1',
            'primary_address_city' => 'City',
            'primary_address_state' => 'State',
            'primary_address_country' => 'Country',
            'primary_address_postalcode' => 'Postal code'
        ),
        'company' => array(
            'email1' => 'Email address',
            'name' => 'Company Name',
            'first_name' => '',
            'last_name' => '',
            'phone_home' => '',
            'phone_office' => 'Work Phone',
            'title' => '',
            'billing_address_street' => 'Address line 1',
            'billing_address_city' => 'City',
            'billing_address_state' => 'State',
            'billing_address_country' => 'Country',
            'billing_address_postalcode' => 'Postal code'
        )
    );
    
    var $MaxToSend = 500;
    
    var $column_headers = Array(
            'Email Address' => 'cc_email',
            'Company Name' => 'cc_company_name',
            'First Name' => 'cc_first_name',
            'Last Name' => 'cc_last_name',
            'Work Phone' => 'cc_work_phone',
            'Home Phone' => 'cc_home_phone',
            'Address Line 1' => 'cc_address_street',
            'City' => 'cc_address_city',
            'US State/CA Province' => 'cc_address_state',
            'Country' => 'cc_address_country',
            'Zip/Postal Code' => 'cc_address_postalcode',
    );
    
    public function __construct($ut = null) {
        $this->utility = $ut;
    }

    public function GetAllCampaignResults() {
        $incrementalUpdate = true;
        $ccLists = new SugarCCList($this->utility);
        $ccLists->CreateProspectLists();
        $this->UpdateAllCampaigns($incrementalUpdate);
        
        return true;
    }

    private function UpdateAllCampaigns($incrementalUpdate = false) {
         global $db;
         $ts = false;
         $sCc = SugarCC::GetOnlyCC();

         $ccCam = new SugarCCCampaign($this->utility);
         $camRet = $ccCam->GetCampaigns();
         $cIDs = $camRet['ids'];
         foreach ($cIDs as $id) {
             CCLog::Log("[SugarCCMass][UpdateAllCampaigns] Processing campaign id: {$id}", 'debug');
             $ts = false;
             if ($incrementalUpdate) {
                 // In some Sugar versions, the MssqlManager constructs an invalid
                 // limit query. Instead of that, construct it manually.
                 if($db instanceof MssqlManager) {
                     $query = "SELECT TOP 1 activity_date FROM campaign_log cl ".
                              "INNER JOIN campaigns c on cl.campaign_id = c.id " .
                              "WHERE cl.deleted = 0 " .
                              "AND c.cc_id = '{$db->quote($id)}' " .
                              "ORDER BY cl.activity_date DESC";
                     $res = $db->query($query); 
                 } else {
                     $query = "SELECT activity_date FROM campaign_log cl " .
                              "INNER JOIN campaigns c on cl.campaign_id = c.id " .
                              "WHERE cl.deleted = 0 " .
                              "AND c.cc_id = '{$db->quote($id)}' " .
                              "ORDER BY cl.activity_date DESC";
                     $res = $db->limitQuery($query, 0, 1);
                 }
                 if ($row = $db->fetchByAssoc($res)) {
                     $ts = strtotime($row['activity_date']);
                 }
             }

             $lastRunCompleted = $db->getOne("SELECT last_run_completed FROM campaigns WHERE cc_id = '{$db->quote($id)}' AND deleted = 0");
             $ccCam->UpdateCampaign($id);
             $eventGetter = new CCCampaignEventCollection($this->utility, $id, $sCc->sync_sent_results);
             $eventGetter->GetCampaignCollections();
             $done = false;
             $db->query("UPDATE campaigns SET last_run_completed=0 WHERE cc_id='{$db->quote($id)}'");
             while (! $done) {
                 $done = SugarCCCampaign::GetDetailedResults($eventGetter, 5, $ts, $lastRunCompleted);
             }
             $db->query("UPDATE campaigns SET last_run_completed=1 WHERE cc_id='{$db->quote($id)}'");
         }
     }


    public function SyncStagedLists() {
        global $db, $timedate;
        $plSeed = new ProspectList();
        $plList = $plSeed->get_full_list('', "prospect_lists.sync_to_cc = '1' and prospect_lists.cc_id is not null");
        foreach ($plList as $pl) {
            $successfulUpdateDate = $timedate->now();
            $this->SyncListToCC($pl);
            $this->SyncRemovedFromCC($pl);
        }
    }

    public static function GetLastSuccessfulDate($pl, $type) {
        global $timedate;

        if($type == 'send') {
            $date = $pl->last_successful_cc_update;
        } else if($type == 'remove') {
            $date = $pl->last_successful_cc_remove;
        }
        $lastUpdate = $timedate->fromDb($date);
        if(!$lastUpdate) {
            $lastUpdate = SugarDateTime::createFromFormat('Y-m-d H:i:s', '2001-01-01 00:00:00');
        }
        return $timedate->asDb($lastUpdate);
    }

    public static function UpdateLastSuccessfulDate($plId, $type, $dbDate) {
        global $db;
        if($type == 'send') {
            $field = 'last_successful_cc_update';
        } else if($type == 'remove') {
            $field = 'last_successful_cc_remove';
        } else return;

        $query = "update prospect_lists set $field = {$db->quoted($dbDate)} where id = {$db->quoted($plId)}";
        $db->query($query);
    }

    public function SyncRemovedFromCC($pl, $test = false) {
        global $timedate, $db;

        $lastUpdate = self::GetLastSuccessfulDate($pl, 'remove');

        //Get all records deleted from this prospect list since last update that have not
        //been re-added to the list.
        $query = 
        "SELECT 
          related_id, prospect_list_id, related_type, max(date_modified) as max_date_modified
        FROM
          prospect_lists_prospects plpo 
        WHERE id NOT IN 
          (SELECT 
            plp.id 
          FROM
            prospect_lists_prospects plp 
            INNER JOIN prospect_lists_prospects plpi 
              ON plp.prospect_list_id = plpi.prospect_list_id 
              AND plp.related_id = plpi.related_id 
              AND plp.related_type = plpi.related_type 
              AND plp.deleted <> plpi.deleted 
          WHERE plp.deleted = 1 
            AND plpi.date_modified > plp.date_modified
            ) 
         AND deleted = 1 
         AND plpo.date_modified > {$db->quoted($lastUpdate)} 
         AND plpo.prospect_list_id = {$db->quoted($pl->id)}
         GROUP BY related_id, prospect_list_id, related_type
         order by max_date_modified";

        $results = $db->query($query);

        $returnDate = $timedate->now();

        $deletedIds = array();
        $moduleMap = array('Contacts' => 'C', 'Leads' => 'L', 'Accounts' => 'A', 'Prospects' => 'P');

        //Package the deleted records
        while($row = $db->fetchByAssoc($results)) {
            if(isset($moduleMap[$row['related_type']])) {
                $deletedIds[] = array(
                    'type' => $moduleMap[$row['related_type']],
                    'id' => $row['related_id'],
                    'date_modified' => $row['max_date_modified']
                );
            }
        }
        //Send all the retrieved people. Send in chunks no larger than $this->MaxToSend

        $updated = false;
        while (count($deletedIds) > 0) {
            
            $toSend = array();
            $beforeCount = count($deletedIds);
            // Pop off ids until we fill the buffer, or run out.
            for ($i = 0; $i < $this->MaxToSend && ($beforeCount - $i >= 1); $i++) {
                $toSend[] = array_pop($deletedIds);
            }
            $activity = SugarCCActivity::createRemoveContactsActivity($toSend, $pl->cc_id);
            
            if ($activity) {
                if($test) {
                    CCLog::Log("Would have sent this activity: $activity", 'fatal');
                    continue;
                }
                $ccAct = new CCActivity($this->utility);
                $response = $ccAct->CreateAddContactActivity($activity);
                if ($response['status'] >= 400) {
                    CCLog::Log('Error removing records from prospect list: ' . print_r($response['data'], true), 'fatal');
                    return false;
                }
                self::UpdateLastSuccessfulDate($pl->id, 'remove', $toSend[0]['date_modified']);
                $updated = true;
            }
            $activity = null;
            $toSend = null;
        }

        self::UpdateLastSuccessfulDate($pl->id, 'remove', $timedate->nowDb());

        return $returnDate;
    }
    
    public function SyncListToCC($pl, $toSend = array('Contacts', 'Leads', 'Accounts', 'Prospects'), $test = false) {
        global $db, $timedate;

        $lastUpdate = self::GetLastSuccessfulDate($pl, 'send');

        if (! $pl->cc_id) {
            CCLog::Log('Trying to send prospect list ' . $pl->id . ', no cc id', 'fatal');
        }

        $query = "SELECT related_id, related_type, date_modified
                    FROM prospect_lists_prospects plp
                  WHERE plp.deleted = 0 and plp.prospect_list_id = {$db->quoted($pl->id)}
                  AND (plp.related_type = 'Accounts' 
                        OR plp.related_type = 'Prospects' 
                        OR plp.related_type = 'Leads' 
                        OR plp.related_type = 'Contacts'
                  ) and plp.date_modified > {$db->quoted($lastUpdate)}
                  ORDER BY date_modified ASC";
        $results = $db->query($query);

        $pIDs = array();
        $startingModuleMap = array('Contacts' => 'C', 'Leads' => 'L', 'Accounts' => 'A', 'Prospects' => 'P');
        $moduleMap = array();

        //Filter the module map according to what we should send
        foreach($startingModuleMap as $moduleToSend => $code) {
            if(in_array($moduleToSend, $toSend)) {
                $moduleMap[$moduleToSend] = $code;
            }
        }

        //Package the retrieved records
        while($row = $db->fetchByAssoc($results)) {
            if(isset($moduleMap[$row['related_type']])) {
                $pIDs[] = array(
                    'type' => $moduleMap[$row['related_type']],
                    'id' => $row['related_id'],
                    'date_modified' => $row['date_modified']
                );
            }
        }
        
        
        $updated = false;   
        //Send all the retrieved people. Send in chunks no larger than $this->MaxToSend
        
        while (count($pIDs) > 0) {
            
            $toSend = array();
            $beforeCount = count($pIDs);
            // Pop off ids until we fill the buffer, or run out.
            for ($i = 0; $i < $this->MaxToSend && ($beforeCount - $i >= 1); $i++) {
                $toSend[] = array_pop($pIDs);
            }
            $activity = SugarCCActivity::createAddContactsActivity($toSend, $pl->cc_id, $this->fbsg_columns);
            
            if ($activity) {
                if($test) {
                    echo "<pre>Would have sent this activity:\n$activity</pre>";
                    continue;
                }
                $ccAct = new CCActivity($this->utility);
                $response = $ccAct->CreateAddContactActivity($activity);
                if ($response['status'] >= 400) {
                    CCLog::Log('Error syncing prospect list: ' . print_r($response['data'], true), 'fatal');
                    return false;
                }
                self::UpdateLastSuccessfulDate($pl->id, 'send', $toSend[0]['date_modified']);
                $updated = true;
            }
            $activity = null;
            $toSend = null;
        }

        self::UpdateLastSuccessfulDate($pl->id, 'send', $timedate->nowDb());
    }

    /**
     * Insert or update contacts from the CC CSV into the cc_cync table for
     * later import into the cooresponding bean module.
     *
     * @param array $completed_activities           
     */
    public function PopulateContactImportTable($completed_activities = Array(), $mark = null) {
        // require the CSV library
        require_once ('modules/fbsg_ConstantContactIntegration/include/csv.php');
        global $db;
        // iterate through each activity
        foreach ($completed_activities as $activity) {
            $cur_headers = Array();
            // get the CSV file specified in the activity array
            $response = $this->utility->GetData($activity['url']);
            if ($response['error']) {
                CCLog::Log('PopulateContactImportTable GetData(CSV) CURL Error: ' . $response['error'], 'fatal');
            } else if ($response['status'] >= 300) {
                CCLog::Log('PopulateContactImportTable GetData(CSV) HTML Status: ' . $response['status'], 'fatal');
            } else {
                // parse the CSV file
                $csv = new CsvParser($response['data'], true, $this->column_headers);
                // for each row,
                while ($row = $csv->ProcessRow()) {
                    $csync = new csync_cc_sync_table();
                    // returns a row if the contact in the CSV is already in the
                    // sync table.
                    $query = 'SELECT id FROM csync_cc_sync_table WHERE cc_email=' . $db->quoted($row['cc_email']) . '';
                    $short_list_id = preg_match(' /.*\/(\d+)$/', $activity['list_id'], $short_id) ? $short_id[1] : false;
                    // if the customer is already in the sync table
                    if ($id = $db->getOne($query)) {
                        // retrieve the sync table contact bean
                        $csync->retrieve($id);
                        // add the list_id to the list of lists in the sync
                        // table contact bean
                        $csync->cc_list_id .= ',' . $short_list_id;
                        // the contact is not in the syn table already
                    } else {
                        // for each row split from an assoc array
                        foreach ($row as $field => $value) {
                            // set the sync table contact bean field equal to
                            // the value returned by the CC csv.
                            $csync->$field = $value;
                        }
                        // set the list_id for the sync table contact bean
                        $csync->cc_list_id = $short_list_id;
                        if($mark) $csync->import_this = $mark;
                    }
                    $csync->save();
                }
            }
        }
    }
    
    public function UpdateOptouts()
    {
        global $db;
        $doNotMailId = $this->utility->GetEndpoint('lists') . '/do-not-mail';
        $listCollection = new CCListMemberCollection($this->utility, $doNotMailId);
        $sugarCCPerson = new SugarCCPerson($this->utility);
        $sugarUpdated = 0;
        $ccFound = 0;

        $personTypes = array('Contacts', 'Leads', 'Prospects', 'Accounts');

        do {
            $continue = $listCollection->GetData(true);

            foreach($listCollection->Items as $member) {
                $ccFound++;
                foreach($personTypes as $personType) {
                    $person = SugarCCPerson::GetPersonByEmailAddress($member->Email, $personType);
                    if($person && !$person->cc_optout) {
                        $sugarUpdated++;
                        $sugarCCPerson->OptOut($person);
                    }
                }
            }
        } while($continue);

        return array('cc_optouts' => $ccFound, 'sugar_optouts' => $sugarUpdated);
    }

    public function SyncImportTableToContacts($sync_arr = Array(), $max_to_import = 1000) {
        global $db;
        $ccList = new SugarCCList($this->utility);
        $syncResult = $ccList->CreateProspectLists();

        $sync_query = '(';
        if (count($sync_arr)) {
            foreach ($sync_arr as $sync) {
                $sync_query .= "eabr.bean_module = '" . $db->quote($sync) . "' or ";
            }
            $sync_query = substr($sync_query, 0, - 4) . ')';
        } else {
            return false; // no sync parameters given (contacts or leads)
        }
        
        $proSeed = new ProspectList();
        $conSeed = new Contact();
        $leadSeed = new Lead();
        $prospectSeed = new Prospect();
        $bean_list = $proSeed->get_full_list('', 'prospect_lists.cc_id is not null');
        $pl = Array();
        
        foreach ($bean_list as $bean) {
            $bean->load_relationship('contacts');
            $bean->load_relationship('leads');
            $bean->load_relationship('prospects');
            $bean->load_relationship('accounts');
            $pl[$bean->cc_id] = $bean;
        }
        
        $query = "SELECT * FROM csync_cc_sync_table where import_this <> '' and import_this is not null and import_this <> '0'";
        $results = $db->query($query);

        $imported_beans = 0;

        
        while (($row = $db->fetchByAssoc($results)) && $imported_beans < $max_to_import) {
            $query = "select eabr.bean_id, eabr.bean_module from email_addr_bean_rel eabr " . 
                     "inner join email_addresses ea on eabr.email_address_id = ea.id " 
                     . "where ea.email_address_caps = '" . $db->quote(strtoupper($row['cc_email'])) 
                     . "' and eabr.deleted = 0 and " . $sync_query . " order by " . "eabr.bean_module";
            $con_res = $db->query($query);
            if ($con_row = $db->fetchByAssoc($con_res)) {
                $bean_type = strtolower($con_row['bean_module']);
                $cc_ids = explode(',', $row['cc_list_id']);

                $added = array();
                foreach ($cc_ids as $cc_id) {
                    $listToAdd = $pl[$this->utility->GetEndpoint('lists', $cc_id)];
                    $listToAdd->$bean_type->add($con_row['bean_id']);
                    $added[] = $listToAdd->name;
                }
                fbsg_CCIntegrationLog::LogInteraction($con_row['bean_id'], $bean_type, "Automatic Sync", false, "Added to lists " . implode(', ', $added));
                if (($bean_type == 'contacts') || ($bean_type == 'leads') || ($bean_type == 'prospects') || ($bean_type == 'accounts')) {
                    $cc_sync_query = 'UPDATE ' . $bean_type . ' SET ' . $bean_type . '.cc_sync=1 WHERE id=\'' . $con_row['bean_id'] . '\'';
                    $db->query($cc_sync_query);
                }
            }
            $query = "update csync_cc_sync_table set import_this = '' where cc_email = '{$db->quote($row['cc_email'])}'";
            $db->query($query);
            $imported_beans++;
        }
        
        return true;
    }
    /**
     * Imports contacts from the sync table into the corresponding beans.
     */
    public function ImportContactsFromCCToSugar($max_to_import = 200) {
        global $db;
        $query_limit = 50; // 50 because, I presume, the list to sync could be
                           // very large and there may be memory/performance
                           // issues if set higher
        $lead_source = ''; // Actual lead source comes from the CCI configuration
                           // table
                           
        // get the CCI configuration info
        $CCSeed = new fbsg_ConstantContactIntegration();
        $CCBean = $CCSeed->get_full_list('', 'fbsgcci.deleted=0');
        
        if (count($CCBean)) {
            // get the default lead source set in the CCI config module
            $lead_source = $CCBean[0]->lead_source;
        }
        
        $proSeed = new ProspectList(); // create target list bean object
                                       
        // get the all of the target lists in sugar
        $bean_list = $proSeed->get_full_list('', 'prospect_lists.cc_id is not null');
        $pl = Array(); // array to store prospect (target) lists
        $conSeed = new Contact();
        $leadSeed = new Lead();
        $prospectSeed = new Prospect();
        $accountSeed = new Account();
        
        // for each target list, load all members of the list
        foreach ($bean_list as $bean) {
            $bean->load_relationship('contacts');
            $bean->load_relationship('leads');
            $bean->load_relationship('prospects');
            $bean->load_relationship('accounts');
            // add the target list bean to the list of target lists and set the
            // array key to the ID of the target list
            $pl[$bean->cc_id] = $bean;
        }

        $imported_beans = 0;
        
        do {
            
            // hold list of contacts to be imported
            $res = Array();
            // create new instance of the table which contains list of contacts
            // from CC which could be imported
            $cc_sync_seed = new csync_cc_sync_table();
            // select all the records in the CC contact import table where the
            // import_this flag is not blank
            $res = $cc_sync_seed->get_list('id', "import_this<>''", 0, $query_limit, $query_limit);
            // for each contact returned by the query
            foreach ($res['list'] as $cc_import) {
                // Accounts have a different mapping than person modules
                $person = true;
                // the import_this flag contains the target module specified by
                // the customer
                if ($cc_import->import_this == 'Contacts') {
                    $con = $conSeed;
                } else if ($cc_import->import_this == 'Leads') {
                    $con = $leadSeed;
                } else if ($cc_import->import_this == 'Prospects') {
                    $con = $prospectSeed;
                } else if($cc_import->import_this == 'Accounts') {
                    $con = $accountSeed;
                    $person = false;
                }

                // this query should return a row if a contact from cc already
                // exists in sugar as the bean type specified by the user in
                // $cc_import->import_this
                if($person) {
                    $query = 'SELECT bean_type.id as id FROM ' . $db->quote(strtolower($cc_import->import_this)) 
                        . ' bean_type INNER JOIN email_addr_bean_rel eabr on (bean_type.id = eabr.bean_id and eabr.bean_module = ' 
                        . $db->quoted($cc_import->import_this) . ') inner join email_addresses ea on eabr.email_address_id = ea.id' 
                        . ' WHERE ea.email_address_caps=' . $db->quoted(strtoupper($cc_import->cc_email)) 
                        . '' . ' AND eabr.bean_module=' . $db->quoted($cc_import->import_this) . '' 
                        . ($cc_import->cc_first_name ? 
                            (' AND bean_type.first_name=' . $db->quoted($cc_import->cc_first_name) . '') : 
                            (' AND (bean_type.first_name=\'\' OR bean_type.first_name is null) ')) 
                        . ' AND bean_type.last_name=' . ($cc_import->cc_last_name ? $db->quoted($cc_import->cc_last_name) : '\'[Not Specified]\'') 
                        . ' AND bean_type.deleted=0 and eabr.deleted = 0 and ea.deleted = 0';
                } else {
                    // Accounts are less restrictive than people. We only match on exact email address.
                    $query = 'SELECT bean_type.id as id from ' . $db->quote(strtolower($cc_import->import_this))
                        . ' bean_type INNER JOIN email_addr_bean_rel eabr on (bean_type.id = eabr.bean_id and eabr.bean_module = '
                        . $db->quoted($cc_import->import_this) . ') inner join email_addresses ea on eabr.email_address_id = ea.id'
                        . ' WHERE ea.email_address_caps = ' . $db->quoted(strtoupper($cc_import->cc_email))
                        . ' AND eabr.bean_module = ' . $db->quoted($cc_import->import_this)
                        . ' AND bean_type.deleted = 0 and eabr.deleted = 0 and ea.deleted = 0';
                }
                
                // fetch the pre-existing bean for this contact (if the contact
                // already exists in the mosule specified by import_this)
                $results = $db->query($query);
                $row = $db->fetchByAssoc($results);
                $bean_id = ($row === false ? '' : $row['id']);
                
                // retrieve the bean specified by the $bean_id and
                // if the contact from constant contact does not already exist
                // then set the name and email address in the $con bean. If the
                // contact does exist already, then use the name stored in
                // sugarcrm.
                $newRecord = false;
                if (! $con->retrieve($bean_id)) {
                    $newRecord = true;
                    // since the bean does not already exist, we need to
                    // initialize a new one.
                    if ($cc_import->import_this == 'Contacts') {
                        $con = new Contact();
                    } else if ($cc_import->import_this == 'Leads') {
                        $con = new Lead();
                        $con->lead_source = $lead_source;
                    } else if ($cc_import->import_this == 'Prospects') {
                        $con = new Prospect();
                    } else if($cc_import->import_this == 'Accounts') {
                        $con = new Account();
                    }
                    
                    // new contact so set name
                    if($person) {
                        $con->first_name = $cc_import->cc_first_name ? $cc_import->cc_first_name : '';
                        $con->last_name = $cc_import->cc_last_name ? $cc_import->cc_last_name : '[Not Specified]';
                    } else {
                        $name = array();
                        $name[] = $cc_import->cc_first_name;
                        if($cc_import->cc_last_name) $name[] = $cc_import->cc_last_name;

                        $con->name = implode(' ', $name);
                    }
                }
                // set the rest of the information for the bean from constant
                // contact.
                $personFields = array(
                    'email1', 'phone_home', 'phone_work', 'primary_address_street', 'primary_address_city', 'primary_address_state', 'primary_address_postalcode', 
                    'primary_address_country');
                $companyFields = array(
                    'email1', '', 'phone_office', 'billing_address_street', 'billing_address_city', 'billing_address_state', 'billing_address_postalcode',
                    'billing_address_country');
                $importFields = array(
                    'cc_email', 'cc_home_phone', 'cc_work_phone', 'cc_address_street', 'cc_address_city', 'cc_address_state', 'cc_address_postalcode', 'cc_address_country');

                $sugarFields = $person ? $personFields : $companyFields;

                $i = 0;
                foreach($sugarFields as $sugarField) {
                    if(!$sugarField) continue;
                    $ccField = $importFields[$i];

                    $con->$sugarField = $cc_import->$ccField ? $cc_import->$ccField : $con->$sugarField;
                    $i++;
                }
                $con->cc_optout = $cc_import->cc_opt_out ? 1 : 0; //Always set the cc optout, since CC is the master for this info.
                
                // set the cc_sync flag to 1 to show that the record is synced
                // with constant contact, or 0 if the record is opted out.
                $con->cc_sync = $con->cc_optout ? 0 : 1;
                $bean_id = $con->save();

                if($newRecord) {
                    fbsg_CCIntegrationLog::LogInteraction($bean_id, $cc_import->import_this, "Automatic Import", false, "New record");
                }

               
                $added = array(); 
                //Only set the lists if the contact is not opted out.
                if(!$con->cc_optout) {
                    // set $lists to an array containing the list IDs of all the
                    // lists in CC that this contact belongs to
                    $lists = explode(',', $cc_import->cc_list_id);
                    
                    if ($lists[0] != '') {
                        // for each list that the contact bleongs to, add them to
                        // the
                        // list in sugar
                        foreach ($lists as $list) {
                            // make the string containing the name of the impor_this
                            // flag (which specifies the name of the module to which
                            // a
                            // cc contact belongs) lower case, so that it can be
                            // used
                            // later to add the contact to the list.
                            $bean_type_lower = strtolower($cc_import->import_this);
                            // get the cc_id of the list
                            $cc_id = $this->utility->GetEndpoint('lists', $list);
                            // access the target list bean using the cc_id array
                            // key,
                            // then use the module relationship property for that
                            // been
                            // matching the lowercase import_this flag to add the
                            // contact to the list
                            $pl[$cc_id]->$bean_type_lower->add($bean_id);
                        }
                    }
                    fbsg_CCIntegrationLog::LogInteraction($bean_id, $cc_import->import_this, "Automatic Import", false, "Added to list(s) " . implode(', ', $lists));
                }

                $imported_beans++;
                // clear the import_this flag, so that the next time the cron
                // job is run, this contact is not imported again.
                $cc_import->import_this = '';
                $cc_import->save();
            }
            
            // while there are still rows returned by the query to retrieve
            // contacts to import from the sugar sync table
        } while ($res['row_count'] && ($imported_beans < $max_to_import));
    }
    /**
     *
     * @param unknown_type $sync_table_ids          
     * @param string $bean_type
     *          The name of the bean module to set the import_this flag to.
     *          This controls where imported CC contacts are sent to in Sugar.
     * @return multitype:number
     */
    public function FlagCCTableForImport($sync_table_ids, $bean_type = 'Contacts') {
        global $db;
        $cc_sync = new csync_cc_sync_table();
        $ret = Array(
                'queued' => 0,
                'skipped' => 0
        );
        foreach ($sync_table_ids as $id) {
            $query = "select id from csync_cc_sync_table where id = {$db->quoted($id)}";
            $retrievedId = $db->getOne($query);
            if ($retrievedId) {
                $ret['queued']++;
                $updateQuery = "update csync_cc_sync_table set import_this = {$db->quoted($bean_type)} where id = {$db->quoted($id)}";  
                $db->query($updateQuery);
            }
        }
        return $ret;
    }

    public static function ListMembershipReport($module_table) {
        global $db;
        $query = "SELECT c.id, c.first_name, c.last_name, ea.email_address, pl.name FROM
          email_addresses ea 
          INNER JOIN email_addr_bean_rel eabr 
            ON eabr.email_address_id = ea.id 
          INNER JOIN $module_table c 
            ON c.id = eabr.bean_id 
          INNER JOIN prospect_lists_prospects plp 
            ON plp.related_id = c.id 
          INNER JOIN prospect_lists pl 
            ON pl.id = plp.prospect_list_id
        WHERE c.deleted = 0 
          AND ea.deleted = 0 
          AND eabr.deleted = 0 
          AND plp.deleted = 0
        ORDER BY ea.email_address";

        $results = $db->query($query);
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="membership_report.csv"');

        while($row = $db->fetchByAssoc($results)) {
            echo implode(',', $row);
        }

        sugar_cleanup();
    }
}
