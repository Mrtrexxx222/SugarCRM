<?php
class SugarCCPerson {
    var $utility;

    public static $NoEmailMessage = "No email address on this record";

    public function __construct($ut = null) {
        $this->utility = $ut;
    }

    private function GetRelatedPLIDs($object) {
        if (!is_object($object))
            return null;
        $table = $object->table_name;
        $module_name = $object->module_dir;
        global $db;
        $query = "SELECT prospect_lists.cc_id as ccid FROM prospect_lists INNER JOIN prospect_lists_prospects ON
		  prospect_lists.id = prospect_lists_prospects.prospect_list_id INNER JOIN $table ON
                  prospect_lists_prospects.related_id = $table.id and prospect_lists_prospects.related_type = '$module_name'
		  WHERE prospect_lists_prospects.deleted = 0 AND $table.id = '" . $db->quote($object->id) . "' ".
                  "AND prospect_lists.cc_id IS NOT NULL";
        $results = $db->query($query);
        $ids = array();
        while ($row = $db->fetchByAssoc($results)) {
            $ids[] = $row['ccid'];
        }
        return $ids;
    }


    private static function MapFromSugarRecord($cc, $sc) {
        if($sc instanceof Company) {
            $map = self::MapFromSugarCompany($cc, $sc);
        } else if($sc instanceof Person) {
            $map = self::MapFromSugarPerson($cc, $sc);
        } else {
            CCLog::Log('Invalid object passed to MapFromSugarRecord; requires Company or Person', 'fatal');
            return false;
        }

        foreach($map['sugarMaster'] as $sugarField => $ccField) {
            $cc->$ccField = $sc->$sugarField;
        }

        foreach($map['simpleFields'] as $sugarField => $ccField) {
            if($sc->$sugarField) {
                $cc->$ccField = $sc->$sugarField;
            }
        }

        $addressField = $map['addressField'];
        $zipField = $map['zipField'];

        $street = preg_split('/[\r\n]+/', $sc->$addressField);
        for($i = 0; $i <= 2; $i++) {
            if(count($street) > $i && $street[$i]) {
                $ccField = 'Addr' . ($i+1);
                $cc->$ccField = $street[$i];
            }
        }

        if ($sc->$zipField) {
            $zip = explode('-', $sc->$zipField);
            $cc->PostalCode = $zip[0];
            $cc->SubPostalCode = isset($zip[1]) ? $zip[1] : "";
        }

        return $cc;
    }

    public static function MapToSugarRecord($cc, $sc, $overwriteFields = false) {
        $sc->email1 = $cc->EmailAddress;
        $sc->cc_id = urldecode($cc['id']);

        if($sc instanceof Company && $overwriteFields) {
            $sc->name = ((string)$cc->CompanyName 
                ? (string)$cc->CompanyName
                : ((string)$cc->FirstName . ' ' . (string)$cc->LastName));

            $sc->billing_address_street = $cc->Addr1;
            $sc->billing_address_city = $cc->City;
            $sc->billing_address_state = $cc->State;
            $sc->phone_office = $cc->WorkPhone;
            $sc->billing_address_country = $cc->CountryName;
            $sc->billing_address_postalcode = $cc->PostalCode;
        } else if($sc instanceof Person && $overwriteFields) {
            $sc->first_name = $cc->FirstName;
            $sc->last_name = $cc->LastName;

            $sc->phone_home = $cc->HomePhone;
            $sc->phone_work = $cc->WorkPhone;
            $sc->primary_address_city = $cc->City;
            $sc->primary_address_state = $cc->State;
            $sc->primary_address_street = $cc->Addr1;
            $sc->primary_address_country = $cc->CountryName;
            $sc->primary_address_postalcode = $cc->PostalCode;
        }

        return $sc;
    }

    private static function MapFromSugarPerson($cc, $sc) {
        $sugarMasterFields = array(
            'email1' => 'EmailAddress',
            'first_name' => 'FirstName',
            'last_name' => 'LastName',
            'account_name' => 'CompanyName',
        );

        $simpleFields = array(
            'phone_home' => 'HomePhone',
            'phone_work' => 'WorkPhone',
            'primary_address_city' => 'City',
            'primary_address_country' => 'CountryName',
            'title' => 'JobTitle'
        );

        $addressField = 'primary_address_street';
        $zipField = 'primary_address_postalcode';

        return array('sugarMaster' => $sugarMasterFields,
            'simpleFields' => $simpleFields,
            'addressField' => $addressField,
            'zipField' => $zipField);
    }

    private static function MapFromSugarCompany($cc, $sc) {
        $sugarMasterFields = array(
            'email1' => 'EmailAddress',
            'name' => 'CompanyName'
        );

        $addressField = 'billing_address_street';
        $zipField = 'billing_address_postalcode';

        $simpleFields = array(
            'phone_office' => 'WorkPhone',
            'billing_address_city' => 'City',
            'billing_address_country' => 'CountryName'
        );

        return array(
            'sugarMaster' => $sugarMasterFields,
            'simpleFields' => $simpleFields,
            'addressField' => $addressField,
            'zipField' => $zipField
        );
    }

    private function updateXMLEntry($xmlFeed, $person) {
        if (!is_object($person)) {
            return null;
        }
        
        $xmlFeed = CCXml::ParseXml($xmlFeed);
        $xc = $xmlFeed->content->Contact;

        $xc->Status = 'Active';
        $xc = $this->MapFromSugarRecord($xc, $person);
        $pIDs = $this->GetRelatedPLIDs($person);
        unset($xc->ContactLists);
        $xlists = $xc->addChild('ContactLists', '');

        foreach ($pIDs as $id) {
            $tempChild = $xlists->addChild('ContactList', '');
            $tempChild->addAttribute('id', $id);
        }
        return $xmlFeed;
    }

    private function FromSugarPerson($sugarPerson, $u) {
        $ccContact = new CCContact($u);
        $ccContact = $this->MapFromSugarRecord($ccContact, $sugarPerson);
        $pIDs = $this->GetRelatedPLIDs($sugarPerson);
        foreach ($pIDs as $id) {
            $ccContact->ContactLists[] = $id;
        }
        if (isset($sugarPerson->cc_id) && $sugarPerson->cc_id != null && $sugarPerson->cc_id !== "") {
            $ccContact->cc_id = $sugarPerson->cc_id;
        }
        return $ccContact;
    }

    public function OptOut($sugarPerson) {
        global $db;
        if(!is_object($sugarPerson)) {
            CCLog::log('Non-object passed to SugarCCPerson::OptOut', 'fatal');
            return;
        }
        $table = $sugarPerson->table_name;
        if($table != 'contacts' && $table != 'leads' && $table != 'prospects' && $table != 'accounts') return;
        
        $query = "UPDATE $table SET cc_optout = 1, cc_lists = '' WHERE id = '{$sugarPerson->id}'";
        $db->query($query);
        $this->UpdateSugarListRelations($sugarPerson, false);
    }

    /**
     * Update the prospect list relationships based on the list field.
     *
     * @param $sugarPerson Person
     * @param $triggerHook bool Whether to trigger the after_relationship_add logic hook
     */
    private function UpdateSugarListRelations($sugarPerson, $triggerHook = false) {
        require_once('modules/ProspectLists/ProspectList.php');
        $GLOBALS['fbsg_plhook'] = ($triggerHook ? true : false);
        global $db;
        if (!$sugarPerson) {
            unset($GLOBALS['fbsg_plhook']);
            return;
        }

        $listNames = array();

        $pSeed = new ProspectList();
        $sugarPerson->load_relationship('prospect_lists');
        $sugarPerson->prospect_lists->get();
        $ctctLists = $pSeed->get_full_list('', 'prospect_lists.cc_id IS NOT NULL');
        $contactListsRaw = isset($sugarPerson->cc_lists) 
            ? SugarCC::ExplodeCaretDelimited($sugarPerson->cc_lists)
            : array();
        $contactLists = array();

        foreach ($ctctLists as $ccl) {
            $contactLists[$ccl->name] = $ccl->id;
        }
        foreach ($contactLists as $k => $v) {
            $nameIndex = array_search($k, $contactListsRaw);
            if ($nameIndex !== false) {
                $sugarPerson->prospect_lists->add($v);
                $listNames[] = $k;
            } else {
                $query = "UPDATE prospect_lists_prospects SET deleted = 1 WHERE related_type = {$db->quoted($sugarPerson->module_name)} "
                       . "AND related_id = '{$db->quote($sugarPerson->id)}' AND prospect_list_id = '{$db->quote($v)}'";
                $db->query($query);
            }
        }

        return $listNames;

        unset($GLOBALS['fbsg_plhook']);
    }

    public function getListNames($bean) {
        $bean->load_relationship('prospect_lists');
        $lists = $bean->prospect_lists->get();
        $names = array();
        $plBean = new ProspectList();

        foreach($lists as $list) {
            if($plBean->retrieve($list) && !empty($plBean->cc_id) && !($plBean->deleted)) {
                $names[] = $plBean->name;
            }
        }

        sort($names, SORT_STRING);

        return $names;
    }
    
    public function Sync(&$person, $updateRels = true) {
        global $db;

        if(empty($person->email1)) {
            CCLog::Log('CCI Error: ' . $person->object_name . ' id ' 
                     . $person->id . ' did not have an email address.', 'info');

            fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", false, self::$NoEmailMessage);
            return;
        }

        $existingEmail = false;
        $person->load_relationships();
        if($updateRels) $addedLists = $this->UpdateSugarListRelations($person, true);

        $ccContact = new CCContact($this->utility);
        
        //We've synced this before, so just update it from CC (this keeps fields not tracked
        //on Sugar intact)
        if (!empty($person->cc_id)) {
            $existingEmail = $ccContact->GetByCCID($person->cc_id, true);
        }
        //Otherwise, we gotta get it from CC
        else {
            $existingEmail = $ccContact->GetByEmail($person->email1, true);
        }
        //Never synced before, and doesn't exist on CC: transform the contact
        //into a CC xml record and post it up, keeping track of the id given on
        if (!$existingEmail) {
            $ccContact = $this->FromSugarPerson($person, $this->utility);
            CCLog::Log('Attempted Post: ' . $ccContact->ToXMLEntry(), 'debug');
            $response = $ccContact->Send('POST');


            if ($response && $response['status'] < 400) {
                $xmlContact = CCXml::ParseXml($response['data']);
                $contactAttributes = $xmlContact->content->Contact->attributes();
                //Update the contact bean with the ID.
                $person->cc_id = (string)$contactAttributes['id'];
                $query = "UPDATE ".$person->table_name." SET cc_id = '" .
                        urldecode($contactAttributes['id']) .
                        "' WHERE ".$person->table_name.".id = '" . $person->id . "'";
                $db->query($query);
                fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", false, "New Contact created on CC on lists " . implode(', ', $addedLists));
            }
        }
        //Whether we've synced before or we just got the contact for the first time,
        //we now have the full record. Update and save.
        else {
            $existingEmail = CCXml::ParseXml($existingEmail);
            if($existingEmail === null) {
                CCLog::Log('[fbsg_cci][SugarCCPerson][Sync]Got malformed XML from CC', 'fatal');
                fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", true, "Malformed response from CC");
                return;
            }
            
            if (((string)$existingEmail->content->Contact->Status) == 'Do Not Mail') {
                fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", false, "Contact Opted out on CC");
                $this->OptOut($person);
                return;
            } else {
                $existingEmail = $this->updateXMLEntry($existingEmail, $person);
                $cc_id = urldecode((string)$existingEmail->id);
                $person->cc_id =$cc_id;
                $query = "UPDATE ".$person->table_name." SET cc_id = '" . $cc_id . "' WHERE ".$person->table_name.".id = '" . $person->id . "'";
                $db->query($query);
                CCLog::Log('Attempted Put: ' . $existingEmail->asXML(), 'debug');
                $response = $this->utility->Put($cc_id, $existingEmail->asXML());


                if($response['status'] >= 400) {
                    fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", false, "Error while updating CC contact: " . $response['data']);
                } else {
                    fbsg_CCIntegrationLog::LogBeanInteraction($person, "Sync on Save", false, "Contact updated on CC with lists " . implode(', ', $addedLists));
                }
            }
        }
        //$this->GetContactCampaigns($person);
    }

    private static function GetPersonIdByEmailAddress($email, $type = null) {
        global $db;
        if($type != 'Contacts' && $type != 'Leads' && $type != 'Prospects' && $type != 'Accounts') {
            $type = null;
        }

        $typeQuery = $type !== null 
            ? "eabr.bean_module = {$db->quoted($type)}"
            : "(eabr.bean_module = 'Accounts' or eabr.bean_module = 'Contacts' or eabr.bean_module = 'Leads' or eabr.bean_module = 'Prospects')";
        
        $query = "select eabr.bean_id, eabr.bean_module from email_addr_bean_rel eabr "
                ."inner join email_addresses ea on eabr.email_address_id = ea.id "
                ."where ea.email_address_caps = '" . $db->quote(strtoupper($email)) . "' and eabr.deleted = 0 and $typeQuery "
                . " and ea.deleted = 0"
                . " order by eabr.bean_module";

        return $db->query($query);
    }

    public static function GetPersonByEmailAddress($email, $type = null) {
        global $db;
        $results = self::GetPersonIdByEmailAddress($email, $type);

        if(!$results) return null;

        while($row = $db->fetchByAssoc($results)) {
            if($row['bean_module'] == 'Accounts' && (!$type || $type == 'Accounts')) {
                $seed = new Account();
                if(!$seed->retrieve($row['bean_id']) || $seed->deleted) continue;
                return $seed;
            }
            else if($row['bean_module'] == 'Contacts' && (!$type || $type == 'Contacts')) {
                $seed = new Contact();
                if(!$seed->retrieve($row['bean_id']) || $seed->deleted) continue;
                return $seed;
            } else if($row['bean_module'] == 'Leads' && (!$type || $type == 'Leads')) {
                $seed = new Lead();
                if(!$seed->retrieve($row['bean_id']) || $seed->deleted) continue;
                return $seed;
            } else if($row['bean_module'] == 'Prospects' && (!$type || $type == 'Prospects')) {
                $seed = new Prospect();
                if(!$seed->retrieve($row['bean_id']) || $seed->deleted) continue;
                return $seed;
            }
        }


        return null;
    }
}
