<?php

class SugarIncrementalSync {
    protected $syncModules = array('accounts', 'contacts', 'leads', 'prospects');

    protected $utility;

    protected $syncHistoryTable = 'fbsg_sync_history';
    protected $syncNewContactsTo;

    /*
     * $ut CCConnector
     * $newContactsModule string Module to sync new contacts to, or null to not create new
     * $syncModules array Modules to check for existing records
     */
    public function __construct(CCConnector $ut, $newContactsModule = null, $syncModules = null) {
        $this->syncModules = $syncModules === null ? $this->syncModules : $syncModules;
        $this->syncNewContactsTo = $newContactsModule;
        $this->utility = $ut;
    }


    /*
     * Get the last sync link for the provided list. This will only be populated if either
     * the last sync process for this list was interrupted, or if the sync is currently ongoing.

     * @param string $listId The CC ID of the list (purely the ID, not the full URL)
     */
    private function GetLastSyncLink($listId) {
        global $db;

        $query = "select last_updated_link from {$this->syncHistoryTable} where cc_list_id = {$db->quoted($listId)}";
        return $db->getOne($query);
    }

    private function GetLastUpdateDate($listId) {
        global $db, $timedate;

        $updatedSince = $db->getOne("select updated_since from {$this->syncHistoryTable} where cc_list_id = {$db->quoted($listId)}");
        $GLOBALS['log']->info("[CCI][SugarIncrementalSync][GetLastUpdateDate] Got $updatedSince from the database");

        return $updatedSince === false
            ? SugarDateTime::createFromFormat('Y-m-d', '2001-01-01')
            : $timedate->fromDb($updatedSince);
    }

    private function SetLastSyncLink($listId, $linkId, $updatedSince) {
        global $db, $timedate;
        $listRecordExists = $db->getOne("select cc_list_id from {$this->syncHistoryTable} where cc_list_id = {$db->quoted($listId)}");

        if($listRecordExists) {
            if($linkId !== false) {
                $db->query("update {$this->syncHistoryTable} set last_updated_link = {$db->quoted($linkId)}, updated_since = {$db->quoted($timedate->asDb($updatedSince))}
                    WHERE cc_list_id = {$db->quoted($listId)}");
            } else {
                $db->query("update {$this->syncHistoryTable} set updated_since = {$db->quoted($timedate->asDb($updatedSince))}
                    WHERE cc_list_id = {$db->quoted($listId)}");
            }
        } else {
            $db->query("insert into {$this->syncHistoryTable} (cc_list_id, last_updated_link, updated_since) 
                VALUES ({$db->quoted($listId)}, {$db->quoted($linkId)}, {$db->quoted($timedate->asDb($updatedSince))})");
        }
    }

    private function GetUpdatedSinceUrl($listId, $date) {
        global $timedate;

        $GLOBALS['log']->info("[CCI][SugarIncrementalSync][GetUpdatedSinceUrl]: Incoming date = " . print_r($date, true));

        $endpoint = $this->utility->GetEndpoint('contacts');
        if(!is_object($date)) {
            $GLOBALS['log']->fatal('$date is not an object: ' . print_r($date, true));
            $formattedDate = '';
        } else {
            $formattedDate = $date->format('Y-m-d\TH:i:s.u\Z');
        }

        if($listId === 'do-not-mail') {
            return $endpoint . "?" . ($formattedDate ? "updatedsince=$formattedDate&" : "") . "listtype=do-not-mail";
        }

        return $endpoint . "?" . ($formattedDate ? "updatedsince=$formattedDate&" : "") . "listid=$listId";
    }

    private function GetNextRecords($endpoint) {
        if(!$endpoint) return null;

        $result = $this->utility->GetData($endpoint);
        if($result['status'] >= 400 || empty($result['data'])) {
            return null;
        }
        

        $parsedRecords = CCXml::ParseXml($result['data']);
        if($parsedRecords === null) {
            CCLog::Log("[fbsg_cci][SugarIncrementalSync][GetNextRecords] Error parsing during auto sync.", 'fatal');
            return null;
        }
        
        return $parsedRecords;
    }

    private function GetNextLink($atom) {
        $links = CCXml::GetLinks($atom);
        return empty($links['next']) ? null : $this->utility->cc_base_url . $links['next'];
    }

    private static function GetSugarDbTime($ccDateTime) {
        if($ccDateTime instanceof DateTime) return $ccDateTime;
        $ccDateTime = preg_replace('/\.\d+Z$/', '', $ccDateTime);
        $ccDateTime = str_replace('T', ' ', $ccDateTime);
        return $ccDateTime 
            ? SugarDateTime::CreateFromFormat('Y-m-d H:i:s', $ccDateTime) 
            : SugarDateTime::createFromFormat('Y-m-d', '2001-01-01');
    }

    public function SyncList($listId) {
        $lastSyncLink = $this->GetLastSyncLink($listId);
        $updatedSince = $this->GetLastUpdateDate($listId);
        $GLOBALS['log']->info("[CCI][SugarIncrementalSync][SyncList] Got $updatedSince from the GetLastUpdateDate");

        $listCcid = $this->utility->GetEndpoint('lists', $listId);
        $sugarList = SugarCCList::GetSugarListByCcId($listCcid);

        if(!$sugarList) {
            $GLOBALS['log']->info("[SugarIncrementalSync][SyncList][fbsg_cci]: Could not retrieve the Sugar list with cc_id $listCcid");
        } else {
            foreach(array('contacts', 'leads', 'accounts', 'prospects') as $beanType) {
                $sugarList->load_relationship($beanType);
            }
        }

        $nextEndpoint = $lastSyncLink 
            ? $lastSyncLink 
            : $this->GetUpdatedSinceUrl($listId, $updatedSince);

        $records = $this->GetNextRecords($nextEndpoint);
        $this->SetLastSyncLink($listId, $this->GetNextLink($records), self::GetSugarDbTime($updatedSince));

        $latestUpdateTime = $updatedSince;

        $ccPerson = new SugarCCPerson($this->utility);

        $syncedRecords = 0;
        $createdRecords = 0;

        while($records !== null) {
            $nextEndpoint = $this->GetNextLink($records);
            foreach($records->entry as $entry) {
                $contact = $entry->content->Contact;
                $bean = SugarCCPerson::GetPersonByEmailAddress((string)$contact->EmailAddress);
                $newRecord = false;

                if(!$bean) {
                    switch($this->syncNewContactsTo) {
                        case 'Accounts':
                            $bean = new Account();
                            break;
                        case 'Contacts':
                            $bean = new Contact();
                            break;
                        case 'Leads':
                            $bean = new Lead();
                            break;
                        case 'Prospects':
                            $bean = new Prospect();
                            break;
                        default:
                            break;
                    }
                    if(!$bean) continue;
                    $newRecord = true;
                    SugarCCPerson::MapToSugarRecord($contact, $bean, true);
                    $createdRecords++;

                } else {
                    SugarCCPerson::MapToSugarRecord($contact, $bean, false);
                }
                $bean->cc_sync = '1';
                if($listId !== 'do-not-mail') $bean->cc_optout = 0;
                $bean->save();
                $syncedRecords++;
                if($listId !== 'do-not-mail') {
                    if($sugarList) $sugarList->{$bean->table_name}->add($bean->id);
                    fbsg_CCIntegrationLog::LogBeanInteraction($bean, "Automatic Sync from CC", false, 
                        $newRecord ? "Contact Created from CC" : "Contact Lists updated from CC");
                } else {
                    $ccPerson->OptOut($bean);
                    fbsg_CCIntegrationLog::LogBeanInteraction($bean, "Automatic Sync from CC", false,
                        "Contact Opted Out on CC");
                }
                $latestUpdateTime = self::GetSugarDbTime($contact->LastUpdateTime);
                self::SetLastSyncLink($listId, false, $latestUpdateTime);
            }
            self::SetLastSyncLink($listId, $nextEndpoint, $latestUpdateTime);

            $records = $this->GetNextRecords($nextEndpoint);
        }
        echo "List $listId. Records Created: {$createdRecords} Records Updated: {$syncedRecords}\n<br>";
        return array($createdRecords, $syncedRecords);
    }

    public function SyncAllLists() {
        global $db;

        $query = "select cc_id from prospect_lists where cc_id is not null and deleted = 0";
        $results = $db->query($query);

        while($row = $db->fetchByAssoc($results)) {
            if(preg_match('/\/lists\/(?P<listId>[\d]+)$/', $row['cc_id'], $match)) {
                $this->SyncList($match['listId']);
            }
        }
        $this->SyncList('do-not-mail');
        return;
    }
}
