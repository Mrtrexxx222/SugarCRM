<?php

function cc_sync($focus, $field, $value, $view) {
    if(!isset($focus->cc_id) || (!$focus->cc_id)) {
            return 'Not a Constant Contact Marketing List';
    }
    if($view === 'DetailView') {
        $html = '<script type="text/javascript" src="modules/fbsg_ConstantContactIntegration/include/js/cc_list_sync.js"></script>';
        return $html.cc_sync_detail($focus, $field, $value);
    }
    
    return '';
}

function cc_sync_detail($focus, $field, $value) {
    return '<input type="button" id="cc_sync_button" name="cc_sync_button" value="Sync to Constant Contact" '.
                  'onclick="fbsg_CCSync.syncList(\'' . $focus->id . '\')">';
}