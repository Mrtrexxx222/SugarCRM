<?php

class CsvParser {

    var $data;
    private $state;
    private $curField;
    private $lineFields;
    private $rows;
    private $curIndex = 0;
    private $headers = null;
    private $headerDefs;

    public function __construct($input, $headersFirst = false, $headerDefs = null) {
        $this->data = $input;
        $this->state = 1;
        $this->curField = '';
        $this->lineFields = array();
        $this->rows = array();
        if ($headersFirst) {
            $this->headers = $this->ProcessRow();
        }
        $this->headerDefs = $headerDefs;

    }

    private function writeField() {
        $this->lineFields[] = $this->curField;
        $this->curField = '';
    }

    private function writeRow() {
        $this->rows[] = $this->lineFields;
        $this->lineFields = array();
    }
    
    public function ProcessRow() {
        $this->state = 1;
        $this->curField = '';
        $this->lineFields = array();
        for($i = $this->curIndex; $i < strlen($this->data); $i++) {
            $c = $this->data[$i];
            switch($this->state) {
                case 1:
                    $this->state = $this->FieldStart($c);
                    break;
                case 2:
                    $this->state = $this->ScanQuoted($c);
                    break;
                case 3:
                    $this->state = $this->ScanText($c);
                    break;
                case 4:
                    $this->state = $this->FieldEnd($c);
                    break;
            }
            if($this->state === 5) {
                $this->curIndex = $i + 1;
                return count($this->lineFields) ? ($this->headers ? $this->LabelRow($this->lineFields) : $this->lineFields) : null;
            }
        }
        if($this->curField) {
            $this->writeField();
        }
        $this->curIndex = $i+1;
        return count($this->lineFields) ? ($this->headers ? $this->LabelRow($this->lineFields) : $this->lineFields) : null;
    }

    public function Process($oneRow = false) {
        if ($oneRow) {
            $this->state = 1;
            $this->curField = '';
            $this->lineFields = array();
        }
        for ($i = $oneRow 
                ? ($this->curIndex <= strlen($this->data) 
                    ? $this->curIndex 
                    : strlen($this->data)) 
                : 0; $i < strlen($this->data); $i++) {
            $c = $this->data[$i];
            switch ($this->state) {
                case 1:
                    $this->state = $this->StartNewField($c);
                    break;
                case 2:
                    $this->state = $this->ScanQuoted($c);
                    break;
                case 3:
                    $this->state = $this->ScanText($c);
                    break;
                case 4:
                    $this->state = $this->FieldEnd($c);
                    break;
                case 5:
                    $i = $i > 0 ? $i - 1 : 0;

                    if ($oneRow) {
                        if ($this->curField) {
                            $this->writeField();
                        }
                        $this->curIndex = $i + 1;
                        return $this->lineFields;
                    }
                    $this->state = 1;
                    $this->writeRow();
                    break;
            }
        }
        if ($this->curField) {
            $this->writeField();
        }
        if ($oneRow) {
            $this->curIndex = $i;
            $this->rows = null;
            return $this->lineFields;
        }
        if ($this->lineFields) {
            $this->writeRow();
        }
        return $this->rows;
    }

    //state 1
    public function FieldStart($c) {
        switch ($c) {
            case ' ':
            case "\r":
                return 1;
            case ',':
                $this->writeField();
                return 1;
            case "\n":
                if(count($this->lineFields)) {
                    $this->writeField();
                    return 5;
                }
                else return 1;
            case '"':
                return 2;
            default:
                $this->curField .= $c;
                return 3;
        }
    }

    //state 2
    public function ScanQuoted($c) {
        switch ($c) {
            case '"':
                return 4;
            default:
                $this->curField .= $c;
                return 2;
        }
    }

    //state 3
    public function ScanText($c) {        
        switch ($c) {
            case "\n":
                $this->writeField();
                return 5;
            case "\r":
                return 3;
            case ',':
                $this->writeField();
                return 1;
            default:
                $this->curField .= $c;
                return 3;
        }
    }

    //state 4
    public function FieldEnd($c) {
        switch ($c) {
            case '"':
                $this->curField .= '"';
                return 2;
            case ' ':
            case "\r":
                return 4;
            case ',':
                $this->writeField();
                return 1;
            case "\n":
                $this->writeField();
                return 5;
            default:
                $this->writeField();
                return 5;
        }
    }
    
    private function LabelRow($row) {
        $ret = Array();
        $count = 0;
        foreach ($this->headers as $header) {
            if ($this->headerDefs[$header]) {
                $ret[$this->headerDefs[$header]] = $row[$count];
            } else {
                $ret[$header] = $row[$count];
            }
            $count++;
        }
        return $ret;
    }
}
