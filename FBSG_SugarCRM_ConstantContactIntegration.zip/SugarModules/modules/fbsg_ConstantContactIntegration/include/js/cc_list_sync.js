var fbsg_CCSync = (function() {
    var Y = YUI().use('node', 'json');
    
    function ShowMessage(m, ty, ti) {
        YAHOO.SUGAR.MessageBox.show({
            type: ty,
            title: ti,
            msg: m
        });
    }
    
    return {
        syncList: function(id) {
            var uri = 'index.php',
                postdata = 'module=fbsg_ConstantContactIntegration&action=sync_prospect_list&id=' + id,
                callback = {
                    success: function(o) {
                        try {
                            var response = Y.JSON.parse(o.responseText);
                            if(response.error) {
                                ShowMessage('There was an error syncing this list to CC: ' 
                                            + response.error, 'alert', 'Error');
                            } else {
                                var message = (response.background ? 'Due to its size, this list will be sent in the background.' : 'List sent to CC.');
                                ShowMessage(message, 'info', 'Success');
                            }
                        } catch(e) {
                            ShowMessage('There was an error syncing this list to CC.', 'alert', 'Error');
                        }
                    },
                    failure: function(o) {
                        ShowMessage('There was an error syncing this list to CC.', 'alert', 'Error');
                    },
                    timeout: 30000
                };
                
                ShowMessage('Syncing this list to Constant Contact...', 'info', 'Syncing');
                YAHOO.util.Connect.asyncRequest("POST", uri, callback, postdata);
        }
    }
})();
