var FBSG_CCConfig = (function() {
	var Y = YUI().use('node', 'json');
	function handleSuccess(o, m, name) {
		if (parseInt(o.responseText, 10) < 400) {
			YAHOO.SUGAR.MessageBox.show({
				type : "alert",
				title : "Info",
				msg : m
			});
		} else {
			YAHOO.SUGAR.MessageBox.show({
				type : "alert",
				title : "Error",
				msg : o.responseText
			});
		}
	}

	function handleFailure(m) {
		YAHOO.SUGAR.MessageBox.show({
			type : "alert",
			title : "Error",
			msg : m
		});
	}

	function asyncCB(m, name, s, f) {
		this.success = (typeof (s) === 'function') ? function(o) {
			s(o, m, name);
		} : function(o) {
			handleSuccess(o, m, name);
		};
		this.failure = (typeof (f) === 'function') ? function(o) {
			f(o, m);
		} : function(o) {
			if (m === undefined || m === '') {
				m = 'There was a error communicating with Sugar.';
			}
			handleFailure(m);
		};
		this.argument = {
			message : m
		};
		this.timeout = 30000;
	}

	function campaign_success(o, m, name) {
		var response, ids, i;
		try {
			response = Y.JSON.parse(o.responseText);
		} catch (e) {
			handleFailure("There was an error communicating with Sugar.");
			return;
		}
		ids = [];
		if (parseInt(response.code, 10) < 400) {
			for (i = 0; i < response.ids.length; i++) {
				ids.push(response.ids[i]);
			}
			getallcamdets(ids, name);
		} else {
			handleFailure('There was an error connecting to Constant Contact');
		}
	}

	function export_success(o, m, d, name) {
		var response = o.responseText;
		d.append('Response was ' + response);
	}

	function removed_success(o, m, name) {
		redirectSugar('?module=fbsg_ConstantContactIntegration&action=config');
	}

	function test_success(o, m, name) {
		try {
			var response = Y.JSON.parse(o.responseText);
			if (!response.success) {
				handleFailure('Authorization failed. Please check the username and password and try again.');
			} else {
				document.forms['AddCCAccount'].submit();
			}
		} catch (e) {
			handleFailure('There was an error communicating with Sugar.');
		}
	}

	function ShowMessage(m, ty, ti) {
		YAHOO.SUGAR.MessageBox.show({
			type : ty,
			title : ti,
			msg : m
		});
	}

	function getallcamdets(ids, name) {
		outerProgress = "Getting " + ids.length +
				" campaign details from Constant Contact...";
		ShowMessage(outerProgress, "plain", "Campaigns");
		var total, errors, statuses, campaignHelper;

		total = 0;
		errors = 0;
		statuses = [];

		campaignHelper = function(ids, name) {
			var helperProgress = "Grabbed " + total +
					" campaign details from Constant Contact...";
			var innerProgress = 'Retrieving results, please wait';
			innerLoop = function(state) {
				var uri, postdata, progressString, cb;
				innerProgress += '.';
				ShowMessage(outerProgress + '<br>' + helperProgress + '<br>' +
						innerProgress, "plain", "Campaigns");

				uri = 'index.php';
				postdata = 'module=fbsg_ConstantContactIntegration&action=getcampaignevents&accountname=' +
						name + '&state=' + state;
				cb = {
					'success' : function(o) {
						try {
							response = Y.JSON.parse(o.responseText);
						} catch (e) {
							campaignHelper(ids, name);
							return;
						}
						if (response.status) {
							campaignHelper(ids, name);
						} else {
							innerLoop(o.responseText);
						}
					},
					'failure' : function(o) {
						campaignHelper(ids, name);
					},
					'timeout' : 30000
				};
				YAHOO.util.Connect.asyncRequest("POST", uri, cb, postdata);
			};
			var progressString, uri, postdata, cb, camID;
			if (!(ids.hasOwnProperty('length')) || ids.length === 0) {
				ShowMessage(
						"Retrieved all campaigns and results from Constant Contact.",
						"alert", "Complete");
				return 0;
			}
			camID = ids[0];
			ids = ids.slice(1, ids.length);
			progressString = 'Grabbed ' + total +
					' campaigns from Constant Contact...';
			uri = 'index.php';
			postdata = 'module=fbsg_ConstantContactIntegration&action=getcampaignevents&accountname=' +
					name + '&ccid=' + camID;
			cb = {
				'success' : function(o) {
					var response, uri, postdata, progressString, cb;
					progressString = 'Grabbed ' + total +
							' campaigns from Constant Contact...';
					total += 1;
					try {
						response = Y.JSON.parse(o.responseText);
					} catch (e) {
						handleFailure("There was an error communicating with Sugar.");
						return;
					}
					if (response.status) {
						getallcamdets(ids, name);
					} else {
						innerLoop(o.responseText);
					}
				},
				'failure' : function(o) {
					campaignHelper(ids, name);
				},
				'timeout' : 30000
			};
			YAHOO.util.Connect.asyncRequest("POST", uri, cb, postdata);

		};

		campaignHelper(ids, name);
	}

	function redirectSugar(l) {
		var addBar = window.location.toString(),
			indexRoot = addBar.indexOf('index.php'),
			sugarRoot = indexRoot === -1 ? addBar +
				'index.php' : addBar.substring(0, indexRoot + 9),
			redirectURL = sugarRoot + l;

		document.location = redirectURL;
	}

	function sugarAsync(name, postdata, success, failure, message, method) {
		var uri = 'index.php', callback = new asyncCB('', name, success,
				failure);
		ShowMessage(message, "plain", "Connecting...");
		YAHOO.util.Connect.asyncRequest(method, uri, callback, postdata);
	}

	function getSaveIndex() {
		var f = document.forms["fbsg_schedule"], i = 0;
		for (i = 0; i < f.length; i++) {
			if (f[i].checked)
				return i;
		}
		return i;
	}

	return {
		getlists : function(name) {
			var postdata = 'module=fbsg_ConstantContactIntegration&action=getlists&accountname=' + name,
				message = '<p>Getting contact lists from Constant Contact...</p>';
			sugarAsync(name, postdata, null, null, message, "POST");
		},

		getcampaigns : function(name) {
			var uri = 'index.php',
				postdata = 'module=fbsg_ConstantContactIntegration&action=getcampaigns&accountname=' +
					name + '&XDEBUG_PROFILE',
				callback = new asyncCB('', name, campaign_success);
			ShowMessage('Getting campaign data from Constant Contact...',
					"plain", "Campaigns");
			YAHOO.util.Connect.asyncRequest("POST", uri, callback, postdata);
		},

		createexportjobs : function(name) {
			var postdata = 'module=fbsg_ConstantContactIntegration&action=createexportjobs&accountname=' + name,
				message = 'Creating contact export jobs on Constant Contact...';
			sugarAsync(name, postdata, export_success, null, message, "POST");
		},

		saveschedule : function(name) {
			var saveIndex = getSaveIndex(), postdata = 'module=fbsg_ConstantContactIntegration&action=saveschedule&accountname=' +
				name + '&sindex=' + saveIndex,
				uri = 'index.php',
				div = Y.one('#fbsg_schedprogress'),
				callback = new asyncCB('',
					name, function(o, m, name) {
						div.setContent('');
					}, function(o, m, name) {
						d.SetContent('Connection Error');
					}
				);
			div.setContent('Saving...');
			YAHOO.util.Connect.asyncRequest("POST", uri, callback, postdata);
		},

		removeaccount : function(name) {
			var postdata = 'module=fbsg_ConstantContactIntegration&action=removeaccount&accountname=' + name,
				message = 'Removing account...';
			sugarAsync(name, postdata, removed_success, null, message, "POST");
		},

		testandadd : function() {
			var aname = document.forms['AddCCAccount']['ccemail'].value,
				pass = document.forms['AddCCAccount']['ccpassword'].value,
				pkey = document.forms['AddCCAccount']['cckey'].value,
				postdata = 'module=fbsg_ConstantContactIntegration&action=testwithcreds&username=' +
					aname + '&pass=' + pass + '&pkey=' + pkey,
				message = '<p>Testing credentials...</p>';

			sugarAsync(name, postdata, test_success, null, message, "POST");
		},

		synclists : function(name) {
			var uri = 'index.php',
				postdata = 'module=fbsg_ConstantContactIntegration&action=sync_lists&accountname=' + name,
				callback = new asyncCB(
					'',
					name,
					function(o, m, n) {
						var res;
						try {
							res = Y.JSON.parse(o.responseText);
							if (res.error) {
								ShowMessage('There was an error: ' + res.error,
										'alert', 'Error');
							} else {
								ShowMessage(res.message, 'alert', 'Info');
							}
						} catch (e) {
							ShowMessage(
									'There was an error. Please refresh the page and try again.',
									'alert', 'Error');
						}
					}
				);
			ShowMessage('Syncing lists...', 'info', 'Syncing...');
			YAHOO.util.Connect.asyncRequest("POST", uri, callback, postdata);
		},

		setleadsource : function(name, lead_source) {
			var uri = 'index.php';
			var postdata = 'module=fbsg_ConstantContactIntegration&action=set_lead_source&accountname=' +
				name + '&lead_source=' + lead_source;
			var cb = {
				success : function(o) {
					ShowMessage('Lead Source Set to ' + lead_source, 'info',
							'Setting Lead Source');
					document.getElementById('update_key').submit();
				},
				failure : function(o) {
					ShowMessage('Failed to update lead source', 'info',
							'Setting Lead Source');
				},
				timeout : 30000
			};
			ShowMessage('Setting Lead Source for new leads to ' + lead_source + '...', 'info', 'Setting Lead Source');
			YAHOO.util.Connect.asyncRequest("POST", uri, cb, postdata);
		},

		updateOptout : function(name) {
			var uri = 'index.php';
			var postdata = 'module=fbsg_ConstantContactIntegration&action=update_optouts&accountname=' + name;

			var cb = {
				success: function(o) {
					var res;
					try {
						res = Y.JSON.parse(o.responseText);
						if(res.error) {
							ShowMessage('There was an error: ' + res.error,
								'alert', 'Error');
						} else {
							ShowMessage(res.message, 'alert', 'Info');
						}
					} catch(e) {
						ShowMessage('There was an error while updating optout status. Please refresh the page and try again.',
							'alert', 'Error');
					}
				},
				failure: function(o) {
					ShowMesage('There was an error while updating optout status. Please refresh the page and try again.',
						'alert', 'Error');
				}
			};

			ShowMessage('Setting CC Optout status. This may take a few minutes.',
				'info', 'Setting Optout Status...');
			YAHOO.util.Connect.asyncRequest("POST", uri, cb, postdata);
		}
	};
}());

function confirm_account_removal (name) {
	r = confirm('Are you sure you want to remove the account?');
	if (r) {
		FBSG_CCConfig.removeaccount(name);
	}
}

$(document).ready(function() {
	// When user clicks on tab, this code will be executed
	$("#fbsgtabs li").click(function() {
		// First remove class "active" from currently active tab
		$("#fbsgtabs li").removeClass('active');

		// Now add class "active" to the selected/clicked tab
		$(this).addClass("active");

		// Hide all tab content
		$(".fbsgtab_content").hide();

		// Here we get the href value of the selected tab
		var selected_tab = $(this).find("a").attr("href");

		// Show the selected tab content
		$(selected_tab).fadeIn();

		// At the end, we add return false so that the click on the link is not
		// executed
		return false;
	});
});