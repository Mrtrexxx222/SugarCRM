var FBSG_CCImport = (function() {
    var update_table_timer = [];
    var progress_meter_timer = [];
    update_table_timer.timerStep = 15000;
    update_table_timer.startTime = 0;
    progress_meter_timer.timerStep = 100;
    progress_meter_timer.active = false;

    function ShowMessage(m, ty, ti) {
        YAHOO.SUGAR.MessageBox.show({
            type : ty,
            title : ti,
            msg : m
        });
    }
    
    return {
        UpdateProgressMeter: function () {
            var meter_percent = 100 - ((update_table_timer.timerStep - ( (new Date()).getTime() - update_table_timer.startTime ))/update_table_timer.timerStep * 100);
            document.getElementById('progress_meter').style.width = meter_percent + '%';
            progress_meter_timer.timer = setTimeout('FBSG_CCImport.UpdateProgressMeter()', progress_meter_timer.timerStep);
        },
        
        BeginCCExport: function () {
            var url = 'index.php?module=csync_cc_sync_table&action=start_cc_export';
            document.getElementById('cc_export_button').disabled=true;
            document.getElementById('import_status').innerHTML = 'Please Wait...';
            var that = this;

            var cb = {
                success: function(o) {
                    var span_el = document.getElementById('import_status');
                    span_el.innerHTML = 'CC Export Initiated';
                    span_el.style.color = '#444444';
                    document.getElementById('cc_export_button').disabled=false;
                    that.UpdateActivitiesTable();
                },
                failure: function(o) {
                    var span_el = document.getElementById('import_status');
                    span_el.innerHTML = "Error communicating with server";
                    span_el.style.color = 'red';
                    document.getElementById('cc_export_button').disabled=false;
                },
                timeout: 180000
            };

            YAHOO.util.Connect.asyncRequest("GET", url, cb);
        },

        UpdatePendingActivities: function () {
            var url = 'index.php?module=csync_cc_sync_table&action=update_pending_activities';

            var cb = {
                success: function(o) {
                    var span_el = document.getElementById('pending_activities');
                    span_el.innerHTML = o.responseText;
                    span_el.style.color = '#444444';
                    setTimeout('FBSG_CCImport.UpdatePendingActivities()', 15000);
                },
                failure: function(o) {
                },
                timeout: 10000
            };

            YAHOO.util.Connect.asyncRequest("GET", url, cb);
        },

        UpdateActivitiesTable: function () {
            var Y = YUI().use('json');
            var url = 'index.php?module=csync_cc_sync_table&action=update_activities_table';
            var progMeter = document.getElementById('progress_meter');
            clearTimeout(progress_meter_timer.timer);
            progress_meter_timer.active = false;
            if(progMeter === null) { return false; }
            progMeter.style.width = '100%';
            var cb = {
                success: function(o) {
                    var data;
                    try {
                        data = Y.JSON.parse(o.responseText);
                    } catch (err) {
                        return;
                    }
                    
                    var all_complete = true;

                    var temp_row;
                    if (data.length) {
                        document.getElementById('activities_table').style.display='block';
                    }

                    for (var i = 0; i < data.length; i++) {
                        temp_row = document.getElementById('row_' + data[i]['list_id']);
                        if (temp_row) {
                            if (data[i]['status'] == '1') {
                                document.getElementById('status_' + data[i]['list_id']).innerHTML = 'COMPLETE';
                            } else {
                                document.getElementById('status_' + data[i]['list_id']).innerHTML = 'PENDING';
                                all_complete = false;
                            }
                        } else {
                            var new_row = document.createElement('tr');
                            var new_name = document.createElement('td');
                            var new_status = document.createElement('td');

                            new_row.id = 'row_' + data[i]['list_id'];
                            new_row.style.width = '100%';
                            new_name.style.width = '80%';
                            new_name.innerHTML = data[i]['name'];
                            new_status.id = 'status_' + data[i]['list_id'];
                            new_status.style.width = '20%';

                            if (data[i]['status'] == '1') {
                                 new_status.innerHTML = 'COMPLETE';
                            } else {
                                 new_status.innerHTML = 'PENDING';
                                 all_complete = false;
                            }

                            new_row.appendChild(new_name);
                            new_row.appendChild(new_status);
                            document.getElementById('activities_table_body').appendChild(new_row);
                        }
                    }
                    if (!(all_complete)) {
                        update_table_timer.timer = setTimeout('FBSG_CCImport.UpdateActivitiesTable()', update_table_timer.timerStep);
                        update_table_timer.startTime = (new Date()).getTime();
                        document.getElementById('progress_row').style.display = '';
                        if (!(progress_meter_timer.active)) {
                            progress_meter_timer.active = true;
                            progress_meter_timer.timer = setTimeout('FBSG_CCImport.UpdateProgressMeter()', progress_meter_timer.timerStep);
                        }
                    } else {
                        document.getElementById('progress_row').style.display = 'none';
                    }
                    
                },
                failure: function(o) {
                },
                timeout: 10000
            };

            YAHOO.util.Connect.asyncRequest("GET", url, cb);
        },

        SyncTableToContactsLeads: function () {
            var Y = YUI().use('json');
            document.getElementById('sync_status').innerHTML = 'Please Wait...';
            var url = 'index.php';
            var postdata = 'module=csync_cc_sync_table&action=sync_table_to_contacts_leads';
            var query_array = [];
            if (document.getElementById('checkbox_contacts').checked) {
                query_array.push('Contacts');
            }
            if (document.getElementById('checkbox_leads').checked) {
                query_array.push('Leads');
            }
            if (document.getElementById('checkbox_targets').checked) {
                query_array.push('Prospects');
            }

            postdata += '&query_array=' + Y.JSON.stringify(query_array);

            var cb = {
                success: function(o) {
                    var span_el = document.getElementById('sync_status');
                    span_el.innerHTML = o.responseText;
                    span_el.style.color = '#444444';
                },
                failure: function(o) {
                },
                timeout: 30000
            };

            YAHOO.util.Connect.asyncRequest("POST", url, cb, postdata);
        },
        
        AutoImportSettings: function () {
            var Y = YUI().use('json');
            document.getElementById('auto_import_status').innerHTML = 'Please Wait...';
            var url = 'index.php';
            var postdata = 'module=fbsg_ConstantContactIntegration&action=auto_import_settings';
            var query_array = [];
            if (!document.getElementById('checkbox_enable').checked) {
                query_array.push('Disable');
            }
            if (document.getElementById('radio_contacts').checked) {
                query_array.push('Contacts');
            }
            if (document.getElementById('radio_leads').checked) {
                query_array.push('Leads');
            }
            if (document.getElementById('radio_targets').checked) {
                query_array.push('Prospects');
            }
            if(document.getElementById('radio_accounts').checked) {
                query_array.push('Accounts');
            }

            query_array.push($('#last_auto_update').val());

            postdata += '&query_array=' + Y.JSON.stringify(query_array);

            var cb = {
                success: function(o) {
                    var span_el = document.getElementById('auto_import_status');
                    span_el.innerHTML = o.responseText;
                    span_el.style.color = '#444444';
                },
                failure: function(o) {
                },
                timeout: 30000
            };

            YAHOO.util.Connect.asyncRequest("POST", url, cb, postdata);
        },

        updateSyncSentResults: function() {
            var params = {
                module: 'fbsg_ConstantContactIntegration',
                action: 'update_sync_sent_results',
                sync_sent: $('#sent_checkbox').prop('checked')
            };
            $.getJSON('index.php', params, function(data) {
                if(console && console.log) {
                    console.log("updated sync sent to " . $('#sent_checkbox').prop('checked'));
                }
            });
        },

        PerformFullAutomaticSync: function() {
            var timesRun = 0;
            ShowMessage("Performing automatic contact sync...", "plain", "Automatic Sync");


            var syncHelper = function() {
                $.get('index.php', {
                    module: 'fbsg_ConstantContactIntegration',
                    action: 'force_sched',
                    job: 'automatic_contact_sync'
                }).success(function() {
                    ShowMessage("Automatic Sync Completed!", "plain", "Automatic Sync");
                }).error(function() {
                    timesRun++;
                    ShowMessage("Continuing automatic sync, " + timesRun, "plain", "Automatic Sync");
                    syncHelper();
                });
            };

            syncHelper();
        }
    };
}());
YUI().use('event', function(Y){Y.on('domready', FBSG_CCImport.UpdateActivitiesTable);});

function update_auto_import_desitination () {
	if (document.getElementById('checkbox_enable').checked) {
		$('#auto_import_desitination').show();
        $('#auto_import_date').show();
    } else {
        $('#auto_import_desitination').hide();
        $('#auto_import_date').hide();
    }
}