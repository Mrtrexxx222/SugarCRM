<?php

require_once('include/MVC/View/SugarView.php');
require_once('modules/fbsg_ConstantContactIntegration/fbsg_ConstantContactIntegration.php');
require_once('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');

class ViewConfig extends SugarView {

    public function __construct() {
        parent::SugarView();
    }

    public function preDisplay() {
			$this->dv->tpl = 'modules/fbsg_ConstantContactIntegration/tpl/config.tpl';
    }

    public function display() {
        global $db, $timedate;
        $CCSeed = new fbsg_ConstantContactIntegration();
        $CCBean = $CCSeed->get_full_list('','fbsgcci.deleted=0');
        
        $CCBean = isset($CCBean[0]) ? $CCBean[0] : $CCSeed;
        
        $exp_date = $CCBean->getExpirationDate();
        
        $cUser = $GLOBALS['current_user'];
        if(!$cUser->is_admin) {
            echo 'You do not have permission to view this page.';
            return;            
        }
        $ccSeed = new fbsg_ConstantContactIntegration();
        $ccList = $ccSeed->get_full_list();

        $account = array('auth' => 'none');

        if ($ccList) {
            $ccAccount = $ccList[0];
            $account = array('name'=>$ccAccount->name, 'schedule_index'=>$ccAccount->schedule_index, 'auth'=>$ccAccount->t(), 'pkey'=>$ccAccount->pkey);
        } else {
        }


        $smarty = new Sugar_Smarty();
        $smarty->assign('v', $account);
        $smarty->assign('ls_options',$GLOBALS['app_list_strings']['lead_source_dom']);
        $smarty->assign('ls_selected', $CCBean->lead_source);
        $smarty->assign('exp_date', $exp_date);
        $smarty->assign('auto_import', $CCBean->auto_import_module);
        $smarty->assign('last_auto_update', $CCBean->last_auto_update ? $timedate->asUser($timedate->fromDb($CCBean->last_auto_update)) : $timedate->now());
        $smarty->assign('widget_script', $this->getJavascriptpath() . 'sugar_grp_yui_widgets.js');
        $smarty->assign('sync_sent_results', $CCBean->sync_sent_results ? true : false);
        parent::display();
				$smarty->display($this->dv->tpl);//$this->dv->tpl);
    }
    
    public function getJavascriptPath() {
        if (preg_match('/^6\.[0-3]/', $GLOBALS['sugar_version'])) {
            return 'include/javascript/';
        } else {
            return 'cache/include/javascript/';
        }
    }
    
    protected function _displayJavascript()
    {
        echo '<link href="modules/fbsg_ConstantContactIntegration/include/css/cci_tab.css" type="text/css" rel="stylesheet">';
        echo '<script type="text/javascript" src="modules/fbsg_ConstantContactIntegration/include/js/jquery-1.7.2.min.js"></script>';
        parent::_displayJavascript(); 
    }
}

?>
