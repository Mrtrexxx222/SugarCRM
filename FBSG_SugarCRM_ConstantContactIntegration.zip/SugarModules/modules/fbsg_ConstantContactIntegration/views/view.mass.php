<?php

require_once('include/MVC/View/SugarView.php');
require_once('modules/fbsg_ConstantContactIntegration/fbsg_ConstantContactIntegration.php');
require_once('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');
require_once('modules/Contacts/Contact.php');

class ViewMass extends SugarView {

    public function __construct() {
        //$this->defs = $viewdefs['fbsg_ConstantContactIntegration']['testView'];
        parent::SugarView();
    }

    public function preDisplay() {
        $this->dv->tpl = 'modules/fbsg_ConstantContactIntegration/tpl/mass.tpl';
    }

    public function display() {
        global $db;
        $seed = new Contact();
        if (!empty($_REQUEST['uid'])) {
            $recordIDs = explode(',', $_REQUEST['uid']);

            $cData = array();
            foreach ($recordIDs as $con) {
                $contact = $seed->retrieve($con);
                $contact->load_relationships();
                $cData[] = array('name' => $contact->name, 'email1' => $contact->email1, 'id' => $contact->id, 'cc_sync' => $contact->cc_sync);
            }
            $smarty = new Sugar_Smarty();
            $smarty->assign('fbsg_contact_list', $cData);
        }
        $smarty->assign('widget_script', $this->getJavascriptpath() . 'sugar_grp_yui_widgets.js');
        $smarty->display($this->dv->tpl);
        parent::display();
    }
    
    public function getJavascriptPath() {
        if (preg_match('/^6\.[0-3]/', $GLOBALS['sugar_version'])) {
            return 'include/javascript/';
        } else {
            return 'cache/include/javascript/';
        }
    }

}

?>