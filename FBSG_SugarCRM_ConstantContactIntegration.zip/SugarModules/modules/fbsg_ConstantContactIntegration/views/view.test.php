<?php
require_once('include/MVC/View/SugarView.php');
global $viewdefs;

class ViewTest extends SugarView
{
	public function __construct()
	{
		$this->defs = $viewdefs['fbsg_ConstantContactIntegration']['testView'];
		parent::SugarView();
	}

	public function preDisplay()
	{
		$this->dv->tpl = 'modules/fbsg_ConstantContactIntegration/tpl/test.tpl';
	}

	public function display()
	{
		$smarty = new Sugar_Smarty();
		$smarty->display($this->dv->tpl);
		parent::display();
	}
}
?>