<?php
 // created: 2012-06-13 21:08:52
$layout_defs["Contacts"]["subpanel_setup"]['fbsg_ccintegrationlog_contacts'] = array (
  'order' => 100,
  'module' => 'fbsg_CCIntegrationLog',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'CC Integration Log',
  'get_subpanel_data' => 'fbsg_ccintegrationlog_contacts',
  'top_buttons' => 
  array (
  ),
);
