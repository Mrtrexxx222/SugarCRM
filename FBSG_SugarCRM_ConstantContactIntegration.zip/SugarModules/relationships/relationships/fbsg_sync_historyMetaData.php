<?php
$dictionary['fbsg_sync_history'] = array (
    'relationships' => array(),
    'table' => 'fbsg_sync_history',
    'fields' => 
    array (
        array (
            'name' => 'cc_list_id',
            'type' => 'id',
        ),
        array (
            'name' => 'last_updated_link',
            'type' => 'varchar',
            'len' => 255,
        ),
        array (
            'name' => 'updated_since',
            'type' => 'datetime',
        ),
    ),
    'indices' => 
    array (
        array (
            'name' => 'idx_fbsg_sync_history_id',
            'type' => 'primary',
            'fields' => 
            array (
                0 => 'cc_list_id',
            ),
        ),
    ),
);