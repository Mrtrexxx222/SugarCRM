<?php
$dictionary['Account']['fields']['fbsg_ccintegrationlog_accounts'] = array(
    'name' => 'fbsg_ccintegrationlog_accounts',
    'type' => 'link',
    'relationship' => 'fbsg_ccintegrationlog_accounts',
    'source' => 'non-db',
    'vname' => 'CC Integration Log',
);