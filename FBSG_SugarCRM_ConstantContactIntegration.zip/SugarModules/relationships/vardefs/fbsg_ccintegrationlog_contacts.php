<?php
$dictionary['Contact']['fields']['fbsg_ccintegrationlog_contacts'] = array(
    'name' => 'fbsg_ccintegrationlog_contacts',
    'type' => 'link',
    'relationship' => 'fbsg_ccintegrationlog_contacts',
    'source' => 'non-db',
    'vname' => 'CC Integration Log',
);