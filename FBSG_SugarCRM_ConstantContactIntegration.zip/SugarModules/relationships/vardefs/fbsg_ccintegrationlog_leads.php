<?php
$dictionary['Lead']['fields']['fbsg_ccintegrationlog_leads'] = array(
    'name' => 'fbsg_ccintegrationlog_leads',
    'type' => 'link',
    'relationship' => 'fbsg_ccintegrationlog_leads',
    'source' => 'non-db',
    'vname' => 'CC Integration Log',
);