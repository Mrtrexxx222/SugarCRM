<?php
$dictionary['Prospect']['fields']['fbsg_ccintegrationlog_prospects'] = array(
    'name' => 'fbsg_ccintegrationlog_prospects',
    'type' => 'link',
    'relationship' => 'fbsg_ccintegrationlog_prospects',
    'source' => 'non-db',
    'vname' => 'CC Integration Log',
);