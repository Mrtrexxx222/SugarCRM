<?php
$job_strings[] = 'update_cc_campaign_results';
$job_strings[] = 'export_staged_cc_contacts';
$job_strings[] = 'sync_staged_lists';
$job_strings[] = 'process_open_activities';
$job_strings[] = 'import_contacts_from_csync_table';
$job_strings[] = 'automatic_contact_sync';
$job_strings[] = 'full_contact_download';
$job_strings[] = 'full_contact_sync';

require_once ('modules/fbsg_ConstantContactIntegration/include/ConstantContact.php');
function update_cc_campaign_results() {
	require_once ('modules/Contacts/Contact.php');
	require_once ('modules/Leads/Lead.php');
	global $db;
	
	$sCC = SugarCC::GetOnlyCC();
	if (! $sCC) {
		CCLog::Log('Sugar-CC integration expired, or no validated CC account found', 'fatal');
		return true;
	}
	
	$ut = new CCBasic($sCC->name, $sCC->password);
	
	$ccMass = new SugarCCMass($ut);
	
	$ccMass->GetAllCampaignResults();
	
	return true;
}
function sync_staged_lists() {
	$sCC = SugarCC::GetOnlyCC();
	if (! $sCC) {
		CCLog::Log('Sugar-CC integration expired, or no validated CC account found.', 'fatal');
		return true;
	}
	
	$ut = new CCBasic($sCC->name, $sCC->password);
	$ccMass = new SugarCCMass($ut);
	$ccMass->SyncStagedLists();
	
	return true;
}

function process_open_activities() {
	global $db;
	$CC = SugarCC::GetOnlyCC();
	if (! $CC) {
		CCLog::Log('Sugar-CC integration expired, or no validated CC account found.', 'fatal');
		return true;
	}
	
	$ut = new CCBasic($CC->name, $CC->password);
	
	$ccActivity = new SugarCCActivity($ut);
	$ccMass = new SugarCCMass($ut);
	$complete_activites = $ccActivity->checkActivityStatus();
	$ccMass->PopulateContactImportTable($complete_activites);
	
	return true;
}

/**
 * Auto-Syncs new & updated contacts from Constant Contact daily.
 *
 * @return boolean
 */
function automatic_contact_sync() {
	global $db, $timedate;
	$CC = SugarCC::GetOnlyCC();
	if (! $CC) {
		CCLog::Log('Sugar-CC integration expired, or no validated CC account found.', 'fatal');
		return true;
	}
	
	$ut = new CCBasic($CC->name, $CC->password);
	$incSync = new SugarIncrementalSync($ut, $CC->auto_import_module);

	$incSync->SyncAllLists();
	
	return true;
}

function import_contacts_from_csync_table() {
	global $db;
	$CC = SugarCC::GetOnlyCC();
	if (! $CC) {
		CCLog::Log('Sugar-CC integration expired, or no validated CC account found.', 'fatal');
		return true;
	}
	
	$ut = new CCBasic($CC->name, $CC->password);
	$ccMass = new SugarCCMass($ut);
	$ccMass->ImportContactsFromCCToSugar();
	
	// start the sycn for CC Activity errors
	global $current_user;
	$current_user = new User();
	$current_user->retrieve('1');
	
	return true;
}

function full_contact_download() {
	global $db;
	$CC = SugarCC::GetOnlyCC();
	if(!$CC) {
		CCLog::Log('Sugar - CC integration expired, or now validated CC account found.', 'fatal');
		return true;
	}

	$ut = new CCBasic($CC->name, $CC->password);
	$ccActivity = new SugarCCActivity($ut);
	$ccActivity->ExportAllContacts();
}

function full_contact_sync() {
	global $db;
	$CC = SugarCC::GetOnlyCC();
	if(!$CC) {
		CCLog::Log('Sugar - CC integration expired, or no validated CC account found.', 'fatal');
		return true;
	}

	$ut = new CCBasic($CC->name, $CC->password);
	$ccMass = new SugarCCMass($ut);
	$ccMass->SyncImportTableToContacts(array('accounts', 'contacts', 'leads', 'prospects'));
}

?>