<?php
require_once('modules/ModuleBuilder/parsers/views/GridLayoutMetaDataParser.php');
require_once('modules/Schedulers/Scheduler.php');
global $db;

$listField = array('name' => 'cc_lists_view', 'vname' => 'LBL_CCLISTS');
$syncField = array('name' => 'cc_sync', 'vname' => 'LBL_CCSYNC');

foreach(array('Contacts', 'Leads', 'Accounts', 'Prospects') as $module) {
    echo "Installing $module view...<br>";
    foreach ( array ( MB_EDITVIEW , MB_DETAILVIEW ) as $view ) {
        $parser = new GridLayoutMetaDataParser($view, $module);
        $parser->removeField('cc_lists');
        $parser->removeField('cc_lists_view');
        $parser->removeField('cc_sync');
        $parser->addField($syncField);
        $parser->addField($listField);
        $parser->handleSave(false);
    }
}

$dt = $GLOBALS['timedate'];
$df = $GLOBALS['current_user']->getUserDateTimePreferences();
$df = $df['date'];

$sch = new Scheduler();
$schList = $sch->get_full_list('', 'schedulers.name = \'Handle Mass Export to Constant Contact\'');
if(count($schList) != 0) {
    $sch = $schList[0];
}
$sch->name = "Handle Mass Export to Constant Contact";
$sch->job = "function::sync_staged_lists";
$sch->date_time_start = $dt->swap_formats(date('Y/m/d'), 'Y/m/d', $df);
$sch->date_time_end = $dt->swap_formats('2020/01/01', 'Y/m/d', $df);
$sch->job_interval = '0::*/2::*::*::*';
$sch->status = 'Active';
$sch->catch_up = 0;
$sch->save();

$sch = new Scheduler();
$schList = $sch->get_full_list('', 'schedulers.name = \'Update CC Campaign Results\'');
if(count($schList) != 0) {
    $sch = $schList[0];
}
$sch->name = "Update CC Campaign Results";
$sch->job = "function::update_cc_campaign_results";
$sch->date_time_start = $dt->swap_formats(date('Y/m/d'), 'Y/m/d', $df);
$sch->date_time_end = $dt->swap_formats('2020/01/01', 'Y/m/d', $df);
$sch->job_interval = '0::0::*::*::*';
$sch->catch_up = 0;
$sch->status = 'Active';
$sch->save();

$sch = new Scheduler();
$schList = $sch->get_full_list('', 'schedulers.name = \'Download CC Data\'');
if(count($schList) != 0) {
    $sch = $schList[0];
}
$sch->name = "Download CC Data";
$sch->job = "function::process_open_activities";
$sch->date_time_start = $dt->swap_formats(date('Y/m/d'), 'Y/m/d', $df);
$sch->date_time_end = $dt->swap_formats('2020/01/01', 'Y/m/d', $df);
$sch->job_interval = '*::*::*::*::*';
$sch->catch_up = 0;
$sch->status = 'Active';
$sch->save();

$sch = new Scheduler();
$schList = $sch->get_full_list('', 'schedulers.name = \'Import CC Data\'');
if(count($schList) != 0) {
    $sch = $schList[0];
}
$sch->name = "Import CC Data";
$sch->job = "function::import_contacts_from_csync_table";
$sch->date_time_start = $dt->swap_formats(date('Y/m/d'), 'Y/m/d', $df);
$sch->date_time_end = $dt->swap_formats('2020/01/01', 'Y/m/d', $df);
$sch->job_interval = '30::*::*::*::*';
$sch->catch_up = 0;
$sch->status = 'Active';
$sch->save();

$sch = new Scheduler();
$schList = $sch->get_full_list('', 'schedulers.name = \'Auto CC Download Sync\'');
if(count($schList) != 0) {
	$sch = $schList[0];
}
$sch->name = "Auto CC Download Sync";
$sch->job = "function::automatic_contact_sync";
$sch->date_time_start = $dt->swap_formats(date('Y/m/d'), 'Y/m/d', $df);
$sch->date_time_end = $dt->swap_formats('2020/01/01', 'Y/m/d', $df);
$sch->job_interval = '0::0::*::*::*';
$sch->catch_up = 0;
$sch->status = 'Active';
$sch->save();