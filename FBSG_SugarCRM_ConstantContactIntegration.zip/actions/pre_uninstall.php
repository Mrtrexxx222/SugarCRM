<?php
//function post_execute() {
    require_once('modules/ModuleBuilder/parsers/views/GridLayoutMetaDataParser.php');
    foreach(array('Contacts', 'Leads', 'Accounts', 'Prospects') as $module) {
        echo "Uninstalling $module view...<br>";
        foreach ( array ( MB_EDITVIEW , MB_DETAILVIEW ) as $view ) {
            $parser = new GridLayoutMetaDataParser($view, $module);
            $parser->removeField('cc_sync');
            $parser->removeField('cc_lists');
            $parser->handleSave(false);
        }
    }
//}
