<?php
$admin_option_defs = array();
$admin_option_defs['fbsg_ConstantContactIntegration']['cci_config'] = array(
    'fbsg_ConstantContactIntegration', 
    'Constant Contact Control Panel', 
    'Manage Constant Contact Configuration',
    './index.php?module=fbsg_ConstantContactIntegration&action=config'
);
$admin_option_defs['fbsg_ConstantContactIntegration']['cci_errors'] = array(
		'fbsg_CCIErrors',
		'Constant Contact Integration Logs',
		'View Constant Contact Logs',
		'./index.php?module=fbsg_CCIErrors&action=index'
);
$admin_option_defs['fbsg_ConstantContactIntegration']['cci_activities'] = array(
		'fbsg_CCIActivities',
		'Constant Contact Activity Status',
		'View Constant Contact Activity Status',
		'./index.php?module=fbsg_CCIActivities&action=index'
);
$admin_group_header[] = array(
    'Constant Contact Integration', 
    '', 
    false, 
    $admin_option_defs, 
    'Synchronize contacts, campaigns, and campaign results from Constant Contact'
);