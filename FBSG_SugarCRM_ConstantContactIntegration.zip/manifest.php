<?php
/* * *******************************************************************************
 * The contents of this file are subject to the SugarCRM Professional Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-professional-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2010 SugarCRM, Inc.; All Rights Reserved.
 * ****************************************************************************** */
$manifest = array(
    'acceptable_sugar_versions' => array(
        'regex_matches' => array(
            '6\\.[01234567]\\..*',
        ),
    ),
    'acceptable_sugar_flavors' => array('CE', 'PRO', 'CORP', 'ENT', 'ULT'),
    'readme' => '',
    'key' => 'fbsg',
    'author' => 'FBSG',
    'description' => 'SugarCRM - Constant Contact Integration',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'Sugar-Constant Contact Integration',
    'published_date' => '2013-01-23',
    'type' => 'module',
    'version' => '2.5.2',
    'remove_tables' => 'prompt',
);
global $sugar_version;
$schedulerCopy = preg_match('/^6.[0-2]/', $sugar_version) ?
    array(
        'from' => '<basepath>/actions/fbsg_cc_jobs.php',
        'to' => 'custom/modules/Schedulers/_AddJobsHere.php'
    ) :
    array(
        'from' => '<basepath>/actions/fbsg_cc_jobs.php',
        'to' => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/fbsg_cc_jobs.php'
    );
$installdefs = array(
    'id' => 'ConstantContactIntegration',
    'beans' =>
    array(
        array(
            'module' => 'fbsg_ConstantContactIntegration',
            'class' => 'fbsg_ConstantContactIntegration',
            'path' => 'modules/fbsg_ConstantContactIntegration/fbsg_ConstantContactIntegration.php',
            'tab' => false,
        ),
        array(
            'module' => 'csync_cc_sync_table',
            'class' => 'csync_cc_sync_table',
            'path' => 'modules/csync_cc_sync_table/csync_cc_sync_table.php',
            'tab' => false,
        ),
        array(
            'module' => 'csync_cc_sync_activities',
            'class' => 'csync_cc_sync_activities',
            'path' => 'modules/csync_cc_sync_activities/csync_cc_sync_activities.php',
            'tab' => false,
        ),
    	array (
    		'module' => 'fbsg_CCIErrors',
    		'class' => 'fbsg_CCIErrors',
    		'path' => 'modules/fbsg_CCIErrors/fbsg_CCIErrors.php',
    		'tab' => false,
    	),
        array (
          'module' => 'fbsg_CCIntegrationLog',
          'class' => 'fbsg_CCIntegrationLog',
          'path' => 'modules/fbsg_CCIntegrationLog/fbsg_CCIntegrationLog.php',
          'tab' => true,
        ),
    ),
    'layoutdefs' =>
    array(
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/Contacts.php',
            'to_module' => 'Contacts',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ConstantContactIntegration.php',
            'to_module' => 'fbsg_ConstantContactIntegration',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_accounts_subpanel.php',
            'to_module' => 'Accounts'
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_contacts_subpanel.php',
            'to_module' => 'Contacts'
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_leads_subpanel.php',
            'to_module' => 'Leads'
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_prospects_subpanel.php',
            'to_module' => 'Prospects'
        ),
    ),
    'administration' =>
	array(
		array(
			'from' => '<basepath>/fbsg_cci_admin.php',
		),
	),
    'relationships' =>
    array(
        array(
            'meta_data' => '<basepath>/SugarModules/relationships/relationships/fbsg_ccintegrationlog_relMetaData.php'
        ),
        array(
            'meta_data' => '<basepath>/SugarModules/relationships/relationships/fbsg_sync_historyMetaData.php'
        ),
    ),
    'image_dir' => '<basepath>/icons',
    'copy' =>
    array(
        array(
            'from' => '<basepath>/SugarModules/custom/',
            'to' => 'custom/'
        ),
        array(
            'from' => '<basepath>/SugarModules/modules/',
            'to' => 'modules/'
        ),
        $schedulerCopy,
        //Despite the above schedulerCopy, we copy to the rebuilt file as well. In 6.3+, this
        //will be overwritten with the correct file on rebuild.
        //In 6.2 and below, it won't be touched, but we still include it in force_sched tasks.
        array(
            'from' => '<basepath>/actions/fbsg_cc_jobs.php',
            'to' => 'custom/modules/Schedulers/Ext/ScheduledTasks/scheduledtasks.ext.php'
        ),
    ),
    'language' =>
    array(
        array(
            'from' => '<basepath>/SugarModules/relationships/language/Contacts.php',
            'to_module' => 'Contacts',
            'language' => 'en_us',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/language/fbsg_ConstantContactIntegration.php',
            'to_module' => 'fbsg_ConstantContactIntegration',
            'language' => 'en_us',
        ),
        array(
            'from' => '<basepath>/SugarModules/language/application/en_us.lang.php',
            'to_module' => 'application',
            'language' => 'en_us',
        ),
    ),
    'vardefs' =>
    array(
        array(
            'from' => '<basepath>/SugarModules/relationships/vardefs/fbsg_ccintegrationlog_accounts.php',
            'to_module' => 'Accounts',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/vardefs/fbsg_ccintegrationlog_contacts.php',
            'to_module' => 'Contacts',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/vardefs/fbsg_ccintegrationlog_leads.php',
            'to_module' => 'Leads',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/vardefs/fbsg_ccintegrationlog_prospects.php',
            'to_module' => 'Prospects',
        ),
    ),
    'layoutdefs' => array(
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_accounts_subpanel.php',
            'to_module' => 'Accounts',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_contacts_subpanel.php',
            'to_module' => 'Contacts',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_leads_subpanel.php',
            'to_module' => 'Leads',
        ),
        array(
            'from' => '<basepath>/SugarModules/relationships/layoutdefs/fbsg_ccintegrationlog_prospects_subpanel.php',
            'to_module' => 'Prospects',
        ),
    ),
    'logic_hooks' => array(
        array(
            'module' => 'Contacts',
            'hook' => 'after_save',
            'order' => 99,
            'description' => 'Sync to Constant Contact',
            'file' => 'custom/modules/Contacts/include/LogicHooks/fbsg_cc_hook.php',
            'class' => 'fbsg_cc_ContactLogic',
            'function' => 'SyncToCC',
        ),
        array(
            'module' => 'Leads',
            'hook' => 'after_save',
            'order' => 99,
            'description' => 'Sync to Constant Contact',
            'file' => 'custom/modules/Leads/include/LogicHooks/fbsg_cc_hook.php',
            'class' => 'fbsg_cc_LeadLogic',
            'function' => 'SyncToCC',
        ),
        array(
            'module' => 'Prospects',
            'hook' => 'after_save',
            'order' => 99,
            'description' => 'Sync to Constant Contact',
            'file' => 'custom/modules/Prospects/include/LogicHooks/fbsg_cc_hook.php',
            'class' => 'fbsg_cc_ProspectLogic',
            'function' => 'SyncToCC',
        ),
        array(
            'module' => 'Accounts',
            'hook' => 'after_save',
            'order' => 99,
            'description' => 'Sync to Constant Contact',
            'file' => 'custom/modules/Accounts/include/LogicHooks/fbsg_cc_hook.php',
            'class' => 'fbsg_cc_AccountLogic',
            'function' => 'SyncToCC',
        ),
        array(
            'module' => 'ProspectLists',
            'hook' => 'after_save',
            'order' => 99,
            'description' => 'Sync to Constant Contact',
            'file' => 'custom/modules/ProspectLists/include/LogicHooks/fbsg_cc_hook.php',
            'class' => 'fbsg_cc_ProspectListsLogic',
            'function' => 'SyncToCC',
        ),
    ),
    'post_execute' => array(
        '<basepath>/actions/post_execute.php',
    ),
    'pre_uninstall' => array(
        '<basepath>/actions/pre_uninstall.php',
    ),
);
