<?php 
$moduleList[] = 'ProductTemplates'; // this line has to be included.

?>