<?PHP
// manifest file for information regarding application of new code
$manifest = array(
  // only install on the following regex sugar versions (if empty, no check)
  'acceptable_sugar_flavors' => array(
          0 => 'CE',
          1 => 'PRO',
          2 => 'ENT',
          3 => 'DEV'
        ),
  'acceptable_sugar_versions' => array(
          'exact_matches' => array(),
    'regex_matches' => array(
            '6|(5\.[1-9])'
          ),
  ),
 // name of new code
  'name' => 'Plus Projects Boton PDF para Sugar',

  // description of new code
  'description' => 'Plugin para Sugar el cual permite generar reportes en formato PDF',

  // author of new code
  'Wilmer' => 'Wilmer Alcivar<walcivar@plus-projects.com>',

  // date published
  'published_date' => '2012-03-02',

  // unistallable
  'is_uninstallable' => true,

  // version of code
  'version' => '1.1',

  // type of code (valid choices are: full, langpack, module, patch, theme )
  'type' => 'module',

  // icon for displaying in UI (path to graphic contained within zip package)
  'icon' => ''
);

$installdefs = array(
 'id'       => 'formRouterPDFButton',
 'mkdirs'   => array('include/SugarFields/Fields/FRPDFButton'),
 'copy'     => array(
                array('from'    => '<basepath>/include/SugarFields/Fields/FRPDFButton',
                      'to'      => 'include/SugarFields/Fields/FRPDFButton',
                ),
                array('from'    => '<basepath>/modules/DynamicFields/templates/Fields/Forms/FRPDFButton.tpl',
                      'to'      => 'modules/DynamicFields/templates/Fields/Forms/FRPDFButton.tpl',
                ),
                array('from'    => '<basepath>/modules/DynamicFields/templates/Fields/Forms/FRPDFButton.php',
                      'to'      => 'modules/DynamicFields/templates/Fields/Forms/FRPDFButton.php',
                ),
                array('from'    => '<basepath>/modules/DynamicFields/templates/Fields/Forms/FRPDFButton.tpl',
                      'to'      => 'modules/DynamicFields/templates/Fields/FormsFRPDFButton.tpl',
                ),
                array('from'    => '<basepath>/modules/DynamicFields/templates/Fields/Forms/FRPDFButton.php',
                      'to'      => 'modules/DynamicFields/templates/Fields/FormsFRPDFButton.php',
                ),
                array('from'    => '<basepath>/modules/DynamicFields/templates/Fields/TemplateFRPDFButton.php',
                      'to'      => 'modules/DynamicFields/templates/Fields/TemplateFRPDFButton.php',
                ),
				array('from'    => '<basepath>/modules/Contracts/logic_hooks.php',
                      'to'      => 'custom/modules/Contracts/logic_hooks.php',
                ),
				array('from'    => '<basepath>/modules/Contracts/add_code_hook.php',
                      'to'      => 'custom/modules/Contracts/add_code_hook.php',
                ),
				array('from'    => '<basepath>/modules/Contacts/logic_hooks.php',
                      'to'      => 'custom/modules/Contacts/logic_hooks.php',
                ),
				array('from'    => '<basepath>/modules/Contacts/update_hook.php',
                      'to'      => 'custom/modules/Contacts/update_hook.php',
                ),
				array('from'    => '<basepath>/modules/Contacts/delete_hook.php',
                      'to'      => 'custom/modules/Contacts/delete_hook.php',
                ),
				array('from'    => '<basepath>/Extension/application/Ext/Include/producttemplates.php',
                      'to'      => 'custom/Extension/application/Ext/Include/producttemplates.php',
                ),
				array('from'    => '<basepath>/modules/ProductCategories/language/es_ES.lang.php',
                      'to'      => 'custom/modules/ProductCategories/language/es_ES.lang.php',
                ),
				array('from'    => '<basepath>/modules/ProductTypes/language/es_ES.lang.php',
                      'to'      => 'custom/modules/ProductTypes/language/es_ES.lang.php',
                ),
				array('from'    => '<basepath>/modules/ProductTemplates/language/es_ES.lang.php',
                      'to'      => 'custom/modules/ProductTemplates/language/es_ES.lang.php',
                ),
				array('from'    => '<basepath>/modules/ProductTemplates/Popup_picker.html',
                      'to'      => 'custom/modules/ProductTemplates/Popup_picker.html',
                ),
				array('from'    => '<basepath>/modules/ProductTemplates/Popup_picker.php',
                      'to'      => 'custom/modules/ProductTemplates/Popup_picker.php',
                ),
				array('from'    => '<basepath>/modules/ProductTemplates/metadata/popupdefs.php',
                      'to'      => 'custom/modules/ProductTemplates/metadata/popupdefs.php',
                ),
				array('from'    => '<basepath>/modules/ProductTemplates/views/view.popup.php',
                      'to'      => 'custom/modules/ProductTemplates/views/view.popup.php',
               ),
			),
  'language'=> array(
                array('from'     => '<basepath>/application/app_strings_en_us.php',
                      'to_module'=> 'application',
                      'language' => 'en_us'
                     ),
                array('from'     => '<basepath>/application/mod_strings_en_us.php',
                      'to_module'=> 'ModuleBuilder',
                      'language' => 'en_us'
                     ),
    )
 );

if (!preg_match('/^6|(5\.(?>[2-9]|1\.0[a-z]))/', $GLOBALS['sugar_version']))
    $installdefs['copy'][] =
                   array('from'    => '<basepath>/modules/ModuleBuilder/views/view.modulefield.php',
                      'to'      => 'modules/ModuleBuilder/views/view.modulefield.php',
                );
