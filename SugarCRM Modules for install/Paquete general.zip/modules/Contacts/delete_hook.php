<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class fdelete
{
    /*
     * The method that does the checking for the specific fields. This is
     * the method that we'll want to call in the logic_hooks.php file.
     */

    function fdelete($bean, $event, $arguments)
	{
		$db =  DBManagerFactory::getInstance(); 
	
		$query = "select c1.chasis_c, c1.motor_c, c1.placa_c, c2.lead_source from contacts_cstm c1, contacts c2 where c1.chasis_c = '".$bean->chasis_c."' and c1.motor_c = '".$bean->motor_c."' and c1.placa_c ='".$bean->placa_c."' and c2.lead_source = '".$bean->lead_source."' and c1.id_c = c2.id"; 
		$result = $db->query($query, true, 'Error selecting the contact record');
 
		if($db->getRowCount($result) > 1)
		{
			$query = "delete from contacts_cstm where id_c = '".$bean->id."'";
			$result = $db->query($query, true, 'Error deleting the old contact_cstm record');

			$query = "delete from contacts where id = '".$bean->id."'";
			$result = $db->query($query, true, 'Error deleting the old contact record');
		}
    }
} 
?>