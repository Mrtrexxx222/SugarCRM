<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class fupdate
{
    /*
     * The method that does the checking for the specific fields. This is
     * the method that we'll want to call in the logic_hooks.php file.
     */

    function fupdate($bean, $event, $arguments)
	{
		$db =  DBManagerFactory::getInstance(); 
		
		$query = "select id_c, c1.chasis_c, c1.motor_c, c1.placa_c, c2.lead_source from contacts_cstm c1, contacts c2 where c1.chasis_c = '".$bean->chasis_c."' and c1.motor_c = '".$bean->motor_c."' and c1.placa_c ='".$bean->placa_c."' and c2.lead_source = '".$bean->lead_source."' and c1.id_c = c2.id";
		$result = $db->query($query, true, 'Error selecting the contact record');
 
		if ($row=$db->fetchByAssoc($result))
		{
			$query = "update contacts_cstm set cedula_ruc_c = '".$bean->cedula_ruc_c."', fecha_envio_xls_c = '".$bean->fecha_envio_xls_c."', marca_c = '".$bean->marca_c."', modelo_c = '".$bean->modelo_c."', chasis_c = '".$bean->chasis_c."', motor_c = '".$bean->motor_c."', fecha_emision_poliza_c = '".$bean->fecha_emision_poliza_c."', fecha_inicio_servicio_c = '".$bean->fecha_inicio_servicio_c."', fecha_final_servicio_c = '".$bean->fecha_final_servicio_c."', placa_c = '".$bean->placa_c."' where chasis_c ='".$bean->chasis_c."'";
			$result = $db->query($query, true, 'Error adding the contact_cstm record...');

			$query = "update contacts set first_name = '".$bean->first_name."', last_name = '".$bean->last_name."', phone_home = '".$bean->phone_home."', phone_mobile = '".$bean->phone_mobile."', phone_work = '".$bean->phone_work."', primary_address_street = '".$bean->primary_address_street."', primary_address_city = '".$bean->primary_address_city."', lead_source = '".$bean->lead_source."' where id ='".$row['id_c']."'"; 
			$result = $db->query($query, true, 'Error adding the contact record...');
		}
    }
} 
?>