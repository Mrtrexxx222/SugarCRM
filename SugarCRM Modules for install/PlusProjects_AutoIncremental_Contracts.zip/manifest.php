<?PHP
// manifest file for information regarding application of new code
$manifest = array(
  // only install on the following regex sugar versions (if empty, no check)
  'acceptable_sugar_flavors' => array(
          0 => 'CE',
          1 => 'PRO',
          2 => 'ENT',
          3 => 'ULT'
        ),
  'acceptable_sugar_versions' => array(
          'exact_matches' => array(),
    'regex_matches' => array(
            '6|(5\.[1-9])'
          ),
  ),
 // name of new code
  'name' => 'Plus Projects autoincremental para Contratos',

  // description of new code
  'description' => 'Plugin para Sugar el cual realiza un control para generar un autoincremental de cada contrato registrado en Sugar',

  // author of new code
  'Wilmer' => 'Wilmer Alcivar<walcivar@plus-projects.com>',

  // date published
  'published_date' => '2012-09-12',

  // unistallable
  'is_uninstallable' => true,

  // version of code
  'version' => '1.1',

  // type of code (valid choices are: full, langpack, module, patch, theme )
  'type' => 'module',

  // icon for displaying in UI (path to graphic contained within zip package)
  'icon' => ''
);

$installdefs = array(
 'id'       => 'AutoIncremental',
 'copy'     => array(
				array('from'    => '<basepath>/modules/Contracts/logic_hooks.php',
                      'to'      => 'custom/modules/Contracts/logic_hooks.php',
                ),
				array('from'    => '<basepath>/modules/Contracts/add_code_hook.php',
                      'to'      => 'custom/modules/Contracts/add_code_hook.php',
                ),
			),
  'language'=> array(
                array('from'     => '<basepath>/application/app_strings_en_us.php',
                      'to_module'=> 'application',
                      'language' => 'en_us'
                     ),
                array('from'     => '<basepath>/application/mod_strings_en_us.php',
                      'to_module'=> 'ModuleBuilder',
                      'language' => 'en_us'
                     ),
    )
 );
