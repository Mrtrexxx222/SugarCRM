<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class add_code 
{ 
	const CODE_PREFIX = "CON";
	const CODE_SUFFIX = "";
	const CODE_SEPARATOR = "-";
	const CODE_FIELD = "reference_code";
	const CUSTOM_TABLE = "contracts";
	const ADD_DATE = "1";
	const DATE_FORMAT = "dmy";
	const ZERO_PADDING = 5; //minimum amount of characters desired for the number. ie 4 = 0001, 3 = 001
	const FIRST_NUM = "00000"; //default to start with.

	function auto_increment(&$bean, $event, $arguments)
	{
		if (!isset($bean->fetched_row['id']))
		{
			$db = DBManagerFactory::getInstance();
			$sql = "select max(numero_c) from contracts_cstm";
			$max_id = $db->getOne($sql);

			if (empty($max_id))
			{
				$db =  DBManagerFactory::getInstance(); 
				$query = "select id, " . self::CODE_FIELD . " from " . self::CUSTOM_TABLE ." where (" . self::CODE_FIELD . " = '' or " . self::CODE_FIELD . " is null) order by right(" . self::CODE_FIELD . ", 4) desc limit 1";
				$result = $db->query($query, true, 'Error selecting most recent ' . self::CODE_FIELD . 'CODE');
				$rows=$db->fetchByAssoc($result);
				if ($rows['id'] == $bean->id) 
				{ 
					$max_id = $max_id;
				}
				else
				{
					$max_id = $max_id+1;
				}
			}
			else
			{
				$max_id = $max_id+1;
			}
			$bean->numero_c = $max_id;
			$pads = self::ZERO_PADDING - strlen($max_id);
			$new_code = self::CODE_PREFIX . (self::ADD_DATE?date(self::DATE_FORMAT):"") . self::CODE_SEPARATOR;
			for($i=0; $i < $pads; $i++)
			{ 
				$new_code .= "0"; 
			}
			$new_code .= $max_id . self::CODE_SUFFIX;
			$bean->reference_code=$new_code;
		}
	}
}
?>