<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class fupdate
{
    /*
     * The method that does the checking for the specific fields. This is
     * the method that we'll want to call in the logic_hooks.php file.
     */

    function fupdate($bean, $event, $arguments)
	{
		$db =  DBManagerFactory::getInstance(); 
		
		$query = "select a.id_c, a.chasis_c, a.motor_c, a.placa_c, a.entidad_c, a.fecha_final_servicio_c from contacts_cstm a, contacts b where a.chasis_c = '".$bean->chasis_c."' and a.motor_c = '".$bean->motor_c."' and a.placa_c ='".$bean->placa_c."' and a.entidad_c ='".$bean->entidad_c."' and a.id_c = b.id and b.deleted = 0";
		$result = $db->query($query, true, 'Error selecting the contact record');
 
		if ($row=$db->fetchByAssoc($result))
		{
			$query = "update contacts set first_name = '".$bean->first_name."', last_name = '".$bean->last_name."', phone_home = '".$bean->phone_home."', phone_mobile = '".$bean->phone_mobile."', phone_work = '".$bean->phone_work."', primary_address_street = '".$bean->primary_address_street."', primary_address_city = '".$bean->primary_address_city."' where id ='".$row['id_c']."'";
			$result = $db->query($query, true, 'Error updating the contact record...');
			
			$query = "update contacts_cstm set marca_c = '".$bean->marca_c."', modelo_c = '".$bean->modelo_c."' where id_c ='".$row['id_c']."'";
			$result = $db->query($query, true, 'Error updating the contact record...');
			
			$hoy = date("Y/m/d");
			$diferencia = $this->diferencia3($bean->fecha_final_servicio_c, $hoy);
			if($diferencia < 0)
			{
				$query = "update contacts_cstm set fecha_emision_poliza_c = '".$bean->fecha_emision_poliza_c."', fecha_inicio_servicio_c = '".$bean->fecha_inicio_servicio_c."', fecha_final_servicio_c = '".$bean->fecha_final_servicio_c."', estado_c = 'Caducado' where chasis_c = '".$bean->chasis_c."' and motor_c = '".$bean->motor_c."' and placa_c ='".$bean->placa_c."' and entidad_c ='".$bean->entidad_c."'";
				$result = $db->query($query, true, 'Error updating the contact_cstm record...');
			}
			else
			{
				$query = "update contacts_cstm set fecha_emision_poliza_c = '".$bean->fecha_emision_poliza_c."', fecha_inicio_servicio_c = '".$bean->fecha_inicio_servicio_c."', fecha_final_servicio_c = '".$bean->fecha_final_servicio_c."', estado_c = 'Renovado' where chasis_c = '".$bean->chasis_c."' and motor_c = '".$bean->motor_c."' and placa_c ='".$bean->placa_c."' and entidad_c ='".$bean->entidad_c."'";
				$result = $db->query($query, true, 'Error updating the contact_cstm record...');
			}
		}
    }
	
	function diferencia3($date1, $date2)
	{
		$fecha1 = date("Y-m-d",strtotime($date1));
		$fecha2 = date("Y-m-d",strtotime($date2));
		$segundos_fecha1=strtotime($fecha1);
		$segundos_fecha2=strtotime($fecha2);
		$segundos_diferencia=$segundos_fecha1-$segundos_fecha2;
		$total_dias=$segundos_diferencia/(60*60*24);
		return $total_dias;
	}
} 
?>