<?php
 $dictionary['Contact']['indices'][] = array('name' =>'idx_fields_c', 'type'=>'index', 'fields'=>array('placa_c','motor_c','chasis_c','entidad_c'));
 ?>