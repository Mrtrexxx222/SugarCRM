<?php
// manifest file for information regarding application of new code
    $manifest = array (
        'acceptable_sugar_flavors' => array('CE','PRO','CORP','ENT','ULT'),
        'acceptable_sugar_versions' => array(
            'exact_matches' => array(),
            'regex_matches' => array('6\\.[0-9]\\.[0-9]$'),
        ),
        'key'=>'custom_job_schedule_package',
        'author' => 'Wilmer Alcivar',
        'description' => 'Custom scheduler job package',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'custom_job_schedule_package',
        'published_date' => '2013-04-06',
        'type' => 'module',
        'version' => '1.0',
        'remove_tables' => 'prompt',
    );
    $installdefs = array(
        'id'       => 'Nodocumentexpired_3',
        'copy'     => array(
            0 => array(
                'from'  => '<basepath>/modules/Schedulers/documentos_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/documentos_vencidos.php',
            ),
            1 => array(
                'from'  => '<basepath>/modules/Schedulers/language/es_Es.documentos_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/Language/es_Es.documentos_vencidos.php',
            ),
            2 => array(
                'from'  => '<basepath>/modules/Schedulers/language/en_us.documentos_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/Language/en_us.documentos_vencidos.php',
            ),				
            3 => array(
                'from'  => '<basepath>/modules/Schedulers/servicios_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/ScheduledTasks/servicios_vencidos.php',
            ),
            4 => array(
                'from'  => '<basepath>/modules/Schedulers/language/es_Es.servicios_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/Language/es_Es.servicios_vencidos.php',
            ),
            5 => array(
                'from'  => '<basepath>/modules/Schedulers/language/en_us.servicios_vencidos.php',
                'to'    => 'custom/Extension/modules/Schedulers/Ext/Language/en_us.servicios_vencidos.php',
            ),
        ),
    );
?>
