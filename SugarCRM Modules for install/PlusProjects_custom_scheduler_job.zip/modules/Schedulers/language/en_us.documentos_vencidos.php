<?php
$mod_strings['LBL_DOCUMENTOS_VENCIDOS'] = 'Documentos Vencidos';
?>