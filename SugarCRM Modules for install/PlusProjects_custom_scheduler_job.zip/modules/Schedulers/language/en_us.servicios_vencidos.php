<?php
$mod_strings['LBL_SERVICIOS_VENCIDOS'] = 'Servicios Vencidos';
?>