<?php

array_push($job_strings, 'servicios_vencidos');
function servicios_vencidos()
{
	require_once("modules/Administration/Administration.php");
	require_once("include/SugarPHPMailer.php");

	$nombres="";
	$id_usuario="";
	$primary_email="";
	$bandera = 0;
	$hoy = date("Y/m/d");

	$db =  DBManagerFactory::getInstance(); 
	$query = "select user_id, role_id from acl_roles_users";
	$result = $db->query($query, true, 'Error selecting the detail product record');
	while($row=$db->fetchByAssoc($result))
	{
		$query2  = "select name from acl_roles where id = '".$row['role_id']."'";
		$result2 = $db->query($query2, true, 'Error selecting the detail product record');
		if($row2 = $db->fetchByAssoc($result2))
		{
			if($row2['name'] == 'Logistica')
			{
				$current_user = new User();
				$current_user->retrieve_by_string_fields(array('id'=>$row['user_id']));
				$nombres = $current_user->first_name." ".$current_user->last_name;
				$id_usuario = $current_user->id;

				$user=BeanFactory::getBean('Users',$id_usuario);
				$primary_email=$user->emailAddress->getPrimaryAddress($user);
			}
		}
	}

	$query3 = "select a.id_c, a.fecha_final_servicio_c, a.placa_c, a.motor_c, a.chasis_c from contacts_cstm a, contacts b where a.id_c = b.id and b.deleted = '0'";
	$result3 = $db->query($query3, true, 'Error selecting the contacts record');
	while($row3=$db->fetchByAssoc($result3)) 
	{
		//para la fecha_final_servicio_c 
		$fecha_f = date("Y/m/d",strtotime($row3['fecha_final_servicio_c']));
		$fecha_fin = diferencia2($fecha_f, $hoy);		
		if($fecha_fin < 0)
		{
			$bandera = 1;
			$query4 = "update contacts_cstm set estado_c = 'Caducado' where id_c = '".$row3['id_c']."'";
			$result4 = $db->query($query4, true, 'Error updating the contacts record');
		}
	}
	if($bandera == 1)
	{
		envia_mail_servicios($primary_email,$nombres);
	}
	return true;
}

function diferencia2($date1, $date2)
{
	$fecha1 = date("Y-m-d",strtotime($date1));
	$fecha2 = date("Y-m-d",strtotime($date2));
	$segundos_fecha1=strtotime($fecha1);
	$segundos_fecha2=strtotime($fecha2);
	$segundos_diferencia=$segundos_fecha1-$segundos_fecha2;
	$total_dias=$segundos_diferencia/(60*60*24);
	return $total_dias;
}

function envia_mail_servicios($primary_email,$nombres)
{
	$mail=new SugarPHPMailer();
	$admin = new Administration();
	$admin->retrieveSettings();
	$mail->isHTML(true);
	$mail->CharSet = "UTF-8";
	$mail->AddAddress($primary_email, $nombres);
	//$mail->AddCC("spachano@plus-projects.com","Sebastian Pachano");
	$mail->From     = $admin->settings['notify_fromaddress']; 
	$mail->FromName = $admin->settings['notify_fromname'];
	$mail->Subject = "Servicios Vencidos de Clientes";
	$mail->Body = "<html><body><p>Estimado(a): <b>".$nombres."</b></p></br>
	<p>Se han encontrado clientes con el servicio vencido</p></br>
	<p>Para mayor informacion por favor revise el reporte de clientes con servicios vencidos en el siguiente link:</p>
	<p><a href='https://autosuplente.sugarondemand.com/'>https://autosuplente.sugarondemand.com</a></p></br></body></html>";
	$mail->prepForOutbound();
	$mail->setMailerForSystem();
	$mail->Send();
}
?>