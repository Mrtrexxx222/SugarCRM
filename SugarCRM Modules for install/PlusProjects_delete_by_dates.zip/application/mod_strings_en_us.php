<?PHP
$mod_strings['fieldTypes']['FRPDFButton'] = 'Plus Projects boton PDF para Sugar';
?>
