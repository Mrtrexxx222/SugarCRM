<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class fdelete
{
    /*
     * The method that does the checking for the specific fields. This is
     * the method that we'll want to call in the logic_hooks.php file.
     */

    function fdelete($bean, $event, $arguments)
	{
		$db =  DBManagerFactory::getInstance(); 
	
		$query = "select id from contacts where deleted = '1'";
		$result = $db->query($query, true, 'Error selecting the contact record');
		while($row=$db->fetchByAssoc($result))
		{
			$query = "delete from contacts_cstm where id_c = '".$row['id']."'";
			$result = $db->query($query, true, 'Error deleting the old contact_cstm record');

			$query = "delete from contacts where id = '".$row['id']."'";
			$result = $db->query($query, true, 'Error deleting the old contact record');
		}
    }
} 
?>