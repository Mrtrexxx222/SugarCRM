<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class fupdate
{
    /*
     * The method that does the checking for the specific fields. This is
     * the method that we'll want to call in the logic_hooks.php file.
     */

    function fupdate($bean, $event, $arguments)
	{
		$db =  DBManagerFactory::getInstance(); 
		
		$query = "select id_c, chasis_c, motor_c, placa_c, entidad_c from contacts_cstm where chasis_c = '".$bean->chasis_c."' and motor_c = '".$bean->motor_c."' and placa_c ='".$bean->placa_c."' and entidad_c ='".$bean->entidad_c."'";
		$result = $db->query($query, true, 'Error selecting the contact record');
 
		if ($row=$db->fetchByAssoc($result))
		{
			$query = "update contacts_cstm set cedula_ruc_c = '".$bean->cedula_ruc_c."', marca_c = '".$bean->marca_c."', modelo_c = '".$bean->modelo_c."', fecha_emision_poliza_c = '".$bean->fecha_emision_poliza_c."', fecha_inicio_servicio_c = '".$bean->fecha_inicio_servicio_c."', fecha_final_servicio_c = '".$bean->fecha_final_servicio_c."' where chasis_c = '".$bean->chasis_c."' and motor_c = '".$bean->motor_c."' and placa_c ='".$bean->placa_c."' and entidad_c ='".$bean->entidad_c."'";
			$result = $db->query($query, true, 'Error updating the contact_cstm record...');

			$query = "update contacts set first_name = '".$bean->first_name."', last_name = '".$bean->last_name."', phone_home = '".$bean->phone_home."', phone_mobile = '".$bean->phone_mobile."', phone_work = '".$bean->phone_work."', primary_address_street = '".$bean->primary_address_street."', primary_address_city = '".$bean->primary_address_city."' where id ='".$row['id_c']."'";
			$result = $db->query($query, true, 'Error updating the contact record...');
		}
    }
} 
?>