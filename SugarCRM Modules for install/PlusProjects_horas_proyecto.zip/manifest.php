<?PHP
// manifest file for information regarding application of new code
$manifest = array(
  // only install on the following regex sugar versions (if empty, no check)
  'acceptable_sugar_flavors' => array(
          0 => 'CE',
          1 => 'PRO',
          2 => 'ENT',
          3 => 'DEV'
        ),
  'acceptable_sugar_versions' => array(
          'exact_matches' => array(),
    'regex_matches' => array(
            '6|(5\.[1-9])'
          ),
  ),
 // name of new code
  'name' => 'Plus Projects horas de proyecto',

  // description of new code
  'description' => 'Plugin para Sugar el cual permite calcular el total de horas invertidas en un proyecto',

  // author of new code
  'Wilmer' => 'Wilmer Alcivar<walcivar@plus-projects.com>',

  // date published
  'published_date' => '2012-08-21',

  // unistallable
  'is_uninstallable' => true,

  // version of code
  'version' => '1.0',

  // type of code (valid choices are: full, langpack, module, patch, theme )
  'type' => 'module',

  // icon for displaying in UI (path to graphic contained within zip package)
  'icon' => ''
);

$installdefs = array(
 'id'       => 'ProjectHours',
 'copy'     => array(
				array('from'    => '<basepath>/modules/Tasks/logic_hooks.php',
                      'to'      => 'custom/modules/Tasks/logic_hooks.php',
                ),
				array('from'    => '<basepath>/modules/Tasks/add_hours.php',
                      'to'      => 'custom/modules/Tasks/add_hours.php',
                ),
			),
 );

if (!preg_match('/^6|(5\.(?>[2-9]|1\.0[a-z]))/', $GLOBALS['sugar_version']))
    $installdefs['copy'][] =
                   array('from'    => '<basepath>/modules/ModuleBuilder/views/view.modulefield.php',
                      'to'      => 'modules/ModuleBuilder/views/view.modulefield.php',
                );
