<?php 
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

class add_hours 
{ 
	function work_hours_diff(&$bean, $event, $arguments) 
	{
		if($bean->finish_date_c != "" && $bean->finish_date_c != null)
		{
			if($bean->parent_type == "Project" || $bean->parent_type == "Proyecto")
			{
				if($bean->status == "Completed" || $bean->status == "Completada")
				{
					$start = strtotime($bean->date_start);
					$end = strtotime($bean->finish_date_c);
					$diff = $end - $start;
					$days = floor ( $diff/86400 ); //calculate the days
					$diff = $diff - ($days*86400); // subtract the days
					$hours = floor ( $diff/3600 ); // calculate the hours
					$diff = $diff - ($hours*3600); // subtract the hours
					$mins = floor ( $diff/60 ); // calculate the minutes
					$diff = $diff - ($mins*60); // subtract the mins
					$secs = $diff; // what's left is the seconds;
					if ($secs!=0) 
					{
						//$secs .= " seconds";
						if ($secs=="1")
							$secs = 1; 
					}
					else 
						$secs = '';
					if ($mins!=0) 
					{
						//$mins .= " mins ";
						if ($mins=="1") 
							$mins = 1; 
						$secs = '';
					}
					else 
						$mins = '';
					if ($hours!=0) 
					{
						//$hours .= " hours ";
						if ($hours=="1") 
							$hours = 1;             
						$secs = '';
					}
					else 
						$hours = '';
					if ($days!=0) 
					{
						//$days .= " days "; 
						if ($days=="1")
							$days = 1;                 
						//$mins = '';
						//$secs = '';
						if ($days == "-1") 
						{
							$days = $hours = $mins = '';
							$secs = "less than 10 seconds";
						}
						if($days >= 1)
						{
							$hours = $hours + ($days * 24);
						}
					}
					else 
						$days = '';
					//return "$days $hours $mins $secs ago";


					$db = DBManagerFactory::getInstance();
					$query = "select horas_c, minutos_c from project_cstm where id_c = '".$bean->parent_id."'";
					$result = $db->query($query, true, 'Error selecting the hours and minutes of the record');
					$row=$db->fetchByAssoc($result);

					if ($row['horas_c'] != "" && $row['horas_c'] != null)
					{
						$horas_proyecto = $row['horas_c'] + $hours;
						if(($row['minutos_c'] + $mins) >= 60)
						{	
							for($i=$row['minutos_c'];$i<60;$i++)
							{
								$mins = $mins - 1;
							}
							$horas_proyecto = $horas_proyecto + 1;
							$minutos_proyecto = $mins;
							$query = "update project_cstm set horas_c = ".$horas_proyecto.", minutos_c = ".$minutos_proyecto.", horas_proyecto_c = '" .$horas_proyecto.":".$minutos_proyecto."' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating the hours');
						}
						else
						{
							$minutos_proyecto= $row['minutos_c'] + $mins;
							$query = "update project_cstm set horas_c = ".$horas_proyecto.", minutos_c = ".$minutos_proyecto.", horas_proyecto_c = '" .$horas_proyecto.":".$minutos_proyecto."' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating the hours');
						}
					}
					else
					{
						if($mins == 0 && $hours!=0)
						{
							$query = "update project_cstm set horas_c = ".$hours.", minutos_c = 00, horas_proyecto_c = '".$hours.":00' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating for first time the hours');
						}
						else if($hours == 0 && $mins!=0)
						{
							$query = "update project_cstm set horas_c = 00, minutos_c = ".$mins.", horas_proyecto_c = '0:".$mins."' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating for first time the hours');
						}
						else if($hours == 0 && $mins == 0)
						{
							$query = "update project_cstm set horas_c = 0, minutos_c = 0, horas_proyecto_c = '0:00' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating for first time the hours');
						}
						else
						{
							$query = "update project_cstm set horas_c = ".$hours.", minutos_c = ".$mins.", horas_proyecto_c = '".$hours.":".$mins."' where id_c = '".$bean->parent_id."'";
							$resultado = $db->query($query, true, 'Error updating for first time the hours');
						}
					}
				}
			}
		}
	}
}
?>


