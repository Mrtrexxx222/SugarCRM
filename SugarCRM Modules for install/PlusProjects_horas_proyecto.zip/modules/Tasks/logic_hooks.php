<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
 $hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['after_save'] = Array(); 
$hook_array['after_save'][] = Array(1, 'Custom Logic', 'custom/modules/Tasks/add_hours.php', 'add_hours', 'work_hours_diff');

$hook_array['after_relationship_add'][] = Array(2,'Custom Logic','custom/modules/Tasks/add_hours.php','add_hours','work_hours_diff');

$hook_array['after_relationship_delete'][] = Array(3,'Custom Logic','custom/modules/Tasks/add_hours.php','add_hours','work_hours_diff'); 
?>